<?php
declare(strict_types=1);

function page_dashboard(): string {
    require_login();
    $user = current_user();
    $pdo  = db();
    $uid  = (int)$user['id'];

    $orders_count = $pdo->prepare('SELECT COUNT(*) FROM orders WHERE user_id=?'); $orders_count->execute([$uid]); $orders_count = (int)$orders_count->fetchColumn();
    $total_spent  = $pdo->prepare('SELECT COALESCE(SUM(price),0) FROM orders WHERE user_id=?'); $total_spent->execute([$uid]); $total_spent = (float)$total_spent->fetchColumn();
    $recent_orders = $pdo->prepare('SELECT o.*,c.brand,c.number,c.country FROM orders o JOIN cards c ON c.id=o.card_id WHERE o.user_id=? ORDER BY o.purchased_at DESC LIMIT 5'); $recent_orders->execute([$uid]); $recent_orders=$recent_orders->fetchAll();

    $seller_stats = null;
    if (in_array($user['role'], ['seller','admin'])) {
        $s_count = $pdo->prepare('SELECT COUNT(*) FROM cards WHERE seller_id=?'); $s_count->execute([$uid]); $s_count=(int)$s_count->fetchColumn();
        $s_sold  = $pdo->prepare('SELECT COUNT(*) FROM orders WHERE seller_id=?'); $s_sold->execute([$uid]); $s_sold=(int)$s_sold->fetchColumn();
        $s_rev   = $pdo->prepare('SELECT COALESCE(SUM(price)*0.9,0) FROM orders WHERE seller_id=?'); $s_rev->execute([$uid]); $s_rev=(float)$s_rev->fetchColumn();
        $seller_stats = ['listed'=>$s_count,'sold'=>$s_sold,'revenue'=>$s_rev];
    }

    ob_start(); ?>
<div class="topbar"><h1 class="page-title">Dashboard</h1>
  <a href="/?p=deposit" class="btn btn-primary btn-sm">+ Deposit</a>
</div>

<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-label">Balance</div>
    <div class="stat-value green">$<?= number_format((float)$user['balance'], 2) ?></div>
    <div class="stat-sub">Available funds</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Orders</div>
    <div class="stat-value"><?= $orders_count ?></div>
    <div class="stat-sub">Total purchases</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Total Spent</div>
    <div class="stat-value red">$<?= number_format($total_spent, 2) ?></div>
    <div class="stat-sub">All time</div>
  </div>
  <?php if ($seller_stats): ?>
  <div class="stat-card">
    <div class="stat-label">Cards Listed</div>
    <div class="stat-value"><?= $seller_stats['listed'] ?></div>
    <div class="stat-sub"><?= $seller_stats['sold'] ?> sold</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Revenue (90%)</div>
    <div class="stat-value green">$<?= number_format($seller_stats['revenue'], 2) ?></div>
    <div class="stat-sub">After 10% fee</div>
  </div>
  <?php endif; ?>
</div>

<div class="card">
  <div class="section-title">Recent Orders</div>
  <?php if (empty($recent_orders)): ?>
    <div class="empty-state"><h3>No orders yet</h3><p><a href="/?p=marketplace" class="text-red">Browse the marketplace</a> to make your first purchase.</p></div>
  <?php else: ?>
  <div class="table-wrap" style="border:none">
    <table>
      <thead><tr><th>Order ID</th><th>Card</th><th>Country</th><th>Price</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($recent_orders as $o): ?>
        <tr>
          <td class="td-mono">#<?= $o['id'] ?></td>
          <td class="td-mono"><?= h(substr($o['number'],0,6)) ?>••••••<?= h(substr($o['number'],-4)) ?> <span class="badge badge-gray"><?= h($o['brand']) ?></span></td>
          <td><?= h($o['country']) ?></td>
          <td class="td-price">$<?= number_format((float)$o['price'],2) ?></td>
          <td><?php
            $s=$o['status'];
            $cls=$s==='delivered'?'badge-green':($s==='refunded'?'badge-red':'badge-amber');
            echo '<span class="badge '.$cls.'">'.$s.'</span>';
          ?></td>
          <td class="text-dim"><?= date('M j, Y', (int)$o['purchased_at']) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
<?php
    return ob_get_clean();
}
