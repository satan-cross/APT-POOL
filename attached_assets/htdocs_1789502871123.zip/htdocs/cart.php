<?php
declare(strict_types=1);

function page_cart(): string {
    require_login();
    $uid = (int)$_SESSION['user_id'];
    $pdo = db();

    // Handle actions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $act = post('action');
        if ($act === 'remove') {
            remove_from_cart($uid, (int)post('card_id'));
            flash('Item removed from cart', 'info');
        } elseif ($act === 'checkout') {
            if (!shop_is_open()) {
                flash('The shop is currently closed — checkout is disabled.', 'error');
                header('Location: /?p=cart');
                exit;
            }
            $result = checkout_cart($uid);
            if ($result['ok']) {
                flash('Purchase complete! ' . $result['count'] . ' card(s) bought for $' . number_format($result['total'],2), 'success');
                header('Location: /?p=orders');
                exit;
            } else {
                flash($result['msg'], 'error');
            }
        }
        header('Location: /?p=cart');
        exit;
    }

    expire_cart_items();

    // Query extended to select the new address fields from the cards table
    $items = $pdo->prepare('SELECT ci.*,c.price,c.number,c.brand,c.card_type,c.bank,c.address,c.address2,c.city,c.state,c.zipcode,c.country,c.exp,c.balance FROM cart_items ci JOIN cards c ON c.id=ci.card_id WHERE ci.user_id=? AND ci.reserved_until>? ORDER BY ci.created_at DESC');
    $items->execute([$uid, time()]);
    $items = $items->fetchAll();
    $total = array_sum(array_column($items, 'price'));
    $user  = current_user();

    ob_start(); ?>
<div class="topbar">
  <h1 class="page-title">Cart <span>(<?= count($items) ?>)</span></h1>
  <?php if (!empty($items)): ?>
    <div class="timer-badge">
      <span class="dot dot-red"></span>
      Reservations expire in <strong data-countdown="<?= max(0, $items[0]['reserved_until'] - time()) ?>">10:00</strong>
    </div>
  <?php endif; ?>
</div>

<?php if (empty($items)): ?>
  <div class="card empty-state">
    <h3>Your cart is empty</h3>
    <p class="text-muted mt-8">Browse the marketplace to add cards.</p>
    <a href="/?p=marketplace" class="btn btn-primary mt-16">Browse Cards</a>
  </div>
<?php else: ?>

<div class="table-wrap">
  <table>
    <thead>
      <tr>
        <th>Number</th><th>Brand</th><th>Type</th><th>Bank</th>
        <th>Address</th><th>Address 2</th><th>City</th><th>State</th><th>Zipcode</th>
        <th>CC</th><th>Exp</th><th>Balance</th><th>Price</th><th>Timer</th><th></th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($items as $item):
      $secs = max(0, $item['reserved_until'] - time()); ?>
      <tr>
        <td class="td-mono"><?= h(substr($item['number'],0,6)) ?>••••••<?= h(substr($item['number'],-4)) ?></td>
        <td><span class="badge badge-purple"><?= h($item['brand']) ?></span></td>
        <td class="text-dim"><?= h($item['card_type']) ?></td>
        <td style="font-size:11px"><?= h($item['bank']) ?></td>

        <!-- Rendered Address Columns -->
        <td style="font-size:11px"><?= h($item['address']) ?></td>
        <td style="font-size:11px"><?= h($item['address2']) ?></td>
        <td style="font-size:11px"><?= h($item['city']) ?></td>
        <td style="font-size:11px"><?= h($item['state']) ?></td>
        <td class="td-mono" style="font-size:11px"><?= h($item['zipcode']) ?></td>

        <td><span class="badge badge-gray"><?= h($item['country']) ?></span></td>
        <td class="td-mono text-dim"><?= h($item['exp']) ?></td>
        <td style="color:var(--green);font-weight:600"><?= $item['balance']?'$'.number_format((float)$item['balance'],2):'–' ?></td>
        <td class="td-price">$<?= number_format((float)$item['price'],2) ?></td>
        <td><span class="timer-badge" style="font-size:11px;padding:3px 8px"><span data-countdown="<?= $secs ?>">—</span></span></td>
        <td>
          <form method="POST">
            <input type="hidden" name="action" value="remove">
            <input type="hidden" name="card_id" value="<?= $item['card_id'] ?>">
            <button class="btn btn-danger btn-xs">Remove</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="card mt-16" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px">
  <div>
    <div class="text-dim text-sm">Order total</div>
    <div style="font-size:24px;font-weight:700;color:var(--red);text-shadow:var(--glow-red)">$<?= number_format($total, 2) ?></div>
    <div class="text-dim text-xs mt-4">Your balance: $<?= number_format((float)$user['balance'], 2) ?></div>
    <?php if (!shop_is_open()): ?>
      <div class="alert alert-error mt-8" style="margin-bottom:0">⚠ The shop is currently closed. Checkout is disabled until it reopens.</div>
    <?php elseif ($user['balance'] < $total): ?>
      <div class="alert alert-error mt-8" style="margin-bottom:0">Insufficient balance — <a href="/?p=deposit">Deposit funds</a></div>
    <?php endif; ?>
  </div>
  <div class="flex gap-8">
    <a href="/?p=marketplace" class="btn btn-ghost">Continue Shopping</a>
    <form method="POST">
      <input type="hidden" name="action" value="checkout">
      <button class="btn btn-primary" <?= ($user['balance'] < $total || !shop_is_open()) ? 'disabled' : '' ?> <?= !shop_is_open() ? 'title="Shop is currently closed"' : '' ?>>
        <svg viewBox="0 0 16 16" fill="currentColor"><path d="M2.97 1.35A1 1 0 013.73 1h8.54a1 1 0 01.76.35l2.609 3.044A1.5 1.5 0 0116 5.37v.255a2.375 2.375 0 01-4.25 1.458A2.371 2.371 0 019.875 8 2.371 2.371 0 018 7.083 2.371 2.371 0 016.125 8a2.371 2.371 0 01-1.875-.917A2.375 2.375 0 010 5.625V5.37a1.5 1.5 0 01.361-.976zm1.78 4.275a1.375 1.375 0 002.75 0 .5.5 0 011 0 1.375 1.375 0 002.75 0 .5.5 0 011 0 1.375 1.375 0 102.75 0V5.37a.5.5 0 00-.12-.325L12.27 2H3.73L1.12 5.045A.5.5 0 001 5.37v.255a1.375 1.375 0 002.75 0 .5.5 0 011 0zM1.5 8.5A.5.5 0 012 9v6h1v-5a1 1 0 011-1h3a1 1 0 011 1v5h6V9a.5.5 0 011 0v6h.5a.5.5 0 010 1H.5a.5.5 0 010-1H1V9a.5.5 0 01.5-.5zM7 14h2v-4H7v4z"/></svg>
        Checkout $<?= number_format($total, 2) ?>
      </button>
    </form>
  </div>
</div>
<?php endif; ?>
<?php
    return ob_get_clean();
}