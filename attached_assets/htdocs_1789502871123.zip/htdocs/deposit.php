<?php
declare(strict_types=1);

function page_deposit(): string {
    require_login();
    $uid  = (int)$_SESSION['user_id'];
    $pdo  = db();

    // ── POST handlers ─────────────────────────────────────────────────────────
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $act = post('action');

        if (!shop_is_open()) {
            flash('Deposits are disabled while the shop is closed.', 'error');
            header('Location: /?p=deposit'); exit;
        }

        // ── Force-refresh currency list (admin convenience) ──────────────────
        if ($act === 'refresh_currencies') {
            require_admin();
            $list = CoinPayments::refreshCurrencies();
            if ($list !== false) {
                flash('Currency list refreshed — ' . count($list) . ' coins loaded from CoinPayments.', 'success');
            } else {
                flash('Failed to refresh currency list from CoinPayments API.', 'error');
            }
            header('Location: /?p=deposit'); exit;
        }

        // ── Create a CoinPayments invoice ─────────────────────────────────────
        if ($act === 'create_deposit') {
            $symbol = strtoupper(trim(post('coin', 'BTC')));
            $amount = round(max(1.0, (float)post('amount', 0)), 2);

            $currencies = PayGate::getEnabledCoins();
            if (!isset($currencies[$symbol])) {
                flash('Invalid or unsupported coin: ' . h($symbol) . '. Please select a coin from the list.', 'error');
                header('Location: /?p=deposit'); exit;
            }

            if (!in_array($symbol, ['BTC', 'XMR'], true)) {
                flash('Only Bitcoin and Monero deposits are supported.', 'error');
                header('Location: /?p=deposit'); exit;
            }

            // Insert a pending row first to get a stable unique reference ID
            $pdo->prepare(
                'INSERT INTO deposits (user_id, method, amount, status) VALUES (?, ?, ?, ?)'
            )->execute([$uid, $symbol, $amount, 'pending']);
            $dep_id = (int)$pdo->lastInsertId();

            $secret = get_setting('pg_callback_secret', '');
            $token = hash_hmac('sha256', 'dep_' . $dep_id . '_uid_' . $uid, $secret);
            $proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
            $callback = $proto . '://' . $host . '/pg_callback.php?' . http_build_query([
                'dep_id' => $dep_id, 'uid' => $uid, 'token' => $token
            ]);
            $pg = PayGate::createWallet($symbol, $callback);
            if (!$pg['ok']) {
                $pdo->prepare('DELETE FROM deposits WHERE id=?')->execute([$dep_id]);
                flash('PayGate error: ' . ($pg['error'] ?? 'Unknown error'), 'error');
                header('Location: /?p=deposit'); exit;
            }
            $converted = PayGate::convertToCrypto($symbol, $amount);

            $pdo->prepare(
                'UPDATE deposits
                    SET cp_invoice_id=?, deposit_address=?, cp_amount_crypto=?
                  WHERE id=?'
            )->execute([
                'pg_' . $dep_id,
                $pg['address_in'],
                $converted['amount_crypto'] ?? null,
                $dep_id,
            ]);

            header("Location: /?p=deposit&show={$dep_id}"); exit;
        }
    }

    // ── Active deposit to show ────────────────────────────────────────────────
    $show_id    = (int)($_GET['show'] ?? 0);
    $active_dep = null;
    if ($show_id > 0) {
        $stmt = $pdo->prepare('SELECT * FROM deposits WHERE id=? AND user_id=?');
        $stmt->execute([$show_id, $uid]);
        $active_dep = $stmt->fetch() ?: null;
    }

    $history = $pdo->prepare('SELECT * FROM deposits WHERE user_id=? ORDER BY created_at DESC LIMIT 30');
    $history->execute([$uid]);
    $history = $history->fetchAll();

    $user      = current_user();
    $shop_open = shop_is_open();

    // ── Load supported coins ─────────────────────────────────────────────────
    $currencies  = PayGate::getEnabledCoins();   // BTC and XMR only
    $popular     = $currencies;
    $total_coins = count($currencies);

    ob_start(); ?>
<div class="topbar">
  <h1 class="page-title">Deposit Funds</h1>
  <div style="font-size:12px;color:var(--text-3)"><?= $total_coins ?> cryptocurrencies supported</div>
</div>

<?php if (!$shop_open): ?>
<div class="alert alert-error" style="margin-bottom:20px">
  🔒 Deposits are currently disabled. The shop is closed.
</div>
<?php endif; ?>

<!-- ── Active deposit panel ──────────────────────────────────────────────── -->
<?php if ($active_dep): ?>
<?php
  $act_symbol   = strtoupper($active_dep['method'] ?? 'CRYPTO');
  $all_coins    = CoinPayments::getCurrencies();
  $act_coin     = $all_coins[$act_symbol] ?? ['name' => $act_symbol, 'symbol' => $act_symbol];
  $checkout_url   = $active_dep['cp_checkout_url']  ?? '';
  $pay_address    = $active_dep['deposit_address']  ?? '';
  $amount_crypto  = $active_dep['cp_amount_crypto'] ?? '';
  $is_pending     = $active_dep['status'] !== 'confirmed';
?>
<div class="card" style="margin-bottom:22px;border-color:<?= $is_pending ? 'var(--amber)' : 'var(--green)' ?>30">
  <div style="display:flex;align-items:center;gap:10px;margin-bottom:18px">
    <span class="badge <?= $is_pending ? 'badge-amber' : 'badge-green' ?>" id="status-badge"
          style="font-size:13px;padding:4px 12px">
      <?= $is_pending ? '⏳ Awaiting Payment' : '✓ Confirmed' ?>
    </span>
    <span class="text-dim" style="font-size:12px">
      Deposit #<?= $active_dep['id'] ?> &middot; <?= h($act_coin['name']) ?> (<?= h($act_symbol) ?>)
    </span>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px">
    <div>
      <div class="stat-label">USD Amount</div>
      <div class="stat-value green" style="font-size:22px">$<?= number_format((float)$active_dep['amount'], 2) ?></div>
    </div>
    <?php if ($amount_crypto): ?>
    <div>
      <div class="stat-label">Crypto Amount</div>
      <div class="stat-value" style="font-size:18px;font-family:monospace">
        <?= h($amount_crypto) ?> <?= h($act_symbol) ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <?php if ($pay_address): ?>
  <div style="margin-bottom:16px">
    <div class="stat-label" style="margin-bottom:6px">Send <?= h($act_symbol) ?> to this address</div>
    <div style="display:flex;align-items:center;gap:8px">
      <code id="pay-addr" style="flex:1;background:var(--bg-3);border:1px solid var(--border-2);border-radius:8px;
            padding:10px 12px;font-size:12px;word-break:break-all;color:var(--amber)">
        <?= h($pay_address) ?>
      </code>
      <button class="btn btn-secondary btn-sm" onclick="copyAddr()" title="Copy address">⧉</button>
    </div>
  </div>
  <?php endif; ?>

  <?php if ($checkout_url): ?>
  <div style="margin-bottom:16px">
    <a href="<?= h($checkout_url) ?>" target="_blank" rel="noopener"
       class="btn btn-primary" style="width:100%;justify-content:center;display:flex;gap:8px">
      💳 Open CoinPayments Checkout
    </a>
    <div class="text-dim" style="font-size:11px;text-align:center;margin-top:6px">
      Opens the CoinPayments hosted payment page in a new tab
    </div>
  </div>
  <?php endif; ?>

  <?php if ($is_pending): ?>
  <div id="confirm-tracker"
       style="background:var(--bg-3);border-radius:8px;padding:12px 16px;font-size:13px">
    <div style="display:flex;align-items:center;gap:10px">
      <span style="color:var(--text-2)">Confirmations:</span>
      <span style="display:flex;gap:5px">
        <?php for ($i = 0; $i < 3; $i++): ?>
        <span id="cdot-<?= $i ?>" style="width:12px;height:12px;border-radius:50%;
              background:var(--border);display:inline-block;transition:background .3s"></span>
        <?php endfor; ?>
      </span>
      <span id="conf-label" style="color:var(--text-2);font-size:12px">0 / 1</span>
    </div>
    <div style="display:flex;align-items:center;gap:8px;margin-top:10px">
      <button id="check-btn" class="btn btn-secondary btn-sm"
              onclick="checkNow(<?= (int)$active_dep['id'] ?>)">🔄 Check Now</button>
      <span id="last-checked" class="text-dim" style="font-size:11px">Checking…</span>
    </div>
  </div>
  <div id="txid-row" style="display:none;margin-top:10px">
    <span class="text-dim" style="font-size:12px">TxID:</span>
    <code id="txid-val" style="font-size:11px;color:var(--indigo);margin-left:6px"></code>
  </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- ── New deposit form ───────────────────────────────────────────────────── -->
<?php if ($shop_open): ?>
<div class="card" style="margin-bottom:22px">
  <div class="section-title" style="margin-bottom:4px">New Deposit via CoinPayments</div>
  <div class="text-dim" style="font-size:12px;margin-bottom:20px">
    Choose any of the <?= $total_coins ?> cryptocurrencies supported by CoinPayments.
  </div>

  <form method="POST" id="deposit-form" onsubmit="return validateForm()">
    <input type="hidden" name="action" value="create_deposit">
    <input type="hidden" name="coin"   id="selected-coin" value="BTC">

    <!-- Amount -->
    <div style="margin-bottom:22px">
      <label class="form-label">Deposit Amount (USD)</label>
      <div style="display:flex;align-items:center;gap:8px;max-width:260px">
        <span style="color:var(--text-3);font-size:18px">$</span>
        <input class="form-input" type="number" id="amount-input" name="amount"
               min="1" step="0.01" placeholder="e.g. 50.00" required
               style="font-size:16px;font-weight:600">
      </div>
      <div class="text-dim" style="font-size:11px;margin-top:4px">Minimum $1.00</div>
    </div>

    <!-- Popular coins quick-pick -->
    <div style="margin-bottom:14px">
      <label class="form-label" style="margin-bottom:10px">
        Popular Coins
        <span class="text-dim" style="font-weight:400;font-size:11px;margin-left:6px">
          — or search all <?= $total_coins ?> below
        </span>
      </label>
      <div id="popular-tiles"
           style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:4px">
        <?php foreach ($popular as $sym => $c): ?>
        <button type="button"
                onclick="selectCoin('<?= h($sym) ?>', '<?= h(addslashes($c['name'])) ?>')"
                class="coin-tile" data-symbol="<?= h($sym) ?>"
                style="background:var(--bg-3);border:2px solid var(--border-2);border-radius:8px;
                       padding:7px 14px;font-size:12px;font-weight:700;cursor:pointer;
                       color:var(--text-1);transition:all .12s;white-space:nowrap;
                       <?= $sym === 'BTC' ? 'border-color:var(--amber);background:rgba(245,158,11,.08)' : '' ?>">
          <?= h($sym) ?>
          <span style="font-weight:400;color:var(--text-3);font-size:10px;margin-left:3px">
            <?= h(strtok($c['name'], ' ')) ?>
          </span>
        </button>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Full searchable dropdown -->
    <div style="margin-bottom:22px">
      <label class="form-label" style="margin-bottom:6px">All Supported Coins</label>
      <div style="position:relative;max-width:440px">
        <input type="text" id="coin-search"
               placeholder="Search by name or symbol (e.g. Ethereum, SOL, USDT…)"
               autocomplete="off"
               style="width:100%;background:var(--bg-3);border:1px solid var(--border-2);
                      border-radius:8px;color:var(--text-1);padding:10px 36px 10px 12px;
                      font-size:13px"
               oninput="filterCoins(this.value)"
               onfocus="showDropdown()"
               onblur="setTimeout(hideDropdown,180)">
        <span style="position:absolute;right:10px;top:50%;transform:translateY(-50%);
                     color:var(--text-3);font-size:14px;pointer-events:none">▾</span>
        <div id="coin-dropdown"
             style="display:none;position:absolute;top:calc(100% + 4px);left:0;right:0;
                    background:var(--bg-2);border:1px solid var(--border-2);border-radius:8px;
                    max-height:260px;overflow-y:auto;z-index:200;box-shadow:0 8px 24px rgba(0,0,0,.5)">
          <?php foreach ($currencies as $sym => $c): ?>
          <div class="coin-option"
               data-symbol="<?= h($sym) ?>"
               data-search="<?= h(strtolower($sym . ' ' . $c['name'])) ?>"
               onclick="selectCoin('<?= h($sym) ?>', '<?= h(addslashes($c['name'])) ?>')"
               style="padding:9px 14px;cursor:pointer;font-size:13px;
                      display:flex;align-items:center;justify-content:space-between;
                      border-bottom:1px solid var(--border)">
            <span>
              <span style="font-weight:700;color:var(--text-1)"><?= h($sym) ?></span>
              <span style="color:var(--text-3);margin-left:8px;font-size:12px"><?= h($c['name']) ?></span>
            </span>
            <span class="coin-check" style="display:none;color:var(--amber)">✓</span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <div id="selected-coin-display"
           style="margin-top:8px;font-size:13px;color:var(--text-2)">
        Selected: <strong id="selected-coin-label" style="color:var(--amber)">Bitcoin (BTC)</strong>
      </div>
    </div>

    <button type="submit" class="btn btn-primary" style="min-width:220px">
      Generate Payment Invoice →
    </button>
    <div class="text-dim" style="font-size:11px;margin-top:8px;max-width:440px;line-height:1.6">
      You will receive a CoinPayments payment address and hosted checkout link.
      Your account balance is credited automatically once the transaction is confirmed on-chain.
    </div>
  </form>
</div>
<?php endif; ?>

<!-- ── Deposit history ────────────────────────────────────────────────────── -->
<?php if (!empty($history)): ?>
<div class="card">
  <div class="section-title" style="margin-bottom:14px">Deposit History</div>
  <div class="table-wrap" style="border:none">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Coin</th>
          <th>USD</th>
          <th>Crypto</th>
          <th>Invoice ID</th>
          <th>Status</th>
          <th>Date</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($history as $dep): ?>
      <?php
        $sc = match($dep['status']) {
            'confirmed' => 'badge-green',
            'rejected', 'cancelled' => 'badge-red',
            default     => 'badge-amber',
        };
        $dep_sym  = strtoupper($dep['method'] ?? '?');
        $inv_id   = $dep['cp_invoice_id'] ?? '';
      ?>
      <tr>
        <td class="td-mono"><?= $dep['id'] ?></td>
        <td><span class="badge badge-gray"><?= h($dep_sym) ?></span></td>
        <td class="td-price">$<?= number_format((float)$dep['amount'], 2) ?></td>
        <td class="text-dim" style="font-size:11px;font-family:monospace">
          <?= $dep['cp_amount_crypto'] ? h(substr($dep['cp_amount_crypto'], 0, 14)) : '—' ?>
        </td>
        <td class="text-dim" style="font-size:11px;font-family:monospace">
          <?= $inv_id ? h(substr($inv_id, 0, 22)) . (strlen($inv_id) > 22 ? '…' : '') : '—' ?>
        </td>
        <td><span class="badge <?= $sc ?>"><?= h($dep['status']) ?></span></td>
        <td class="text-dim" style="font-size:11px">
          <?= date('M j Y H:i', (int)$dep['created_at']) ?>
        </td>
        <td>
          <?php if ($dep['status'] === 'pending'): ?>
          <a href="/?p=deposit&show=<?= $dep['id'] ?>" class="btn btn-ghost btn-xs">View</a>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<style>
.coin-option:hover { background: var(--bg-3); }
.coin-option.selected { background: rgba(245,158,11,.08); }
.coin-option.selected .coin-check { display:inline!important; }
.coin-tile.selected { border-color:var(--amber)!important; background:rgba(245,158,11,.08)!important; }
#coin-search:focus { outline:none; border-color:var(--border-2); }
</style>

<script>
// ── State ────────────────────────────────────────────────────────────────────
let currentSymbol = 'BTC';
let dropdownVisible = false;

function selectCoin(symbol, name) {
  currentSymbol = symbol;
  document.getElementById('selected-coin').value      = symbol;
  document.getElementById('selected-coin-label').textContent = name + ' (' + symbol + ')';
  document.getElementById('coin-search').value        = symbol + ' — ' + name;

  // Update popular tiles
  document.querySelectorAll('.coin-tile').forEach(t => t.classList.remove('selected'));
  const tile = document.querySelector('.coin-tile[data-symbol="' + symbol + '"]');
  if (tile) tile.classList.add('selected');

  // Update dropdown options
  document.querySelectorAll('.coin-option').forEach(o => {
    o.classList.toggle('selected', o.dataset.symbol === symbol);
  });

  hideDropdown();
}

function filterCoins(query) {
  query = query.toLowerCase().trim();
  let visible = 0;
  document.querySelectorAll('.coin-option').forEach(opt => {
    const match = !query || opt.dataset.search.includes(query);
    opt.style.display = match ? '' : 'none';
    if (match) visible++;
  });
  showDropdown();
}

function showDropdown() {
  document.getElementById('coin-dropdown').style.display = 'block';
  dropdownVisible = true;
}

function hideDropdown() {
  document.getElementById('coin-dropdown').style.display = 'none';
  dropdownVisible = false;
}

function validateForm() {
  const coin = document.getElementById('selected-coin').value;
  if (!coin) {
    alert('Please select a cryptocurrency.');
    return false;
  }
  const amount = parseFloat(document.getElementById('amount-input').value);
  if (isNaN(amount) || amount < 1) {
    alert('Please enter an amount of at least $1.00.');
    return false;
  }
  return true;
}

// Initialise: mark BTC as selected in the dropdown
document.querySelectorAll('.coin-option[data-symbol="BTC"]').forEach(o => o.classList.add('selected'));

// Keyboard: close dropdown on Escape
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') hideDropdown();
});

<?php if ($active_dep && $active_dep['status'] !== 'confirmed'): ?>
// ── Deposit polling ──────────────────────────────────────────────────────────
const DEP_ID = <?= (int)$active_dep['id'] ?>;
let pollTimer;

function updateDots(confirms) {
  const colors = ['#ef4444', '#f97316', '#22c55e'];
  for (let i = 0; i < 3; i++) {
    const dot = document.getElementById('cdot-' + i);
    if (dot) dot.style.background = confirms > i ? colors[Math.min(i, 2)] : 'var(--border)';
  }
  const lbl = document.getElementById('conf-label');
  if (lbl) lbl.textContent = confirms + ' / 1';
}

async function checkNow(id) {
  const btn = document.getElementById('check-btn');
  const lc  = document.getElementById('last-checked');
  if (btn) btn.disabled = true;
  if (lc)  lc.textContent = 'Checking…';
  try {
    const r = await fetch('check_deposits.php?id=' + id);
    const d = await r.json();
    if (lc) lc.textContent = 'Last checked: ' + new Date().toLocaleTimeString();
    updateDots(d.confirmations || 0);
    if (d.txid) {
      const tr = document.getElementById('txid-row');
      const tv = document.getElementById('txid-val');
      if (tr) tr.style.display = 'block';
      if (tv) tv.textContent   = d.txid.substring(0, 28) + '…';
    }
    if (d.status === 'confirmed') {
      clearInterval(pollTimer);
      const badge = document.getElementById('status-badge');
      if (badge) badge.outerHTML = '<span class="badge badge-green" style="font-size:13px;padding:4px 12px">✓ Confirmed</span>';
      const tracker = document.getElementById('confirm-tracker');
      if (tracker) tracker.innerHTML = '<div style="color:#22c55e;font-size:13px;padding:4px 0">✓ Payment confirmed — refreshing…</div>';
      setTimeout(() => location.reload(), 1500);
    }
  } catch (e) {
    if (lc) lc.textContent = 'Check failed — retrying…';
  }
  if (btn) btn.disabled = false;
}

function copyAddr() {
  const el = document.getElementById('pay-addr');
  if (el) {
    navigator.clipboard.writeText(el.textContent.trim()).then(() => {
      const btn = document.querySelector('[onclick="copyAddr()"]');
      if (btn) { btn.textContent = '✓'; setTimeout(() => btn.textContent = '⧉', 1500); }
    });
  }
}

checkNow(DEP_ID);
pollTimer = setInterval(() => checkNow(DEP_ID), 20000);
<?php endif; ?>
</script>

<?php
    return ob_get_clean();
}
