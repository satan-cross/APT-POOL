/* === BytePool — Vanilla JS === */

function toast(msg, type = 'info') {
  let c = document.querySelector('.toast-container');
  if (!c) { c = document.createElement('div'); c.className = 'toast-container'; c.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px'; document.body.appendChild(c); }
  const t = document.createElement('div');
  t.style.cssText = 'padding:10px 16px;background:var(--bg-surface);border:1px solid var(--border);border-radius:var(--r-md);font-size:12.5px;color:var(--text-1);box-shadow:0 8px 24px rgba(0,0,0,.4);animation:slideIn .2s ease;min-width:220px;display:flex;align-items:center;gap:8px';
  if (type==='success') t.style.borderColor = 'rgba(34,197,94,.3)';
  if (type==='error') t.style.borderColor = 'rgba(219,20,60,.3)';
  const icons = { success: '✓', error: '✕', info: '●' };
  const colors = { success: 'var(--green)', error: 'var(--red)', info: 'var(--teal)' };
  t.innerHTML = `<span style="color:${colors[type]||colors.info}">${icons[type]||icons.info}</span> ${msg}`;
  c.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 300); }, 3000);
}

function copyText(text, btn) {
  navigator.clipboard.writeText(text).then(() => {
    const orig = btn.innerHTML;
    btn.innerHTML = '✓'; btn.style.color = 'var(--green)';
    setTimeout(() => { btn.innerHTML = orig; btn.style.color = ''; }, 1500);
    toast('Copied to clipboard', 'success');
  });
}

function startCountdown(el, seconds, onExpire) {
  if (!el) return;
  let s = parseInt(seconds, 10);
  const update = () => {
    if (s <= 0) { el.textContent = '00:00'; if (onExpire) onExpire(); return; }
    const m = Math.floor(s / 60).toString().padStart(2, '0');
    const sec = (s % 60).toString().padStart(2, '0');
    el.textContent = m + ':' + sec;
    if (s < 60) el.style.color = 'var(--red)';
    s--; setTimeout(update, 1000);
  };
  update();
}

document.addEventListener('DOMContentLoaded', () => {

  // Login tabs
  document.querySelectorAll('.login-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.dataset.tab;
      document.querySelectorAll('.login-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === target));
      document.querySelectorAll('.login-form').forEach(f => f.style.display = f.dataset.form === target ? 'block' : 'none');
    });
  });

  // Countdown timers
  document.querySelectorAll('[data-countdown]').forEach(el => {
    startCountdown(el, el.dataset.countdown, () => { const row = el.closest('tr') || el.closest('.order-card'); if (row) row.style.opacity = '.5'; });
  });

  // Refund countdowns
  document.querySelectorAll('[data-refund-countdown]').forEach(el => {
    startCountdown(el, el.dataset.refundCountdown, () => {
      const btn = el.closest('.refund-bar')?.querySelector('.btn-refund');
      if (btn) { btn.disabled = true; btn.textContent = 'Window Closed'; }
    });
  });

  // Filter form auto-submit on select change
  const ff = document.getElementById('filter-form');
  if (ff) ff.querySelectorAll('select').forEach(s => s.addEventListener('change', () => ff.submit()));

  // Crypto selection
  document.querySelectorAll('.crypto-option').forEach(opt => {
    opt.addEventListener('click', () => {
      document.querySelectorAll('.crypto-option').forEach(o => o.classList.remove('selected'));
      opt.classList.add('selected');
      const addr = opt.dataset.address;
      const addrEl = document.getElementById('deposit-address');
      if (addrEl && addr) addrEl.textContent = addr;
      const nameEl = document.getElementById('selected-crypto');
      if (nameEl) nameEl.textContent = opt.dataset.name || '';
    });
  });

  // Inventory parser preview
  const raw = document.getElementById('raw-inventory');
  const preview = document.getElementById('parser-preview');
  if (raw && preview) {
    raw.addEventListener('input', () => {
      const lines = raw.value.trim().split('\n').filter(l => l.trim());
      if (!lines.length) { preview.textContent = 'Paste raw card data above to preview...'; return; }
      const parsed = lines.slice(0, 5).map(l => { const p = l.split(/[|;,\t]/); return { number: p[0]||'?', exp: p[1]||'?', cvv: p[2]||'?', name: p[3]||'?' }; });
      preview.textContent = JSON.stringify(parsed, null, 2);
      const cnt = document.getElementById('parsed-count');
      if (cnt) cnt.textContent = lines.length + ' card(s) detected';
    });
  }

  // Copy buttons
  document.querySelectorAll('.copy-btn').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const text = btn.dataset.copy || btn.closest('.reveal-value')?.querySelector('.reveal-data')?.textContent || '';
      copyText(text.trim(), btn);
    });
  });

  // Support chat scroll to bottom
  const chatMsgs = document.querySelector('.chat-msgs');
  if (chatMsgs) chatMsgs.scrollTop = chatMsgs.scrollHeight;

  // Auto-dismiss alerts
  document.querySelectorAll('.alert[data-auto-dismiss]').forEach(el => {
    setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .5s'; setTimeout(() => el.remove(), 500); }, 4000);
  });
});
