<?php
declare(strict_types=1);
/**
 * card_unlock.php — PIN verification endpoint
 *
 * POST: { card_id, pin }
 * Returns JSON with the decrypted card payload (for JS to render + encrypt locally).
 *
 * Security:
 * - Must be authenticated buyer who purchased this exact card
 * - PIN verified with password_verify (bcrypt)
 * - Rate-limited: 5 attempts → 15-min lockout (stored in pin_attempts table)
 * - Response only sent over the existing HTTPS proxy
 */

require_once __DIR__ . '/../src/bootstrap.php';
header('Content-Type: application/json');

if (!is_logged_in()) { echo json_encode(['ok'=>false,'error'=>'Not authenticated']); exit; }

$uid     = (int)$_SESSION['user_id'];
$card_id = (int)($_POST['card_id'] ?? 0);
$pin     = (string)($_POST['pin'] ?? '');

if ($card_id <= 0 || $pin === '') { echo json_encode(['ok'=>false,'error'=>'Missing parameters']); exit; }

$pdo = db();

// ── 1. Verify buyer owns this card via a completed order ──────────
$stmt = $pdo->prepare('SELECT o.id FROM orders o WHERE o.user_id=? AND o.card_id=? AND o.status != "refunded" LIMIT 1');
$stmt->execute([$uid, $card_id]);
if (!$stmt->fetchColumn()) {
    echo json_encode(['ok'=>false,'error'=>'Access denied']); exit;
}

// ── 2. Rate-limit check ────────────────────────────────────────────
$MAX_ATTEMPTS = 5;
$LOCKOUT_SECS = 900; // 15 minutes

$ra = $pdo->prepare('SELECT attempts, locked_until FROM pin_attempts WHERE user_id=? AND card_id=?');
$ra->execute([$uid, $card_id]);
$rl = $ra->fetch(PDO::FETCH_ASSOC);

if ($rl && (int)$rl['locked_until'] > time()) {
    $mins = ceil(((int)$rl['locked_until'] - time()) / 60);
    echo json_encode(['ok'=>false,'error'=>"Too many failed attempts. Try again in {$mins} min.",'locked'=>true]); exit;
}

// ── 3. Fetch card and verify PIN ───────────────────────────────────
$cs = $pdo->prepare('SELECT * FROM cards WHERE id=?');
$cs->execute([$card_id]);
$card = $cs->fetch(PDO::FETCH_ASSOC);

if (!$card || empty($card['pin_hash'])) {
    // Card has no PIN — should not reach here but handle gracefully
    echo json_encode(['ok'=>false,'error'=>'This card has no PIN protection']); exit;
}

if (!password_verify($pin, $card['pin_hash'])) {
    // Record failed attempt
    $attempts = ($rl ? (int)$rl['attempts'] : 0) + 1;
    $lock_until = $attempts >= $MAX_ATTEMPTS ? time() + $LOCKOUT_SECS : 0;
    $pdo->prepare('INSERT INTO pin_attempts (user_id,card_id,attempts,locked_until) VALUES (?,?,?,?)
                   ON CONFLICT(user_id,card_id) DO UPDATE SET attempts=excluded.attempts, locked_until=excluded.locked_until')
        ->execute([$uid, $card_id, $attempts, $lock_until]);
    $remaining = $MAX_ATTEMPTS - $attempts;
    $msg = $remaining > 0 ? "Incorrect PIN. {$remaining} attempt(s) remaining." : "Too many attempts. Locked for 15 minutes.";
    echo json_encode(['ok'=>false,'error'=>$msg,'attempts'=>$attempts,'locked'=>($lock_until>0)]); exit;
}

// ── 4. PIN correct — reset attempt counter ────────────────────────
$pdo->prepare('DELETE FROM pin_attempts WHERE user_id=? AND card_id=?')->execute([$uid, $card_id]);

// ── 5. Build and return card payload ─────────────────────────────
// Build human-readable card text for the encrypted download
$lines = [
    'BytePool — Protected Card Data',
    str_repeat('─', 40),
    'Card Number : ' . ($card['number'] ?? ''),
    'Expiry      : ' . ($card['exp'] ?? ''),
    'CVV         : ' . ($card['cvv'] ?? ''),
    'Name        : ' . ($card['card_name'] ?? ''),
    'Bank        : ' . ($card['bank'] ?? ''),
    'Country     : ' . ($card['country'] ?? ''),
    'Type        : ' . ($card['brand'] ?? '') . ' ' . ($card['card_type'] ?? ''),
    'Balance     : ' . ($card['balance'] ? number_format((float)$card['balance'],2) : 'N/A'),
    'Phone       : ' . ($card['phone'] ?? 'N/A'),
    str_repeat('─', 40),
    'Order Date  : ' . date('Y-m-d H:i:s'),
    'Buyer ID    : ' . $uid,
    str_repeat('─', 40),
    '⚠ Keep this information strictly confidential.',
];

echo json_encode([
    'ok'      => true,
    'number'  => $card['number'],
    'exp'     => $card['exp'],
    'cvv'     => $card['cvv'],
    'name'    => $card['card_name'],
    'bank'    => $card['bank'],
    'country' => $card['country'],
    'brand'   => $card['brand'],
    'type'    => $card['card_type'],
    'balance' => $card['balance'],
    'phone'   => $card['phone'] ?? '',
    'text'    => implode("\n", $lines), // plaintext for client-side AES encryption
]);
