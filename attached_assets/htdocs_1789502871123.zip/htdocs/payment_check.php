<?php
declare(strict_types=1);

/**
 * Tokenized Stripe payment-method pre-authorization endpoint.
 *
 * This endpoint intentionally accepts only Stripe PaymentMethod IDs. It must
 * not be called with raw card numbers or CVVs from seller uploads.
 *
 * POST /payment_check.php
 * {
 *   "paymentMethodId": "pm_...",
 *   "requestId": "stable-request-id"
 * }
 */

require_once __DIR__ . '/src/bootstrap.php';

header('Content-Type: application/json; charset=utf-8');

function payment_check_response(array $body, int $status): never
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    payment_check_response([
        'valid' => false,
        'error' => 'POST required',
    ], 405);
}

if (!is_logged_in()) {
    payment_check_response([
        'valid' => false,
        'error' => 'Authentication required.',
    ], 401);
}

$current_user = current_user();
if (!in_array($current_user['role'] ?? '', ['seller', 'admin'], true)) {
    payment_check_response([
        'valid' => false,
        'error' => 'Seller access required.',
    ], 403);
}

$raw_body = file_get_contents('php://input');
$body = json_decode($raw_body ?: '', true);

if (!is_array($body) || array_diff(array_keys($body), ['paymentMethodId', 'requestId'])) {
    payment_check_response([
        'valid' => false,
        'error' => 'Only paymentMethodId and requestId are accepted.',
    ], 400);
}

$payment_method_id = $body['paymentMethodId'] ?? null;
$request_id = $body['requestId'] ?? null;

if (!is_string($payment_method_id) || !preg_match('/^pm_[A-Za-z0-9_]+$/', $payment_method_id)) {
    payment_check_response([
        'valid' => false,
        'error' => 'paymentMethodId must be a valid Stripe PaymentMethod ID.',
    ], 400);
}

if ($request_id !== null && (
    !is_string($request_id) ||
    !preg_match('/^[A-Za-z0-9_-]{8,64}$/', $request_id)
)) {
    payment_check_response([
        'valid' => false,
        'error' => 'requestId must contain 8-64 letters, numbers, underscores, or hyphens.',
    ], 400);
}

$stripe_secret_key = getenv('STRIPE_SECRET_KEY');
if (!is_string($stripe_secret_key) || $stripe_secret_key === '') {
    payment_check_response([
        'valid' => false,
        'error' => 'Stripe payment verification is not configured.',
    ], 503);
}

/**
 * Make a Stripe API request without exposing the secret or provider response.
 *
 * @return array{status:int, body:array<string,mixed>|null, curl_error:?string}
 */
function stripe_payment_request(
    string $method,
    string $path,
    string $secret_key,
    array $form = [],
    ?string $idempotency_key = null
): array {
    $curl = curl_init('https://api.stripe.com/v1' . $path);
    if ($curl === false) {
        return ['status' => 0, 'body' => null, 'curl_error' => 'Unable to initialize HTTP client'];
    }

    $headers = ['Accept: application/json'];
    $options = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_HTTPAUTH => CURLAUTH_BASIC,
        CURLOPT_USERPWD => $secret_key . ':',
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
    ];

    if ($idempotency_key !== null) {
        $options[CURLOPT_HTTPHEADER][] = 'Idempotency-Key: ' . $idempotency_key;
    }

    if ($method === 'POST') {
        $options[CURLOPT_POSTFIELDS] = http_build_query($form, '', '&', PHP_QUERY_RFC3986);
        $options[CURLOPT_HTTPHEADER][] = 'Content-Type: application/x-www-form-urlencoded';
    }

    curl_setopt_array($curl, $options);
    $response = curl_exec($curl);
    $curl_error = curl_error($curl) ?: null;
    $status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
    curl_close($curl);

    if ($response === false || $curl_error !== null) {
        return ['status' => $status, 'body' => null, 'curl_error' => $curl_error ?? 'Stripe request failed'];
    }

    $decoded = json_decode($response, true);
    return [
        'status' => $status,
        'body' => is_array($decoded) ? $decoded : null,
        'curl_error' => null,
    ];
}

$payment_method = stripe_payment_request(
    'GET',
    '/payment_methods/' . rawurlencode($payment_method_id),
    $stripe_secret_key
);

if ($payment_method['curl_error'] !== null) {
    payment_check_response([
        'valid' => false,
        'error' => 'Payment verification is temporarily unavailable.',
    ], 502);
}

if ($payment_method['status'] === 404) {
    payment_check_response([
        'valid' => false,
        'error' => 'Payment method was not found.',
    ], 404);
}

if ($payment_method['status'] < 200 || $payment_method['status'] >= 300 || $payment_method['body'] === null) {
    payment_check_response([
        'valid' => false,
        'error' => 'Payment verification is temporarily unavailable.',
    ], 502);
}

$stripe_payment_method = $payment_method['body'];
if (($stripe_payment_method['type'] ?? null) !== 'card' || !is_array($stripe_payment_method['card'] ?? null)) {
    payment_check_response([
        'valid' => false,
        'error' => 'Only card PaymentMethods can be verified.',
    ], 422);
}

$idempotency_request_id = $request_id ?? ('auto-' . bin2hex(random_bytes(16)));
$payment_intent = stripe_payment_request(
    'POST',
    '/payment_intents',
    $stripe_secret_key,
    [
        'amount' => 120,
        'currency' => 'usd',
        'payment_method' => $payment_method_id,
        'payment_method_types' => ['card'],
        'confirm' => 'true',
        'capture_method' => 'manual',
    ],
    'payment-preauth:' . $payment_method_id . ':' . $idempotency_request_id
);

if ($payment_intent['curl_error'] !== null || $payment_intent['body'] === null) {
    payment_check_response([
        'valid' => false,
        'error' => 'Payment verification is temporarily unavailable.',
    ], 502);
}

$intent = $payment_intent['body'];
$intent_status = $intent['status'] ?? null;

if ($intent_status === 'requires_capture') {
    $card = $stripe_payment_method['card'];
    payment_check_response([
        'valid' => true,
        'status' => 'authorized',
        'amount' => 120,
        'currency' => 'usd',
        'paymentMethod' => [
            'id' => (string) ($stripe_payment_method['id'] ?? $payment_method_id),
            'type' => 'card',
            'brand' => is_string($card['brand'] ?? null) ? $card['brand'] : null,
            'last4' => is_string($card['last4'] ?? null) ? $card['last4'] : null,
        ],
        'paymentIntentId' => (string) ($intent['id'] ?? ''),
    ], 200);
}

if ($intent_status === 'requires_action') {
    payment_check_response([
        'valid' => false,
        'status' => 'requires_action',
        'code' => 'authentication_required',
        'paymentMethodId' => $payment_method_id,
    ], 402);
}

if ($intent_status === 'processing') {
    payment_check_response([
        'valid' => false,
        'status' => 'processing',
        'code' => 'verification_processing',
        'paymentMethodId' => $payment_method_id,
    ], 202);
}

payment_check_response([
    'valid' => false,
    'status' => 'declined',
    'code' => 'payment_method_declined',
    'paymentMethodId' => $payment_method_id,
], 402);