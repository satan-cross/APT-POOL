<?php
declare(strict_types=1);
/**
 * check_deposits.php — Deposit status polling endpoint (PayGate.to)
 *
 * Called by the deposit page JS every 20 seconds:
 *   GET /check_deposits.php?id=<deposit_id>
 *
 * With PayGate.to, deposits are confirmed via callback (pg_callback.php).
 * This endpoint simply reads the current DB status so the frontend can react
 * when the callback has credited the deposit.
 *
 * Returns JSON:
 *   { "status": "pending"|"confirmed"|"cancelled", "txid": string|null, "amount_crypto": string|null }
 */

// ── Bootstrap ─────────────────────────────────────────────────────────────────
foreach ([
    __DIR__ . '/init.php',
    __DIR__ . '/src/bootstrap.php',
] as $f) {
    if (file_exists($f)) { require_once $f; break; }
}

header('Content-Type: application/json');

// ── Auth ──────────────────────────────────────────────────────────────────────
if (empty($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}
$uid = (int)$_SESSION['user_id'];

// ── Load deposit ──────────────────────────────────────────────────────────────
$dep_id = (int)($_GET['id'] ?? 0);
if ($dep_id <= 0) {
    echo json_encode(['error' => 'Invalid deposit ID']);
    exit;
}

$pdo  = db();
$stmt = $pdo->prepare('SELECT * FROM deposits WHERE id = ? AND user_id = ?');
$stmt->execute([$dep_id, $uid]);
$dep  = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$dep) {
    echo json_encode(['error' => 'Deposit not found']);
    exit;
}

// ── Return current DB status ──────────────────────────────────────────────────
// PayGate confirms via GET callback (pg_callback.php) which writes confirmed status to DB.
// We simply report the current state — the frontend JS polls this until it sees "confirmed".
echo json_encode([
    'status'        => $dep['status'],
    'txid'          => $dep['txid'] ?? null,
    'amount_crypto' => $dep['cp_amount_crypto'] ?? null,
    'address'       => $dep['deposit_address'] ?? null,
]);
