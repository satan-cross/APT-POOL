<?php
declare(strict_types=1);
/**
 * pg_callback.php — PayGate.to Payment Callback Endpoint
 *
 * PayGate sends a GET request to this URL when a crypto payment is confirmed.
 * It includes our original query parameters plus:
 *   value_coin  — amount paid in crypto
 *   coin        — coin ticker (e.g. "btc", "erc20_usdt", "trc20_usdt")
 *   txid_in     — blockchain transaction ID of the customer → receiving wallet tx
 *
 * Our callback URL format:
 *   https://site.com/pg_callback.php?dep_id=123&uid=456&token=<hmac>
 *
 * Response must be plain text "ok" to suppress repeated callbacks.
 */

// ── Bootstrap ──────────────────────────────────────────────────────────────────
foreach ([
    __DIR__ . '/init.php',               // legacy flat layout
    __DIR__ . '/src/bootstrap.php',      // new src/ layout
] as $f) {
    if (file_exists($f)) { require_once $f; break; }
}

header('Content-Type: text/plain');

// ── Extract and validate parameters ──────────────────────────────────────────
$dep_id = (int)($_GET['dep_id'] ?? 0);
$uid    = (int)($_GET['uid']    ?? 0);
$token  = (string)($_GET['token'] ?? '');

if ($dep_id <= 0 || $uid <= 0 || $token === '') {
    echo 'bad_request';
    exit;
}

// ── Verify HMAC token (prevents spoofed callbacks) ────────────────────────────
$secret        = get_setting('pg_callback_secret', '');
$expected      = hash_hmac('sha256', 'dep_' . $dep_id . '_uid_' . $uid, $secret);
if (!hash_equals($expected, $token)) {
    error_log('[pg_callback] Invalid HMAC token for dep #' . $dep_id);
    echo 'invalid_token';
    exit;
}

// ── Load deposit ──────────────────────────────────────────────────────────────
$pdo  = db();
$stmt = $pdo->prepare('SELECT * FROM deposits WHERE id = ? AND user_id = ?');
$stmt->execute([$dep_id, $uid]);
$dep  = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$dep) {
    error_log('[pg_callback] Deposit not found: dep_id=' . $dep_id . ' uid=' . $uid);
    echo 'not_found';
    exit;
}

// Already confirmed — idempotent response
if ($dep['status'] === 'confirmed') {
    echo 'ok';
    exit;
}

// ── Extract PayGate transaction data ─────────────────────────────────────────
$value_coin  = (string)($_GET['value_coin']  ?? '');
$coin_ticker = (string)($_GET['coin']        ?? '');
$txid_in     = (string)($_GET['txid_in']     ?? '');

error_log('[pg_callback] Payment received — dep #' . $dep_id . ' uid=' . $uid
    . ' coin=' . $coin_ticker . ' value=' . $value_coin . ' txid=' . $txid_in);

// ── Confirm the deposit and credit user balance ───────────────────────────────
try {
    $pdo->beginTransaction();

    $pdo->prepare(
        "UPDATE deposits SET status='confirmed', txid=?, confirmed_at=?, cp_amount_crypto=? WHERE id=? AND status='pending'"
    )->execute([
        $txid_in ?: null,
        time(),
        $value_coin ?: $dep['cp_amount_crypto'],
        $dep_id,
    ]);

    if ($pdo->rowCount() > 0) {
        // Only credit if we actually flipped the row (race-safe)
        $pdo->prepare('UPDATE users SET balance = balance + ? WHERE id = ?')
            ->execute([(float)$dep['amount'], $uid]);

        error_log('[pg_callback] Deposit #' . $dep_id . ' confirmed — $' . $dep['amount'] . ' credited to user #' . $uid);
    }

    $pdo->commit();
    echo 'ok';
} catch (\Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[pg_callback] DB error for dep #' . $dep_id . ': ' . $e->getMessage());
    echo 'db_error';
}
