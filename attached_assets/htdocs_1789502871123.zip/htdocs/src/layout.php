<?php
declare(strict_types=1);

function render_layout(string $page, string $body_html): void {
    $user   = current_user();
    $flashes = flash_pop();
    $current = current_page();
    $cart_n = 0;

    $nav = [
        ['page'=>'dashboard',    'label'=>'Dashboard',   'icon'=>'<svg viewBox="0 0 16 16" fill="currentColor"><path d="M2 2h5v5H2zm7 0h5v5H9zm-7 7h5v5H2zm7 0h5v5H9z"/></svg>'],
        ['page'=>'marketplace',  'label'=>'Shop Cards',  'icon'=>'<svg viewBox="0 0 16 16" fill="currentColor"><path d="M1 3a1 1 0 011-1h12a1 1 0 011 1v2H1V3zm0 4h14v6a1 1 0 01-1 1H2a1 1 0 01-1-1V7zm3 2v1h4V9H4z"/></svg>'],
        ['page'=>'cart',         'label'=>'Cart',        'icon'=>'<svg viewBox="0 0 16 16" fill="currentColor"><path d="M0 1.5A.5.5 0 01.5 1H2a.5.5 0 01.485.379L2.89 3H14.5a.5.5 0 01.491.592l-1.5 8A.5.5 0 0113 12H4a.5.5 0 01-.491-.408L1.01 3.607 .61 2H.5A.5.5 0 010 1.5zm3.102 3l1.313 7H12.9l1.313-7H3.102zM5 12a2 2 0 100 4 2 2 0 000-4zm7 0a2 2 0 100 4 2 2 0 000-4z"/></svg>', 'badge'=>$cart_n],
        ['page'=>'orders',       'label'=>'Orders',      'icon'=>'<svg viewBox="0 0 16 16" fill="currentColor"><path d="M5.5 5.5A.5.5 0 016 5h4a.5.5 0 01.5.5v7a.5.5 0 01-.5.5H6a.5.5 0 01-.5-.5v-7zm.5.5v6h3V6H6z"/><path d="M14 4.5V14a2 2 0 01-2 2H4a2 2 0 01-2-2V2a2 2 0 012-2h5.5L14 4.5zm-3 0A1.5 1.5 0 019.5 3V1H4a1 1 0 00-1 1v12a1 1 0 001 1h8a1 1 0 001-1V4.5h-2z"/></svg>'],
        ['page'=>'deposit',      'label'=>'Deposit',     'icon'=>'<svg viewBox="0 0 16 16" fill="currentColor"><path d="M1 3a1 1 0 011-1h12a1 1 0 011 1v2H1V3zm0 4h14v6a1 1 0 01-1 1H2a1 1 0 01-1-1V7zm3 2v1h4V9H4z"/></svg>'],
        ['page'=>'support',      'label'=>'Support',     'icon'=>'<svg viewBox="0 0 16 16" fill="currentColor"><path d="M8 1a5 5 0 00-5 5v1H2a1 1 0 00-1 1v3a1 1 0 001 1h1a5 5 0 0010 0h1a1 1 0 001-1V8a1 1 0 00-1-1h-1V6a5 5 0 00-5-5z"/></svg>'],
    ];
    $nav[1]['label'] = 'Shop';
    $nav = array_values(array_filter($nav, fn(array $item): bool =>
        in_array($item['page'], ['dashboard', 'marketplace', 'deposit', 'support'], true)
    ));

    $seller_nav = [
        ['page'=>'seller',   'label'=>'My Inventory', 'icon'=>'<svg viewBox="0 0 16 16" fill="currentColor"><path d="M1 2.5A1.5 1.5 0 012.5 1h3A1.5 1.5 0 017 2.5v3A1.5 1.5 0 015.5 7h-3A1.5 1.5 0 011 5.5v-3zM2.5 2a.5.5 0 00-.5.5v3a.5.5 0 00.5.5h3a.5.5 0 00.5-.5v-3a.5.5 0 00-.5-.5h-3zm6.5.5A1.5 1.5 0 0110.5 1h3A1.5 1.5 0 0115 2.5v3A1.5 1.5 0 0113.5 7h-3A1.5 1.5 0 019 5.5v-3zm1.5-.5a.5.5 0 00-.5.5v3a.5.5 0 00.5.5h3a.5.5 0 00.5-.5v-3a.5.5 0 00-.5-.5h-3zM1 10.5A1.5 1.5 0 012.5 9h3A1.5 1.5 0 017 10.5v3A1.5 1.5 0 015.5 15h-3A1.5 1.5 0 011 13.5v-3zM2.5 10a.5.5 0 00-.5.5v3a.5.5 0 00.5.5h3a.5.5 0 00.5-.5v-3a.5.5 0 00-.5-.5h-3z"/></svg>'],
    ];

    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BytePool</title><link rel="stylesheet" href="/assets/app.css"></head><body>';
    echo '<div class="shell">';

    if ($user) {
        echo '<aside class="sidebar">';
        echo '<div class="logo"><div class="logo-icon">BP</div><div><div class="logo-name">BytePool</div><div class="logo-sub">Crypto Mining Pool</div></div></div>';

        echo '<span class="nav-section">Workspace</span>';
        foreach ($nav as $n) {
            $active = $current === $n['page'] ? ' active' : '';
            $badge  = !empty($n['badge']) && $n['badge'] > 0 ? '<span class="nav-badge">' . $n['badge'] . '</span>' : '';
            echo '<a href="/?p=' . $n['page'] . '" class="nav-link' . $active . '">' . $n['icon'] . h($n['label']) . $badge . '</a>';
        }

        if (false) {
            echo '<span class="nav-section">Seller</span>';
            foreach ($seller_nav as $n) {
                $active = $current === $n['page'] ? ' active' : '';
                echo '<a href="/?p=' . $n['page'] . '" class="nav-link' . $active . '">' . $n['icon'] . h($n['label']) . '</a>';
            }
        } elseif (false) {
            echo '<div class="sidebar-sep"></div>';
            echo '<a href="/?p=become_seller" class="nav-link' . ($current==='become_seller'?' active':'') . '"><svg viewBox="0 0 16 16" fill="currentColor" style="width:14px;height:14px"><path d="M8 2a.5.5 0 01.5.5v5h5a.5.5 0 010 1h-5v5a.5.5 0 01-1 0v-5h-5a.5.5 0 010-1h5v-5A.5.5 0 018 2z"/></svg>Become Seller</a>';
        }

        if ($user['role'] === 'admin') {
            echo '<div class="sidebar-sep"></div>';
            echo '<span class="nav-section">Admin</span>';
            echo '<a href="/?p=admin" class="nav-link' . ($current==='admin'?' active':'') . '"><svg viewBox="0 0 16 16" fill="currentColor" style="width:14px;height:14px"><path d="M8 1a2 2 0 012 2v4H6V3a2 2 0 012-2zm3 6V3a3 3 0 00-6 0v4a2 2 0 00-2 2v5a2 2 0 002 2h6a2 2 0 002-2V9a2 2 0 00-2-2z"/></svg>Admin Panel</a>';
        }
        echo '<div class="sidebar-spacer"></div>';
        echo '<div class="user-block">';
        echo '<div class="user-name">' . h($user['username']) . '</div>';
        echo '<div class="user-balance">$' . number_format((float)$user['balance'], 2) . '</div>';
        echo '<div class="user-role">' . h($user['role']) . '</div>';
        echo '</div>';
        echo '<div class="sidebar-sep"></div>';
        echo '<a href="/?p=login&action=logout" class="nav-link"><svg viewBox="0 0 16 16" fill="currentColor" style="width:14px;height:14px"><path fill-rule="evenodd" d="M6 3.5a.5.5 0 01.5-.5h5a.5.5 0 01.5.5v9a.5.5 0 01-.5.5h-5a.5.5 0 010-1H11V4H6.5a.5.5 0 01-.5-.5zm2.354 2.646a.5.5 0 010 .708L7.207 8l1.147 1.146a.5.5 0 01-.708.708l-1.5-1.5a.5.5 0 010-.708l1.5-1.5a.5.5 0 01.708 0z"/><path fill-rule="evenodd" d="M1 8a.5.5 0 01.5-.5H8.5a.5.5 0 010 1H1.5A.5.5 0 011 8z"/></svg>Sign Out</a>';
        echo '</aside>';
    }

    echo '<main class="main"><div class="main-inner">';

    // Global shop-closed banner (non-admin users)
    if ($user && $user['role'] !== 'admin' && !shop_is_open()) {
        $reason = get_setting('shop_closed_reason', '');
        echo '<div style="display:flex;align-items:center;gap:10px;padding:11px 16px;background:rgba(219,20,60,.1);border:1px solid rgba(219,20,60,.35);border-radius:var(--r-md);margin-bottom:16px">';
        echo '<span class="dot dot-red" style="animation:pulse 1s infinite;flex-shrink:0"></span>';
        echo '<div><span style="font-weight:700;color:var(--red);font-size:12.5px">Shop Temporarily Closed</span>';
        if ($reason) echo '<span class="text-dim text-xs" style="margin-left:8px">— ' . h($reason) . '</span>';
        echo '</div></div>';
    }

    // Flash messages
    foreach ($flashes as $f) {
        $cls = match($f['type']) { 'success'=>'alert-success','error'=>'alert-error', default=>'alert-info' };
        echo '<div class="alert ' . $cls . '" data-auto-dismiss>' . h($f['msg']) . '</div>';
    }

    echo $body_html;
    echo '</div></main></div>';
    echo '<script src="/assets/app.js"></script></body></html>';
}

function get_cart_count_fast(): int {
    try {
        $pdo = db();
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM cart_items WHERE user_id=? AND reserved_until>?');
        $stmt->execute([$_SESSION['user_id'], time()]);
        return (int)$stmt->fetchColumn();
    } catch (Exception) { return 0; }
}
