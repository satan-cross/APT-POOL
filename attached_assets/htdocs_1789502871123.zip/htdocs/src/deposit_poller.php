<?php
declare(strict_types=1);
/**
 * deposit_poller.php — Shared deposit-sweep logic.
 *
 * Included by:
 *   scripts/poll_deposits.php  — CLI background loop
 *   public/cron.php            — HTTP endpoint for external cron services
 *
 * APIs used (no key required):
 *   BTC / BTC_SEGWIT → Blockstream.info (primary) + BlockCypher (fallback)
 *   LTC              → BlockCypher
 *   USDT_TRC20       → TronGrid public endpoint
 *   XMR              → manual admin confirmation only (skipped)
 */

const REQUIRED_CONFIRMS = 1;
const CHECK_COOLDOWN    = 55; // min seconds between re-checks of the same deposit

// ─────────────────────────────────────────────────────────────────────────────
function sweep_pending_deposits(callable $log): void {
    $pdo = db();
    $now = time();

    $stmt = $pdo->query("
        SELECT * FROM deposits
        WHERE  status = 'pending'
          AND  deposit_address IS NOT NULL
          AND  deposit_address != ''
          AND  method != 'XMR'
        ORDER  BY created_at ASC
        LIMIT  100
    ");
    $pending = $stmt->fetchAll();

    if (empty($pending)) return;

    $log('Sweeping ' . count($pending) . ' pending deposit(s)…');

    set_setting('poller_last_run',      (string)$now);
    set_setting('poller_pending_count', (string)count($pending));

    foreach ($pending as $dep) {
        $dep_id = (int)$dep['id'];

        // Rate-limit: don't hammer the same deposit repeatedly
        $rl_key = "poller_rl_{$dep_id}";
        $last   = (int)get_setting($rl_key, '0');
        if ($now - $last < CHECK_COOLDOWN) continue;
        set_setting($rl_key, (string)$now);

        $result = check_deposit_on_chain($dep, $log);

        if ($result['confirmations'] >= REQUIRED_CONFIRMS && $result['status'] === 'found') {
            $pdo->beginTransaction();
            try {
                $pdo->prepare('UPDATE users SET balance = balance + ? WHERE id = ?')
                    ->execute([$dep['amount'], $dep['user_id']]);
                $pdo->prepare(
                    "UPDATE deposits SET status='confirmed', txid=?, confirmations=?, confirmed_at=? WHERE id=?"
                )->execute([$result['txid'], $result['confirmations'], $now, $dep_id]);
                $pdo->commit();
                $log("✓ CONFIRMED deposit #{$dep_id} | {$dep['method']} | \${$dep['amount']}"
                    . " → user #{$dep['user_id']}"
                    . ($result['txid'] ? ' | txid=' . substr($result['txid'], 0, 20) . '…' : ''));
            } catch (\Throwable $e) {
                $pdo->rollBack();
                $log("ERROR confirming #{$dep_id}: " . $e->getMessage());
            }
        } elseif ($result['confirmations'] > 0) {
            $pdo->prepare('UPDATE deposits SET confirmations=?, txid=? WHERE id=?')
                ->execute([$result['confirmations'], $result['txid'], $dep_id]);
            $log("⏳ Deposit #{$dep_id} {$result['confirmations']}/" . REQUIRED_CONFIRMS . " confirms");
        } else {
            $log("  ○ Deposit #{$dep_id} ({$dep['method']}) → {$result['status']}");
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
function check_deposit_on_chain(array $dep, callable $log): array {
    $method  = $dep['method'];
    $address = $dep['deposit_address'];
    $amount  = (float)$dep['amount'];

    try {
        return match(true) {
            in_array($method, ['BTC', 'BTC_SEGWIT'], true) => check_btc($address),
            $method === 'LTC'                              => check_blockcypher($address, 'ltc/main'),
            $method === 'USDT_TRC20'                       => check_trongrid($address, $amount),
            default => ['status' => 'unsupported', 'confirmations' => 0, 'txid' => null],
        };
    } catch (\Throwable $e) {
        $log("  API error for #{$dep['id']}: " . $e->getMessage());
        return ['status' => 'api_error', 'confirmations' => 0, 'txid' => null];
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Bitcoin: Blockstream.info (primary, no rate limit) + BlockCypher fallback
// ─────────────────────────────────────────────────────────────────────────────
function check_btc(string $address): array {
    $raw = poller_http_fetch("https://blockstream.info/api/address/{$address}/txs");
    if ($raw !== false) {
        $txs = json_decode($raw, true);
        if (is_array($txs)) {
            foreach ($txs as $tx) {
                foreach (($tx['vout'] ?? []) as $vout) {
                    if (($vout['scriptpubkey_address'] ?? '') !== $address) continue;
                    $confirmed = $tx['status']['confirmed'] ?? false;
                    $confirms  = $confirmed ? 1 : 0;
                    if ($confirmed && isset($tx['status']['block_height'])) {
                        $tip_raw = @poller_http_fetch('https://blockstream.info/api/blocks/tip/height');
                        if ($tip_raw !== false) {
                            $tip = (int)trim($tip_raw);
                            $bh  = (int)$tx['status']['block_height'];
                            if ($tip > 0 && $bh > 0) $confirms = $tip - $bh + 1;
                        }
                    }
                    return ['status' => 'found', 'confirmations' => $confirms, 'txid' => $tx['txid'] ?? null];
                }
            }
            return ['status' => 'not_found', 'confirmations' => 0, 'txid' => null];
        }
    }
    return check_blockcypher($address, 'btc/main');
}

// ─────────────────────────────────────────────────────────────────────────────
// BlockCypher (BTC legacy / LTC)
// ─────────────────────────────────────────────────────────────────────────────
function check_blockcypher(string $address, string $chain): array {
    $url  = "https://api.blockcypher.com/v1/{$chain}/addrs/" . urlencode($address) . "?unspentOnly=false&limit=50";
    $raw  = poller_http_fetch($url);
    if ($raw === false) throw new \RuntimeException("BlockCypher unreachable");
    $data = json_decode($raw, true);
    if (!is_array($data)) throw new \RuntimeException("BlockCypher bad JSON");

    if (!isset($data['txrefs']) && !isset($data['unconfirmed_txrefs'])) {
        return ['status' => 'not_found', 'confirmations' => 0, 'txid' => null];
    }

    $txrefs = array_merge($data['txrefs'] ?? [], $data['unconfirmed_txrefs'] ?? []);
    foreach ($txrefs as $tx) {
        if (($tx['tx_input_n'] ?? 0) === -1) {
            return [
                'status'        => 'found',
                'confirmations' => (int)($tx['confirmations'] ?? 0),
                'txid'          => $tx['tx_hash'] ?? null,
            ];
        }
    }
    return ['status' => 'not_found', 'confirmations' => 0, 'txid' => null];
}

// ─────────────────────────────────────────────────────────────────────────────
// TronGrid: USDT TRC20 (USDT contract: TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t)
// ─────────────────────────────────────────────────────────────────────────────
function check_trongrid(string $address, float $expected_usdt): array {
    $CONTRACT = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';
    $url  = "https://api.trongrid.io/v1/accounts/{$address}/transactions/trc20"
          . "?limit=20&contract_address={$CONTRACT}";
    $raw  = poller_http_fetch($url);
    if ($raw === false) throw new \RuntimeException("TronGrid unreachable");
    $data = json_decode($raw, true);
    if (!isset($data['data']) || !is_array($data['data'])) {
        return ['status' => 'not_found', 'confirmations' => 0, 'txid' => null];
    }

    $expected_sun = (int)round($expected_usdt * 1e6);
    $tolerance    = max(1000, (int)($expected_sun * 0.01));

    foreach ($data['data'] as $tx) {
        if (($tx['to'] ?? '') !== $address) continue;
        $val = (int)($tx['value'] ?? 0);
        if (abs($val - $expected_sun) <= $tolerance) {
            $confirms = isset($tx['block_timestamp']) ? 1 : 0;
            return ['status' => 'found', 'confirmations' => $confirms, 'txid' => $tx['transaction_id'] ?? null];
        }
    }
    return ['status' => 'not_found', 'confirmations' => 0, 'txid' => null];
}

// ─────────────────────────────────────────────────────────────────────────────
function poller_http_fetch(string $url): string|false {
    $ctx = stream_context_create(['http' => [
        'method'        => 'GET',
        'timeout'       => 10,
        'ignore_errors' => true,
        'header'        => "User-Agent: BytePool/1.0\r\nAccept: application/json",
    ]]);
    return @file_get_contents($url, false, $ctx);
}
