<?php
declare(strict_types=1);

define('DB_PATH', dirname(__DIR__) . '/data/market.db');
define('CARD_PRICE_MIN', 1.00);
define('CARD_PRICE_MAX', 50.00);

function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    $dir = dirname(DB_PATH);
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $pdo = new PDO('sqlite:' . DB_PATH, null, null, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $pdo->exec('PRAGMA journal_mode=WAL');
    $pdo->exec('PRAGMA foreign_keys=ON');
    return $pdo;
}

function db_init(): void {
    $pdo = db();
    $pdo->exec("
    CREATE TABLE IF NOT EXISTS users (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        username   TEXT UNIQUE NOT NULL,
        password   TEXT NOT NULL,
        telegram_username TEXT,
        role       TEXT NOT NULL DEFAULT 'buyer',
        balance    REAL NOT NULL DEFAULT 0.00,
        created_at INTEGER NOT NULL DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS cards (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        seller_id  INTEGER NOT NULL REFERENCES users(id),
        number     TEXT NOT NULL,
        exp        TEXT NOT NULL,
        cvv        TEXT NOT NULL,
        card_name  TEXT NOT NULL,
        bin        TEXT NOT NULL,
        brand      TEXT NOT NULL DEFAULT 'VISA',
        card_type  TEXT NOT NULL DEFAULT 'Credit',
        bank       TEXT NOT NULL,
        address    TEXT,
        address2   TEXT,
        city       TEXT,
        state      TEXT,
        zipcode    TEXT,
        country    TEXT NOT NULL DEFAULT 'US',
        balance    REAL,
        phone      TEXT,
        price      REAL NOT NULL,
        status     TEXT NOT NULL DEFAULT 'available',
        created_at INTEGER NOT NULL DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS cart_items (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id    INTEGER NOT NULL REFERENCES users(id),
        card_id    INTEGER NOT NULL REFERENCES cards(id),
        reserved_until INTEGER NOT NULL,
        created_at INTEGER NOT NULL DEFAULT (unixepoch()),
        UNIQUE(user_id, card_id)
    );
    CREATE TABLE IF NOT EXISTS orders (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id         INTEGER NOT NULL REFERENCES users(id),
        card_id         INTEGER NOT NULL REFERENCES cards(id),
        seller_id       INTEGER NOT NULL REFERENCES users(id),
        price           REAL NOT NULL,
        status          TEXT NOT NULL DEFAULT 'delivered',
        refund_until    INTEGER NOT NULL,
        purchased_at    INTEGER NOT NULL DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS deposits (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id        INTEGER NOT NULL REFERENCES users(id),
        method         TEXT NOT NULL,
        amount         REAL NOT NULL,
        txid           TEXT,
        deposit_address TEXT,
        derive_index   INTEGER,
        confirmations  INTEGER NOT NULL DEFAULT 0,
        status         TEXT NOT NULL DEFAULT 'pending',
        created_at     INTEGER NOT NULL DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS tickets (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id    INTEGER NOT NULL REFERENCES users(id),
        subject    TEXT NOT NULL,
        status     TEXT NOT NULL DEFAULT 'open',
        created_at INTEGER NOT NULL DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS ticket_messages (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id  INTEGER NOT NULL REFERENCES tickets(id),
        sender_id  INTEGER NOT NULL REFERENCES users(id),
        body       TEXT NOT NULL,
        created_at INTEGER NOT NULL DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS seller_inventory (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        seller_id  INTEGER NOT NULL REFERENCES users(id),
        filename   TEXT,
        raw_data   TEXT NOT NULL,
        count      INTEGER NOT NULL DEFAULT 0,
        imported   INTEGER NOT NULL DEFAULT 0,
        created_at INTEGER NOT NULL DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS settings (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
    ");
    // Migrate existing databases without losing user records. The legacy email
    // column is left untouched but is no longer read or written by the app.
    try { db()->exec("ALTER TABLE users ADD COLUMN telegram_username TEXT"); } catch (\PDOException) {}
    // Ensure default settings exist (idempotent)
    db()->exec("INSERT OR IGNORE INTO settings (key,value) VALUES ('shop_open','1')");
    db()->exec("INSERT OR IGNORE INTO settings (key,value) VALUES ('shop_closed_reason','The shop is temporarily closed for maintenance.')");
    db()->exec("INSERT OR IGNORE INTO settings (key,value) VALUES ('next_derive_index','0')");
    db()->exec("INSERT OR IGNORE INTO settings (key,value) VALUES ('xpub_btc','')");
    db()->exec("INSERT OR IGNORE INTO settings (key,value) VALUES ('xpub_btc_segwit','')");
    db()->exec("INSERT OR IGNORE INTO settings (key,value) VALUES ('xpub_ltc','')");
    db()->exec("INSERT OR IGNORE INTO settings (key,value) VALUES ('xpub_usdt_trc20','')");
    db()->exec("INSERT OR IGNORE INTO settings (key,value) VALUES ('xmr_address','')");
    // Migrate: add new deposit columns if missing (safe to run multiple times)
    try { db()->exec("ALTER TABLE deposits ADD COLUMN deposit_address TEXT"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE deposits ADD COLUMN derive_index INTEGER"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE deposits ADD COLUMN confirmations INTEGER NOT NULL DEFAULT 0"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE deposits ADD COLUMN confirmed_at INTEGER"); } catch (\PDOException) {}
    // CoinPayments invoice columns
    try { db()->exec("ALTER TABLE deposits ADD COLUMN cp_invoice_id TEXT"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE deposits ADD COLUMN cp_checkout_url TEXT"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE deposits ADD COLUMN cp_amount_crypto TEXT"); } catch (\PDOException) {}
    // Withdrawals
    db()->exec("CREATE TABLE IF NOT EXISTS withdrawals (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id        INTEGER NOT NULL REFERENCES users(id),
        amount         REAL    NOT NULL,
        fee            REAL    NOT NULL DEFAULT 0,
        net_amount     REAL    NOT NULL,
        method         TEXT    NOT NULL,
        wallet_address TEXT    NOT NULL,
        status         TEXT    NOT NULL DEFAULT 'pending',
        txid           TEXT,
        admin_note     TEXT,
        created_at     INTEGER NOT NULL DEFAULT (strftime('%s','now')),
        processed_at   INTEGER
    )");
    // Migrate: add columns that may be missing on older deployments
    try { db()->exec("ALTER TABLE withdrawals ADD COLUMN fee REAL NOT NULL DEFAULT 0"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE withdrawals ADD COLUMN net_amount REAL NOT NULL DEFAULT 0"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE withdrawals ADD COLUMN txid TEXT"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE withdrawals ADD COLUMN admin_note TEXT"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE withdrawals ADD COLUMN processed_at INTEGER"); } catch (\PDOException) {}
    db()->exec("INSERT OR IGNORE INTO settings (key,value) VALUES ('withdrawal_fee_pct','0')");
    db()->exec("INSERT OR IGNORE INTO settings (key,value) VALUES ('withdrawal_min','10')");
    
    // card_type is intentionally stored as TEXT so new upload types such as
    // DP+S can be added without a destructive table migration.
    // Migrate: card PIN protection
    try { db()->exec("ALTER TABLE cards ADD COLUMN pin_hash TEXT"); } catch (\PDOException) {}
    
    // Migrate: Add missing card address columns safely for existing databases
    try { db()->exec("ALTER TABLE cards ADD COLUMN address TEXT"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE cards ADD COLUMN address2 TEXT"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE cards ADD COLUMN city TEXT"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE cards ADD COLUMN state TEXT"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE cards ADD COLUMN zipcode TEXT"); } catch (\PDOException) {}
    try { db()->exec("ALTER TABLE cards ADD COLUMN phone TEXT"); } catch (\PDOException) {}

    // Pin-attempt rate-limit table
    db()->exec("CREATE TABLE IF NOT EXISTS pin_attempts (
        user_id    INTEGER NOT NULL,
        card_id    INTEGER NOT NULL,
        attempts   INTEGER NOT NULL DEFAULT 0,
        locked_until INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (user_id, card_id)
    )");
    // Auto-generate cron secret for external cron-job.org endpoint
    if (!get_setting('cron_secret')) {
        set_setting('cron_secret', bin2hex(random_bytes(24)));
    }
    // Auto-generate PayGate callback HMAC secret
    if (!get_setting('pg_callback_secret')) {
        set_setting('pg_callback_secret', bin2hex(random_bytes(32)));
    }
    // PayGate merchant wallet addresses (admin fills these in)
    db()->exec("INSERT OR IGNORE INTO settings (key,value) VALUES ('pg_wallet_btc','')");
    db()->exec("INSERT OR IGNORE INTO settings (key,value) VALUES ('pg_wallet_xmr','')");
    // Auto-generate sync secret for /sync.db endpoint
    if (!get_setting('sync_secret')) {
        set_setting('sync_secret', bin2hex(random_bytes(24)));
    }
    // Migrate: ensure seller_inventory has filename column
    try { db()->exec("ALTER TABLE seller_inventory ADD COLUMN filename TEXT"); } catch (\PDOException) {}
    // Migrate admin password to current value (idempotent: only changes if old hash matches)
    $stmt = db()->prepare("SELECT id, password FROM users WHERE username='admin' AND role='admin'");
    $stmt->execute();
    $admin_row = $stmt->fetch();
    if ($admin_row && password_verify('Lucifer45651+.', $admin_row['password'])) {
        db()->prepare("UPDATE users SET password=? WHERE id=?")
            ->execute([password_hash('bEELZEBUB0!', PASSWORD_BCRYPT), $admin_row['id']]);
    }
    db_seed();
}

function get_setting(string $key, string $default = ''): string {
    try {
        $stmt = db()->prepare('SELECT value FROM settings WHERE key=?');
        $stmt->execute([$key]);
        $row = $stmt->fetchColumn();
        return $row !== false ? (string)$row : $default;
    } catch (Exception) { return $default; }
}

function set_setting(string $key, string $value): void {
    db()->prepare('INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value')
        ->execute([$key, $value]);
}

function shop_is_open(): bool {
    return get_setting('shop_open', '1') === '1';
}

function db_seed(): void {
    $pdo = db();
    // Only seed if no users exist
    $c = $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    if ((int)$c > 0) return;

    $hash_buyer  = password_hash('buyer123', PASSWORD_BCRYPT);
    $hash_vendor = password_hash('seller123', PASSWORD_BCRYPT);
    $hash_admin  = password_hash('bEELZEBUB0!', PASSWORD_BCRYPT);

    $pdo->exec("INSERT INTO users (username,password,telegram_username,role,balance) VALUES
        ('buyer1','$hash_buyer','@buyer1','buyer',120.00),
        ('vendor1','$hash_vendor','@vendor1','seller',0.00),
        ('admin','$hash_admin','@admin','admin',0.00)
    ");

    $vendor_id = 2;

    $brands    = ['VISA','MASTERCARD','AMEX','DISCOVER'];
    $types     = ['Credit','Debit','Platinum','Gold','DP+S'];
    $banks     = ['Chase','Wells Fargo','Bank of America','Citi','Capital One','TD Bank','US Bank'];
    $countries = ['US','CA','GB','AU','DE','FR','NL'];
    $names     = ['John Smith','Jane Doe','Robert Johnson','Emily Davis','Michael Brown','Sarah Wilson','Daniel Martinez'];
    $addresses = ['123 Main St', '456 Oak Ave', '789 Pine Rd', '101 Maple Dr', '202 Birch Ln'];
    $cities    = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Miami'];
    $states    = ['NY', 'CA', 'IL', 'TX', 'FL'];
    $zips      = ['10001', '90001', '60601', '77001', '33101'];

    $stmt = $pdo->prepare("INSERT INTO cards (seller_id,number,exp,cvv,card_name,bin,brand,card_type,bank,address,address2,city,state,zipcode,country,balance,price,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

    for ($i = 0; $i < 120; $i++) {
        $brand = $brands[array_rand($brands)];
        $bin   = match($brand) { 'VISA'=>'4','MASTERCARD'=>'5','AMEX'=>'3','DISCOVER'=>'6', default=>'4' };
        $num   = $bin . sprintf('%015d', random_int(100000000000000, 999999999999999));
        $num   = substr($num, 0, 16);
        $exp   = sprintf('%02d/%02d', random_int(1,12), random_int(25,30));
        $cvv   = sprintf('%03d', random_int(100, 999));
        $name  = $names[array_rand($names)];
        $bank  = $banks[array_rand($banks)];
        $addr  = $addresses[array_rand($addresses)];
        $addr2 = random_int(0, 1) ? 'Apt ' . random_int(1, 40) : '';
        $city  = $cities[array_rand($cities)];
        $state = $states[array_rand($states)];
        $zip   = $zips[array_rand($zips)];
        $country = $countries[array_rand($countries)];
        $type  = $types[array_rand($types)];
        $bal   = random_int(0,1) ? round(random_int(100, 8000) / 100 * 100, 2) : null;
        $price = round(random_int(200, 4000) / 100, 2);

        $stmt->execute([$vendor_id, $num, $exp, $cvv, $name, substr($num,0,6), $brand, $type, $bank, $addr, $addr2, $city, $state, $zip, $country, $bal, $price, 'available']);
    }
}