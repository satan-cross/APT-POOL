<?php
declare(strict_types=1);
/**
 * crypto.php — Self-hosted HD wallet address derivation
 *
 * Security model: server stores ONLY extended public keys (xpub/zpub/tpub).
 * Private keys NEVER touch the server. Funds are swept offline.
 *
 * Supports:
 *  - Bitcoin  P2PKH  (xpub → 1… addresses)
 *  - Bitcoin  P2WPKH (zpub → bc1q… bech32 native SegWit) ← recommended
 *  - Litecoin P2PKH  (Ltub/xpub → L… addresses)
 *  - USDT TRC20      (xpub → T… Tron addresses, same secp256k1 key derivation)
 *
 * Requires PHP extensions: gmp, hash (with sha256/ripemd160), openssl
 */

// ══════════════════════════════════════════════════════════
// secp256k1 constants (GMP objects created lazily)
// ══════════════════════════════════════════════════════════

function _secp_p(): \GMP { static $v; return $v ??= gmp_init('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F', 16); }
function _secp_n(): \GMP { static $v; return $v ??= gmp_init('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141', 16); }
function _secp_Gx(): \GMP { static $v; return $v ??= gmp_init('79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798', 16); }
function _secp_Gy(): \GMP { static $v; return $v ??= gmp_init('483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8', 16); }

// Point at infinity marker
const EC_INF = null;

// ══════════════════════════════════════════════════════════
// EC point arithmetic (affine coordinates, GMP)
// ══════════════════════════════════════════════════════════

function ec_add(?array $P, ?array $Q): ?array {
    if ($P === EC_INF) return $Q;
    if ($Q === EC_INF) return $P;
    $p = _secp_p();
    [$Px, $Py] = $P;
    [$Qx, $Qy] = $Q;
    if (gmp_cmp($Px, $Qx) === 0) {
        if (gmp_cmp($Py, $Qy) !== 0) return EC_INF; // P + (-P)
        return ec_double($P);
    }
    $num = gmp_mod(gmp_sub($Qy, $Py), $p);
    $den = gmp_invert(gmp_mod(gmp_sub($Qx, $Px), $p), $p);
    $s   = gmp_mod(gmp_mul($num, $den), $p);
    $Rx  = gmp_mod(gmp_sub(gmp_sub(gmp_mul($s, $s), $Px), $Qx), $p);
    $Ry  = gmp_mod(gmp_sub(gmp_mul($s, gmp_sub($Px, $Rx)), $Py), $p);
    if (gmp_sign($Rx) < 0) $Rx = gmp_add($Rx, $p);
    if (gmp_sign($Ry) < 0) $Ry = gmp_add($Ry, $p);
    return [$Rx, $Ry];
}

function ec_double(?array $P): ?array {
    if ($P === EC_INF) return EC_INF;
    $p = _secp_p();
    [$Px, $Py] = $P;
    if (gmp_cmp($Py, gmp_init(0)) === 0) return EC_INF;
    $num = gmp_mod(gmp_mul(gmp_mul(gmp_init(3), gmp_mul($Px, $Px)), gmp_invert(gmp_mod(gmp_mul(gmp_init(2), $Py), $p), $p)), $p);
    $Rx  = gmp_mod(gmp_sub(gmp_mul($num, $num), gmp_mul(gmp_init(2), $Px)), $p);
    $Ry  = gmp_mod(gmp_sub(gmp_mul($num, gmp_sub($Px, $Rx)), $Py), $p);
    if (gmp_sign($Rx) < 0) $Rx = gmp_add($Rx, $p);
    if (gmp_sign($Ry) < 0) $Ry = gmp_add($Ry, $p);
    return [$Rx, $Ry];
}

function ec_mul(\GMP $k, ?array $P): ?array {
    $R = EC_INF;
    $Q = $P;
    $n = _secp_n();
    $k = gmp_mod($k, $n);
    $bits = gmp_strval($k, 2);
    foreach (str_split($bits) as $bit) {
        $R = ec_double($R);
        if ($bit === '1') $R = ec_add($R, $Q);
    }
    return $R;
}

// ══════════════════════════════════════════════════════════
// Public key encoding / decoding
// ══════════════════════════════════════════════════════════

// Parse compressed public key bytes → [x GMP, y GMP]
function ec_decompress(string $compressed): ?array {
    if (strlen($compressed) !== 33) return null;
    $prefix = ord($compressed[0]);
    if ($prefix !== 2 && $prefix !== 3) return null;
    $p  = _secp_p();
    $x  = gmp_import(substr($compressed, 1, 32), 1, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
    $y2 = gmp_mod(gmp_add(gmp_add(gmp_mul(gmp_mul($x, $x), $x), gmp_mul(gmp_init(0), $x)), gmp_init(7)), $p);
    // Tonelli-Shanks sqrt: p ≡ 3 mod 4 so sqrt = y2^((p+1)/4) mod p
    $exp = gmp_div_q(gmp_add($p, gmp_init(1)), gmp_init(4));
    $y   = gmp_powm($y2, $exp, $p);
    if (gmp_cmp(gmp_mul($y, $y), $y2) !== 0 && gmp_cmp(gmp_mod(gmp_mul($y, $y), $p), $y2) !== 0) return null;
    $y_even = (gmp_intval(gmp_mod($y, gmp_init(2))) === 0);
    if (($prefix === 2) !== $y_even) $y = gmp_sub($p, $y);
    return [$x, $y];
}

// Compressed pubkey bytes from point
function ec_compress(array $point): string {
    [$x, $y] = $point;
    $prefix = (gmp_intval(gmp_mod($y, gmp_init(2))) === 0) ? "\x02" : "\x03";
    return $prefix . gmp_export($x, 32, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
}

// Uncompressed pubkey (04 || x || y) from point — for Tron/ETH
function ec_uncompressed(array $point): string {
    [$x, $y] = $point;
    return "\x04"
        . gmp_export($x, 32, GMP_MSW_FIRST | GMP_BIG_ENDIAN)
        . gmp_export($y, 32, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
}

// ══════════════════════════════════════════════════════════
// Base58 / Base58Check
// ══════════════════════════════════════════════════════════

const BASE58_ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

function base58_encode(string $data): string {
    $n = gmp_import($data, 1, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
    $b58 = '';
    while (gmp_cmp($n, gmp_init(0)) > 0) {
        [$n, $rem] = gmp_div_qr($n, gmp_init(58));
        $b58 = BASE58_ALPHABET[gmp_intval($rem)] . $b58;
    }
    foreach (str_split($data) as $byte) {
        if ($byte !== "\x00") break;
        $b58 = '1' . $b58;
    }
    return $b58;
}

function base58check_encode(string $payload): string {
    $checksum = substr(hash('sha256', hash('sha256', $payload, true), true), 0, 4);
    return base58_encode($payload . $checksum);
}

function base58_decode(string $s): string {
    $map = array_flip(str_split(BASE58_ALPHABET));
    $n = gmp_init(0);
    foreach (str_split($s) as $ch) {
        $n = gmp_add(gmp_mul($n, gmp_init(58)), gmp_init($map[$ch] ?? 0));
    }
    $bytes = ($n == 0) ? '' : gmp_export($n, 1, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
    foreach (str_split($s) as $ch) {
        if ($ch !== '1') break;
        $bytes = "\x00" . $bytes;
    }
    return $bytes;
}

function base58check_decode(string $s): ?string {
    $raw = base58_decode($s);
    if (strlen($raw) < 4) return null;
    $payload  = substr($raw, 0, -4);
    $checksum = substr($raw, -4);
    $expected = substr(hash('sha256', hash('sha256', $payload, true), true), 0, 4);
    return ($checksum === $expected) ? $payload : null;
}

// ══════════════════════════════════════════════════════════
// Bech32 (BIP173 — native SegWit P2WPKH)
// ══════════════════════════════════════════════════════════

const BECH32_CHARSET = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';

function bech32_polymod(array $values): int {
    $GEN = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
    $chk = 1;
    foreach ($values as $v) {
        $b = $chk >> 25;
        $chk = (($chk & 0x1ffffff) << 5) ^ $v;
        for ($i = 0; $i < 5; $i++) {
            if (($b >> $i) & 1) $chk ^= $GEN[$i];
        }
    }
    return $chk;
}

function bech32_hrp_expand(string $hrp): array {
    $out = [];
    foreach (str_split($hrp) as $c) $out[] = ord($c) >> 5;
    $out[] = 0;
    foreach (str_split($hrp) as $c) $out[] = ord($c) & 31;
    return $out;
}

function bech32_create_checksum(string $hrp, array $data): array {
    $values  = array_merge(bech32_hrp_expand($hrp), $data, [0, 0, 0, 0, 0, 0]);
    $polymod = bech32_polymod($values) ^ 1;
    $checksum = [];
    for ($i = 0; $i < 6; $i++) $checksum[] = ($polymod >> (5 * (5 - $i))) & 31;
    return $checksum;
}

function bech32_convert_bits(array $data, int $fromBits, int $toBits, bool $pad = true): array {
    $acc = 0; $bits = 0; $out = []; $maxv = (1 << $toBits) - 1;
    foreach ($data as $v) {
        $acc = ($acc << $fromBits) | $v;
        $bits += $fromBits;
        while ($bits >= $toBits) {
            $bits -= $toBits;
            $out[] = ($acc >> $bits) & $maxv;
        }
    }
    if ($pad && $bits > 0) $out[] = ($acc << ($toBits - $bits)) & $maxv;
    return $out;
}

function bech32_encode(string $hrp, array $data): string {
    $combined = array_merge($data, bech32_create_checksum($hrp, $data));
    $enc = $hrp . '1';
    foreach ($combined as $d) $enc .= BECH32_CHARSET[$d];
    return $enc;
}

// P2WPKH address from 20-byte hash160
function p2wpkh_address(string $hash160, string $hrp = 'bc'): string {
    $converted = bech32_convert_bits(array_values(unpack('C*', $hash160)), 8, 5);
    return bech32_encode($hrp, array_merge([0], $converted));
}

// ══════════════════════════════════════════════════════════
// Hash helpers
// ══════════════════════════════════════════════════════════

function hash256(string $data): string {
    return hash('sha256', hash('sha256', $data, true), true);
}

function hash160(string $data): string {
    return hash('ripemd160', hash('sha256', $data, true), true);
}

// ══════════════════════════════════════════════════════════
// Keccak-256 (for Tron/ETH address derivation)
// Standard SHA3 is NOT the same — this is the original Keccak
// ══════════════════════════════════════════════════════════

function keccak256(string $input): string {
    // Keccak-256: rate=1088 bits=136 bytes, capacity=512 bits
    static $RC = null;
    if ($RC === null) {
        // Round constants (64-bit, high bits may be set → negative PHP ints)
        $hexRC = [
            '0000000000000001','0000000000008082','800000000000808a','8000000080008000',
            '000000000000808b','0000000080000001','8000000080008081','8000000000008009',
            '000000000000008a','0000000000000088','0000000080008009','000000008000000a',
            '000000008000808b','800000000000008b','8000000000008089','8000000000008003',
            '8000000000008002','8000000000000080','000000000000800a','800000008000000a',
            '8000000080008081','8000000000008080','0000000080000001','8000000080008008',
        ];
        $RC = array_map(fn($h) => u64le($h), $hexRC);
    }

    static $ROT = [
        [0,36,3,41,18],[1,44,10,45,2],[62,6,43,15,61],[28,55,25,21,56],[27,20,39,8,14]
    ];

    $rate = 136; // bytes for Keccak-256
    // Padding (Keccak original, NOT SHA3)
    $msg = $input . "\x01";
    $msg .= str_repeat("\x00", ($rate - (strlen($msg) % $rate)) % $rate);
    $msg[strlen($msg) - 1] = chr(ord($msg[strlen($msg) - 1]) | 0x80);

    // State: 25 x 64-bit lanes stored as pairs [hi_int32, lo_int32] to avoid sign issues
    // Actually we use PHP 64-bit int directly, relying on bitwise ops being sign-agnostic
    $state = array_fill(0, 25, 0);

    $blocks = str_split($msg, $rate);
    foreach ($blocks as $block) {
        // XOR block into state (little-endian 64-bit lanes)
        $words = array_values(unpack('P*', str_pad($block, $rate, "\x00")));
        // P = little-endian unsigned 64-bit → stored as signed PHP int (bit pattern preserved)
        for ($i = 0; $i < count($words); $i++) {
            $state[$i] ^= $words[$i];
        }
        // 24 Keccak rounds
        for ($round = 0; $round < 24; $round++) {
            // Theta
            $C = [0,0,0,0,0];
            for ($x = 0; $x < 5; $x++)
                $C[$x] = $state[$x] ^ $state[$x+5] ^ $state[$x+10] ^ $state[$x+15] ^ $state[$x+20];
            $D = [0,0,0,0,0];
            for ($x = 0; $x < 5; $x++)
                $D[$x] = $C[($x+4)%5] ^ keccak_rot64($C[($x+1)%5], 1);
            for ($i = 0; $i < 25; $i++)
                $state[$i] ^= $D[$i % 5];
            // Rho + Pi
            $B = array_fill(0, 25, 0);
            for ($x = 0; $x < 5; $x++)
                for ($y = 0; $y < 5; $y++)
                    $B[$y*5 + ((2*$x+3*$y)%5)] = keccak_rot64($state[$x + 5*$y], $ROT[$x][$y]);
            // Chi
            for ($x = 0; $x < 5; $x++)
                for ($y = 0; $y < 5; $y++)
                    $state[$x+5*$y] = $B[$x+5*$y] ^ ((~$B[($x+1)%5+5*$y]) & $B[($x+2)%5+5*$y]);
            // Iota
            $state[0] ^= $RC[$round];
        }
    }

    // Squeeze: first 4 lanes = 32 bytes (little-endian)
    $out = '';
    for ($i = 0; $i < 4; $i++) {
        $out .= pack('P', $state[$i]);
    }
    return $out;
}

// Rotate 64-bit integer left by $n bits (PHP signed → bit-pattern correct)
function keccak_rot64(int $x, int $n): int {
    $n &= 63;
    if ($n === 0) return $x;
    $left  = $x << $n;
    $shift = 64 - $n;
    // Unsigned right shift: mask out sign-extended bits
    $right = ($x >> $shift) & (~(PHP_INT_MIN >> ($shift - 1)));
    return $left | $right;
}

// Parse hex round constant into PHP int (handles values > PHP_INT_MAX correctly)
function u64le(string $hex): int {
    // Convert hex big-endian to little-endian 64-bit int (as used in RC for direct XOR)
    // RC values are in big-endian order; we apply them as-is (not byteswapped)
    $hi = hexdec(substr($hex, 0, 8));
    $lo = hexdec(substr($hex, 8, 8));
    return ($hi << 32) | $lo;
}

// ══════════════════════════════════════════════════════════
// BIP32 extended key parsing and child derivation
// ══════════════════════════════════════════════════════════

// Supported xpub version bytes
const XPUB_VERSIONS = [
    'xpub' => '0488B21E', // BIP44 mainnet
    'zpub' => '04B24746', // BIP84 native segwit mainnet
    'Ltub' => '019DA462', // Litecoin BIP44 mainnet
    'Mtub' => '01B26EF6', // Litecoin BIP49 mainnet
];

function bip32_parse_xpub(string $xpub): ?array {
    $raw = base58check_decode($xpub);
    if ($raw === null || strlen($raw) !== 78) return null;
    $version   = bin2hex(substr($raw, 0, 4));
    $depth     = ord($raw[4]);
    $parent_fp = substr($raw, 5, 4);
    $child_num = unpack('N', substr($raw, 9, 4))[1];
    $chain_code = substr($raw, 13, 32);
    $pubkey    = substr($raw, 45, 33);
    // Detect type
    $type = 'xpub';
    foreach (XPUB_VERSIONS as $name => $ver) {
        if (strtoupper($version) === strtoupper($ver)) { $type = $name; break; }
    }
    return compact('version', 'depth', 'parent_fp', 'child_num', 'chain_code', 'pubkey', 'type');
}

// Derive a non-hardened child public key from a parsed xpub node
// index must be 0 … 2^31-1
function bip32_derive_public(array $node, int $index): ?array {
    if ($index >= 0x80000000) return null; // hardened not supported from xpub
    $data  = $node['pubkey'] . pack('N', $index);
    $I     = hash_hmac('sha512', $data, $node['chain_code'], true);
    $IL    = substr($I, 0, 32);
    $IR    = substr($I, 32, 32);
    $n     = _secp_n();
    $il_int = gmp_import($IL, 1, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
    if (gmp_cmp($il_int, $n) >= 0) return null; // invalid key (astronomically rare)
    $G      = [_secp_Gx(), _secp_Gy()];
    $Il_pt  = ec_mul($il_int, $G);
    $parent = ec_decompress($node['pubkey']);
    if ($parent === null) return null;
    $child_point = ec_add($Il_pt, $parent);
    if ($child_point === EC_INF) return null;
    $child_pubkey = ec_compress($child_point);
    $fingerprint  = substr(hash160($node['pubkey']), 0, 4);
    return [
        'version'    => $node['version'],
        'depth'      => $node['depth'] + 1,
        'parent_fp'  => $fingerprint,
        'child_num'  => $index,
        'chain_code' => $IR,
        'pubkey'     => $child_pubkey,
        'type'       => $node['type'],
    ];
}

// Derive pubkey at relative path e.g. "0/12" from an xpub
function bip32_derive_path(array $node, string $path): ?array {
    foreach (explode('/', trim($path, '/')) as $seg) {
        $idx = (int)$seg;
        $node = bip32_derive_public($node, $idx);
        if ($node === null) return null;
    }
    return $node;
}

// ══════════════════════════════════════════════════════════
// Address derivation per coin
// ══════════════════════════════════════════════════════════

// Bitcoin P2PKH (legacy) — prefix 0x00
function btc_p2pkh(string $compressed_pubkey): string {
    return base58check_encode("\x00" . hash160($compressed_pubkey));
}

// Bitcoin P2WPKH (native SegWit bech32 bc1q…)
function btc_p2wpkh(string $compressed_pubkey): string {
    return p2wpkh_address(hash160($compressed_pubkey), 'bc');
}

// Litecoin P2PKH — prefix 0x30
function ltc_p2pkh(string $compressed_pubkey): string {
    return base58check_encode("\x30" . hash160($compressed_pubkey));
}

// Tron/USDT TRC20 address from compressed pubkey
function tron_address(string $compressed_pubkey): string {
    $point = ec_decompress($compressed_pubkey);
    if ($point === null) return '';
    $uncompressed_body = gmp_export($point[0], 32, GMP_MSW_FIRST | GMP_BIG_ENDIAN)
                       . gmp_export($point[1], 32, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
    $hash = keccak256($uncompressed_body); // 32 bytes
    $raw  = "\x41" . substr($hash, 12, 20); // prefix 0x41 + last 20 bytes
    return base58check_encode($raw);
}

// ══════════════════════════════════════════════════════════
// Main public API
// ══════════════════════════════════════════════════════════

/**
 * Derive a deposit address from an xpub/zpub and sequential index.
 *
 * For BIP44 wallets the external chain is m/44'/coin'/0'/0/{index}
 * The xpub stored in settings should already be at depth m/44'/coin'/0'
 * so we derive child path "0/{index}".
 *
 * @param  string $xpub_str  The xpub/zpub/Ltub stored in admin settings
 * @param  int    $index     Sequential deposit index (0, 1, 2, …)
 * @param  string $coin      'btc', 'btc_segwit', 'ltc', 'usdt_trc20'
 * @return string|null       Deposit address or null on error
 */
function derive_deposit_address(string $xpub_str, int $index, string $coin): ?string {
    $node = bip32_parse_xpub($xpub_str);
    if ($node === null) return null;
    $child = bip32_derive_path($node, "0/{$index}");
    if ($child === null) return null;
    return match($coin) {
        'btc'        => btc_p2pkh($child['pubkey']),
        'btc_segwit' => btc_p2wpkh($child['pubkey']),
        'ltc'        => ltc_p2pkh($child['pubkey']),
        'usdt_trc20' => tron_address($child['pubkey']),
        default      => null,
    };
}

/**
 * Validate that an xpub string is well-formed (correct checksum, correct prefix, valid pubkey).
 * Returns ['ok'=>true] or ['ok'=>false, 'error'=>'...']
 */
function validate_xpub(string $xpub): array {
    if (strlen($xpub) < 50) return ['ok' => false, 'error' => 'Too short'];
    $raw = base58check_decode($xpub);
    if ($raw === null) return ['ok' => false, 'error' => 'Invalid checksum'];
    if (strlen($raw) !== 78) return ['ok' => false, 'error' => 'Wrong length'];
    $pubkey = substr($raw, 45, 33);
    if ($pubkey[0] !== "\x02" && $pubkey[0] !== "\x03") return ['ok' => false, 'error' => 'Invalid pubkey prefix'];
    $version = strtoupper(bin2hex(substr($raw, 0, 4)));
    $known = array_map('strtoupper', XPUB_VERSIONS);
    if (!in_array($version, $known, true)) {
        return ['ok' => false, 'error' => "Unknown version bytes $version — use xpub/zpub/Ltub"];
    }
    // Verify the pubkey point is on the curve
    try {
        $point = ec_decompress($pubkey);
        if ($point === null) return ['ok' => false, 'error' => 'Public key not on secp256k1 curve'];
    } catch (\Throwable) {
        return ['ok' => false, 'error' => 'Pubkey decompression failed'];
    }
    $type = array_flip($known)[$version];
    return ['ok' => true, 'type' => $type, 'depth' => ord($raw[4])];
}

/**
 * Get and increment the global deposit derive index.
 * Each call returns a unique index, thread-safe via SQLite exclusive transaction.
 */
function next_deposit_index(): int {
    $pdo = db();
    $pdo->beginTransaction();
    $stmt = $pdo->query("SELECT value FROM settings WHERE key='next_derive_index'");
    $row  = $stmt ? $stmt->fetchColumn() : false;
    $idx  = $row !== false ? (int)$row : 0;
    $pdo->prepare("INSERT INTO settings (key,value) VALUES ('next_derive_index',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value")
        ->execute([$idx + 1]);
    $pdo->commit();
    return $idx;
}
