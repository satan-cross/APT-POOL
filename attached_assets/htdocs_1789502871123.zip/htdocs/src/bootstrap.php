<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/crypto.php';
require_once __DIR__ . '/pages/lib/PayGate.php';
db_init();

session_start();

// ─── Auth helpers ────────────────────────────────────────────
// Development mode is enabled explicitly by the PHP preview workflow. It
// auto-authenticates the seeded admin account for local previews only.
function app_is_dev_mode(): bool {
    return in_array(strtolower(trim((string)getenv('APP_ENV'))), ['dev', 'development', 'local'], true);
}

function ensure_dev_session(): void {
    if (!app_is_dev_mode() || !empty($_SESSION['user_id'])) return;
    $user = db()->query("SELECT * FROM users WHERE role='admin' ORDER BY id ASC LIMIT 1")->fetch();
    if (!$user) return;
    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['user'] = $user;
}

function is_logged_in(): bool {
    ensure_dev_session();
    return !empty($_SESSION['user_id']);
}

function current_user(): ?array {
    ensure_dev_session();
    return $_SESSION['user'] ?? null;
}

function require_login(): void { if (!is_logged_in()) { header('Location: /?p=login'); exit; } }
function require_admin(): void { require_login(); $u = current_user(); if (($u['role'] ?? '') !== 'admin') { http_response_code(403); exit('Forbidden'); } }
function require_seller(): void { require_login(); $u = current_user(); if (!in_array($u['role'] ?? '', ['seller','admin'])) { header('Location: /?p=become_seller'); exit; } }

// ─── Flash messages ─────────────────────────────────────────
function flash(string $msg, string $type = 'info'): void { $_SESSION['flash'][] = compact('msg', 'type'); }
function flash_pop(): array { $f = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $f; }

// ─── Input helpers ──────────────────────────────────────────
function post(string $k, mixed $default = ''): mixed { return $_POST[$k] ?? $default; }
function get(string $k, mixed $default = ''): mixed { return $_GET[$k] ?? $default; }
function h(mixed $v): string { return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }

// ─── Cart helpers ────────────────────────────────────────────
const CART_MINUTES = 10;

function cart_count(): int {
    if (!is_logged_in()) return 0;
    $pdo = db();
    expire_cart_items();
    return (int)$pdo->prepare('SELECT COUNT(*) FROM cart_items WHERE user_id=? AND reserved_until>?')
        ->execute([$_SESSION['user_id'], time()]) ? $pdo->query('SELECT COUNT(*) FROM cart_items WHERE user_id=' . $_SESSION['user_id'] . ' AND reserved_until>' . time())->fetchColumn() : 0;
}

function expire_cart_items(): void {
    db()->prepare('UPDATE cards SET status="available" WHERE id IN (SELECT card_id FROM cart_items WHERE reserved_until<?)')
        ->execute([time()]);
    db()->prepare('DELETE FROM cart_items WHERE reserved_until<?')->execute([time()]);
}

function add_to_cart(int $user_id, int $card_id): bool {
    expire_cart_items();
    $pdo = db();
    $card = $pdo->prepare('SELECT * FROM cards WHERE id=? AND status="available"')->execute([$card_id]) ? $pdo->prepare('SELECT * FROM cards WHERE id=? AND status="available"') : null;
    if (!$card) return false;
    $card->execute([$card_id]);
    $row = $card->fetch();
    if (!$row) return false;
    $until = time() + CART_MINUTES * 60;
    try {
        $pdo->prepare('INSERT INTO cart_items (user_id,card_id,reserved_until) VALUES (?,?,?)')->execute([$user_id, $card_id, $until]);
        $pdo->prepare('UPDATE cards SET status="reserved" WHERE id=?')->execute([$card_id]);
        return true;
    } catch (Exception) { return false; }
}

function remove_from_cart(int $user_id, int $card_id): void {
    db()->prepare('DELETE FROM cart_items WHERE user_id=? AND card_id=?')->execute([$user_id, $card_id]);
    db()->prepare('UPDATE cards SET status="available" WHERE id=? AND status="reserved"')->execute([$card_id]);
}

function checkout_cart(int $user_id): array {
    expire_cart_items();
    $pdo = db();
    $user = $pdo->prepare('SELECT * FROM users WHERE id=?');
    $user->execute([$user_id]);
    $user = $user->fetch();
    $items = $pdo->prepare('SELECT ci.*,c.price,c.seller_id FROM cart_items ci JOIN cards c ON c.id=ci.card_id WHERE ci.user_id=?');
    $items->execute([$user_id]);
    $items = $items->fetchAll();
    $total = array_sum(array_column($items, 'price'));
    if ($user['balance'] < $total) return ['ok'=>false,'msg'=>'Insufficient balance'];
    $pdo->beginTransaction();
    try {
        $refund_until = time() + 3600; // 60 min refund window
        foreach ($items as $item) {
            $pdo->prepare('INSERT INTO orders (user_id,card_id,seller_id,price,refund_until) VALUES (?,?,?,?,?)')->execute([$user_id, $item['card_id'], $item['seller_id'], $item['price'], $refund_until]);
            $pdo->prepare('UPDATE cards SET status="sold" WHERE id=?')->execute([$item['card_id']]);
            $pdo->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$item['price'] * 0.9, $item['seller_id']]);
        }
        $pdo->prepare('UPDATE users SET balance=balance-? WHERE id=?')->execute([$total, $user_id]);
        $pdo->prepare('DELETE FROM cart_items WHERE user_id=?')->execute([$user_id]);
        $pdo->commit();
        $_SESSION['user']['balance'] = round($user['balance'] - $total, 2);
        return ['ok'=>true,'count'=>count($items),'total'=>$total];
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['ok'=>false,'msg'=>'Checkout failed'];
    }
}

// ─── Login/Logout ───────────────────────────────────────────
function do_login(string $username, string $password): bool {
    $pdo = db();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE username=?');
    $stmt->execute([trim($username)]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user']    = $user;
        return true;
    }
    return false;
}

function do_register(string $username, string $password, string $telegram_username = ''): array {
    if (strlen($username) < 3) return ['ok'=>false,'msg'=>'Username too short (min 3 chars)'];
    if (strlen($password) < 6) return ['ok'=>false,'msg'=>'Password too short (min 6 chars)'];
    try {
        db()->prepare('INSERT INTO users (username,password,telegram_username) VALUES (?,?,?)')
            ->execute([trim($username), password_hash($password, PASSWORD_BCRYPT), trim($telegram_username)]);
        return ['ok'=>true];
    } catch (Exception) { return ['ok'=>false,'msg'=>'Username already taken']; }
}

function do_logout(): void { session_destroy(); }

// ─── Refund ─────────────────────────────────────────────────
function request_refund(int $order_id, int $user_id): array {
    $pdo = db();
    $order = $pdo->prepare('SELECT * FROM orders WHERE id=? AND user_id=?');
    $order->execute([$order_id, $user_id]);
    $order = $order->fetch();
    if (!$order) return ['ok'=>false,'msg'=>'Order not found'];
    if ($order['status'] !== 'delivered') return ['ok'=>false,'msg'=>'Already refunded'];
    if (time() > $order['refund_until']) return ['ok'=>false,'msg'=>'Refund window closed'];
    $pdo->beginTransaction();
    try {
        $pdo->prepare('UPDATE orders SET status="refunded" WHERE id=?')->execute([$order_id]);
        $pdo->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$order['price'], $user_id]);
        $pdo->prepare('UPDATE users SET balance=balance-? WHERE id=?')->execute([$order['price'] * 0.9, $order['seller_id']]);
        $pdo->prepare('UPDATE cards SET status="available" WHERE id=?')->execute([$order['card_id']]);
        $pdo->commit();
        $_SESSION['user']['balance'] = round(($_SESSION['user']['balance'] ?? 0) + $order['price'], 2);
        return ['ok'=>true];
    } catch (Exception) { $pdo->rollBack(); return ['ok'=>false,'msg'=>'Refund failed']; }
}

// ─── Route resolver ─────────────────────────────────────────
function current_page(): string {
    $page = preg_replace('/[^a-z_]/', '', strtolower(get('p', 'marketplace')));
    $allowed = ['login','dashboard','marketplace','cart','orders','deposit','support','seller','become_seller','admin'];
    return in_array($page, $allowed) ? $page : 'marketplace';
}
