<?php
declare(strict_types=1);
/**
 * wallet_setup.php — Redirected
 *
 * HD wallet setup has been replaced by CoinPayments.
 * Admin deposit settings are now in the Admin panel → CoinPayments tab.
 */

foreach ([
    __DIR__ . '/init.php',
    __DIR__ . '/bootstrap.php',
] as $f) {
    if (file_exists($f)) { require_once $f; break; }
}

header('Location: /?p=admin&tab=paygate');
exit;
