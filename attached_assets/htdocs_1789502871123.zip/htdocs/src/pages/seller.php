<?php
declare(strict_types=1);

function seller_luhn_valid(string $value): bool {
    $digits = preg_replace('/\D/', '', $value);
    if (!is_string($digits) || !preg_match('/^\d{13,19}$/', $digits)) {
        return false;
    }

    $sum = 0;
    $double = false;
    for ($i = strlen($digits) - 1; $i >= 0; $i--) {
        $digit = (int)$digits[$i];
        if ($double) {
            $digit *= 2;
            if ($digit > 9) $digit -= 9;
        }
        $sum += $digit;
        $double = !$double;
    }

    return $sum % 10 === 0;
}

function page_seller(): string {
    require_seller();
    $uid = (int)$_SESSION['user_id'];
    $pdo = db();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $act = post('action');

        if ($act === 'upload_inventory') {
            $use_pin = (bool)post('use_pin', false);
            $form_pin_raw = trim(post('card_pin', ''));

            // Validate form-level PIN if provided
            $default_pin_hash = null;
            if ($use_pin && $form_pin_raw !== '') {
                if (!preg_match('/^\d{4,8}$/', $form_pin_raw)) {
                    flash('PIN must be 4–8 digits only.', 'error');
                    header('Location: /?p=seller'); exit;
                }
                $default_pin_hash = password_hash($form_pin_raw, PASSWORD_BCRYPT);
            }

            // Base prices per card type — price column in data is ignored
            $base_price_credit = max(0.01, round((float)post('base_price_credit', 5.00), 2));
            $base_price_debit  = max(0.01, round((float)post('base_price_debit',  3.00), 2));

            // Resolve raw data: file upload takes priority over paste
            $filename = null;
            $raw      = '';
            if (!empty($_FILES['inventory_file']['tmp_name']) && $_FILES['inventory_file']['error'] === UPLOAD_ERR_OK) {
                $raw      = trim((string)file_get_contents($_FILES['inventory_file']['tmp_name']));
                $filename = basename($_FILES['inventory_file']['name']);
            } else {
                $raw = trim(post('raw_inventory', ''));
            }

            if (!$raw) { flash('Please paste card data or upload a file.', 'error'); }
            else {
                $lines = array_filter(array_map('trim', explode("\n", $raw)));
                $count = 0;

                // Required fields and their column indices in the pipe-delimited format:
                // number|exp|cvv|name|address|address2|city|state|zipcode|country|phone
                $required_fields = [
                    0 => 'number',
                    1 => 'exp',
                    2 => 'cvv',
                    3 => 'name',
                    4 => 'address',
                    6 => 'city',
                    7 => 'state',
                    8 => 'zipcode',
                ];

                $skipped_lines   = [];  // line numbers (1-based) that failed validation
                $missing_by_line = [];  // which fields were missing per skipped line
                $line_total      = 0;
                $line_valid      = 0;

                // Keep the upload atomic: below-threshold uploads must not
                // leave partially imported inventory behind.
                $pdo->beginTransaction();

                foreach ($lines as $line_idx => $line) {
                    if (str_starts_with(ltrim($line), '#')) continue;
                    $line_total++;

                    $line_pin_hash = $default_pin_hash;
                    $number        = '';
                    $exp           = '';
                    $cvv           = '';
                    $name          = '';
                    $address       = '';
                    $address2      = '';
                    $city          = '';
                    $state         = '';
                    $zipcode       = '';
                    $country       = 'US';
                    $phone         = '';
                    $requires_cvv  = false;

                    // Check for Track format with an optional trailing PIN.
                    // Accept plain :1234 as well as labeled :ps1234/:ps:1234.
                    // Example: ...?*:ps1234
                    if (preg_match('/%?B?(\d{13,19})\^([^\^]+)\^(\d{2})(\d{2})[^\?]*\??.*?(?::(?:(?:ps|pin)[:=]?)?(\d{4,8}))?$/i', $line, $t1_matches)) {
                        $number   = $t1_matches[1];
                        $card_type = 'DP+S';
                        $raw_name = trim($t1_matches[2]);
                        if (str_contains($raw_name, '/')) {
                            $name_parts = explode('/', $raw_name, 2);
                            $name = trim($name_parts[1]) . ' ' . trim($name_parts[0]);
                        } else {
                            $name = $raw_name;
                        }
                        $exp = $t1_matches[4] . '/' . $t1_matches[3];

                        if (!empty($t1_matches[5])) {
                            $line_pin_hash = password_hash($t1_matches[5], PASSWORD_BCRYPT);
                        }

                    // Check for Track 2 format with the same optional PIN forms.
                    // Example: ;4111...=YYMM...?:ps1234
                    } elseif (preg_match('/;?(\d{13,19})=(\d{2})(\d{2})[^\?]*\??.*?(?::(?:(?:ps|pin)[:=]?)?(\d{4,8}))?$/i', $line, $t2_matches)) {
                        $number = $t2_matches[1];
                        $card_type = 'DP+S';
                        $exp    = $t2_matches[3] . '/' . $t2_matches[2];

                        if (!empty($t2_matches[4])) {
                            $line_pin_hash = password_hash($t2_matches[4], PASSWORD_BCRYPT);
                        }

                    // Fallback to standard delimited format:
                    // number|exp|cvv|name|address|address2|city|state|zipcode|country|phone|type
                    } else {
                        $requires_cvv = true;
                        // Preserve empty columns so an optional type in the
                        // final field remains at index 11.
                        $parts = preg_split('/[|;,\t]/', $line);
                        $missing = [];

                        foreach ($required_fields as $idx => $field_name) {
                            $val = trim($parts[$idx] ?? '');
                            if ($field_name === 'number') {
                                $val = preg_replace('/\D/', '', $val);
                                if (strlen($val) < 13 || strlen($val) > 19) {
                                    $missing[] = 'number (must be 13–19 digits)';
                                }
                            } elseif ($val === '') {
                                $missing[] = $field_name;
                            }
                        }

                        if (!empty($missing)) {
                            $skipped_lines[]   = $line_idx + 1;
                            $missing_by_line[] = implode(', ', $missing);
                            continue;
                        }

                        $number   = preg_replace('/\D/', '', $parts[0]);
                        $exp      = trim($parts[1]);
                        $cvv      = trim($parts[2]);
                        $name     = trim($parts[3]);
                        $address  = trim($parts[4]);
                        $address2 = trim($parts[5] ?? '');
                        $city     = trim($parts[6]);
                        $state    = trim($parts[7]);
                        $zipcode  = trim($parts[8]);
                        $country  = strtoupper(trim($parts[9] ?? 'US')) ?: 'US';
                        $phone    = trim($parts[10] ?? '');
                        $card_type = trim($parts[11] ?? 'Credit');
                    }

                    if (strlen($number) < 13 || strlen($number) > 19) {
                        $skipped_lines[]   = $line_idx + 1;
                        $missing_by_line[] = 'valid card number';
                        continue;
                    }

                    if (!seller_luhn_valid($number)) {
                        $skipped_lines[]   = $line_idx + 1;
                        $missing_by_line[] = 'valid Luhn checksum';
                        continue;
                    }

                    if (!preg_match('/^(0[1-9]|1[0-2])\/(?:\d{2}|\d{4})$/', $exp)) {
                        $skipped_lines[]   = $line_idx + 1;
                        $missing_by_line[] = 'valid expiration (MM/YY)';
                        continue;
                    }

                    if ($requires_cvv && !preg_match('/^\d{3,4}$/', $cvv)) {
                        $skipped_lines[]   = $line_idx + 1;
                        $missing_by_line[] = 'valid CVV';
                        continue;
                    }

                    $bin   = substr($number, 0, 1);
                    $brand = match($bin) { '4'=>'VISA','5'=>'MASTERCARD','3'=>'AMEX','6'=>'DISCOVER', default=>'VISA' };

                    // Keep the canonical spelling in the database while
                    // retaining the existing types used by marketplace filters.
                    $normalized_type = strtoupper(trim($card_type ?? 'Credit'));
                    $card_type = match ($normalized_type) {
                        'DP+S' => 'DP+S',
                        'DEBIT' => 'Debit',
                        'PLATINUM' => 'Platinum',
                        'GOLD' => 'Gold',
                        default => 'Credit',
                    };
                    $price     = ($card_type === 'Debit') ? $base_price_debit : $base_price_credit;

                    try {
                        $pdo->prepare('INSERT INTO cards (seller_id,number,exp,cvv,card_name,address,address2,city,state,zipcode,bin,brand,card_type,country,phone,price,pin_hash,bank) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute([
                            $uid, $number, $exp, $cvv, $name,
                            $address, $address2, $city, $state, $zipcode,
                            substr($number,0,6), $brand, $card_type, $country, $phone, $price, $line_pin_hash,
                            '',
                        ]);
                        $count++;
                        $line_valid++;
                    } catch (\PDOException $e) {
                        if ($pdo->inTransaction()) $pdo->rollBack();
                        flash('Database error while inserting card: ' . htmlspecialchars($e->getMessage()) . ' — run the required ALTER TABLE migrations on your cards table (add columns: address2, phone, pin_hash).', 'error');
                        header('Location: /?p=seller'); exit;
                    }
                }

                $valid_ratio = $line_total > 0 ? ($line_valid / $line_total) : 0.0;
                if ($line_total === 0 || $valid_ratio < 0.74) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    $valid_percent = number_format($valid_ratio * 100, 1);
                    $minimum_valid = (int)ceil($line_total * 0.74);
                    flash("Upload refused: only {$line_valid} of {$line_total} data line(s) passed local validation ({$valid_percent}%). At least {$minimum_valid} line(s) (74%) must pass Luhn and format checks.", 'error');
                    header('Location: /?p=seller'); exit;
                }

                $skip_msg = '';
                if (!empty($skipped_lines)) {
                    $all_missing = array_unique(array_merge(...array_map(
                        fn($m) => array_map('trim', explode(',', $m)),
                        $missing_by_line
                    )));
                    sort($all_missing);
                    $skipped_count = count($skipped_lines);
                    $skip_msg = " ($skipped_count line(s) skipped — missing required field(s): <strong>" . htmlspecialchars(implode(', ', $all_missing)) . "</strong>)";
                }

                if ($count > 0) {
                    try {
                        $pdo->prepare('INSERT INTO seller_inventory (seller_id,filename,raw_data,count,imported) VALUES (?,?,?,?,?)')->execute([$uid, $filename, $raw, count($lines), $count]);
                        $pdo->commit();
                    } catch (\PDOException $e) {
                        if ($pdo->inTransaction()) $pdo->rollBack();
                        flash('Cards imported but inventory log failed: ' . htmlspecialchars($e->getMessage()) . ' — create the seller_inventory table if it does not exist.', 'warning');
                        header('Location: /?p=seller'); exit;
                    }
                    $src_msg = $filename ? " from <strong>" . htmlspecialchars($filename) . "</strong>" : '';
                    $type    = empty($skipped_lines) ? 'success' : 'warning';
                    flash("Imported $count card(s){$src_msg} to your inventory!{$skip_msg}", $type);
                } elseif (!empty($skipped_lines)) {
                    flash("No cards imported. All lines were missing required fields: <strong>" . htmlspecialchars(implode(', ', array_unique(array_merge(...array_map(fn($m) => array_map('trim', explode(',', $m)), $missing_by_line))))) . "</strong>.<br>Required format: Track 1/2 (with optional :PIN) or number|exp|cvv|name|address|address2|city|state|zipcode|country|phone", 'error');
                } else {
                    flash('No valid card lines found. Required format: Track 1/2 (with optional :PIN) or number|exp|cvv|name|address|address2|city|state|zipcode|country|phone', 'error');
                }
            }
            header('Location: /?p=seller');
            exit;
        }

        if ($act === 'delete_card') {
            $card_id = (int)post('card_id');
            $pdo->prepare('UPDATE cards SET status="deleted" WHERE id=? AND seller_id=? AND status="available"')->execute([$card_id, $uid]);
            flash('Card removed', 'info');
            header('Location: /?p=seller');
            exit;
        }

        if ($act === 'update_price') {
            $card_id = (int)post('card_id');
            $price   = max(0.01, round((float)post('price'), 2));
            $pdo->prepare('UPDATE cards SET price=? WHERE id=? AND seller_id=? AND status="available"')->execute([$price, $card_id, $uid]);
            flash('Price updated', 'success');
            header('Location: /?p=seller');
            exit;
        }
    }

    $cards = $pdo->prepare('SELECT * FROM cards WHERE seller_id=? AND status != "deleted" ORDER BY created_at DESC LIMIT 100');
    $cards->execute([$uid]);
    $cards = $cards->fetchAll();

    $total_listed   = count(array_filter($cards, fn($c) => $c['status']==='available'));
    $total_sold     = $pdo->prepare('SELECT COUNT(*) FROM orders WHERE seller_id=?'); $total_sold->execute([$uid]); $total_sold=(int)$total_sold->fetchColumn();
    $total_revenue  = $pdo->prepare('SELECT COALESCE(SUM(price)*0.9,0) FROM orders WHERE seller_id=?'); $total_revenue->execute([$uid]); $total_revenue=(float)$total_revenue->fetchColumn();
    $shop_open      = shop_is_open();

    ob_start(); ?>
<div class="topbar">
  <h1 class="page-title">Seller <span>Dashboard</span></h1>
  <span class="badge badge-green"><span class="dot dot-green"></span> No Bond Required</span>
</div>

<div class="stat-grid">
  <div class="stat-card"><div class="stat-label">Listed</div><div class="stat-value"><?= $total_listed ?></div></div>
  <div class="stat-card"><div class="stat-label">Sold</div><div class="stat-value green"><?= $total_sold ?></div></div>
  <div class="stat-card"><div class="stat-label">Revenue</div><div class="stat-value green">$<?= number_format($total_revenue, 2) ?></div><div class="stat-sub">90% of sales</div></div>
</div>

<div class="seller-grid">
  <div>
    <div class="card mb-16">
      <div class="section-title">Upload Inventory</div>
      <?php if (!$shop_open): ?>
      <div style="display:flex;align-items:center;gap:10px;padding:11px 14px;border-radius:var(--r-sm);border:1px solid rgba(219,20,60,.4);background:rgba(219,20,60,.08);margin-bottom:12px">
        <span>⚠</span>
        <div>
          <div class="fw-6" style="color:var(--red);font-size:12px">Shop is temporarily closed</div>
          <div class="text-dim text-xs mt-2">You can still upload cards to your inventory, but buyers will not be able to purchase them until the shop reopens.</div>
        </div>
      </div>
      <?php endif; ?>

      <p class="text-sm text-muted mb-12">Set base prices per card type, then paste or upload your card data.</p>

      <!-- Base price inputs -->
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px">
        <div class="form-group" style="margin:0">
          <label class="form-label">Base Price — Credit</label>
          <div style="position:relative">
            <span style="position:absolute;left:9px;top:50%;transform:translateY(-50%);color:var(--text-3);font-size:13px">$</span>
            <input class="form-input" type="number" id="inp_credit" step="0.01" min="0.01" value="5.00" style="padding-left:22px" oninput="syncPrices()">
          </div>
          <div class="form-hint">Applied to all credit cards</div>
        </div>
        <div class="form-group" style="margin:0">
          <label class="form-label">Base Price — Debit</label>
          <div style="position:relative">
            <span style="position:absolute;left:9px;top:50%;transform:translateY(-50%);color:var(--text-3);font-size:13px">$</span>
            <input class="form-input" type="number" id="inp_debit" step="0.01" min="0.01" value="3.00" style="padding-left:22px" oninput="syncPrices()">
          </div>
          <div class="form-hint">Applied to all debit cards</div>
        </div>
      </div>
      <div style="font-size:11px;color:var(--text-3);margin-bottom:14px;padding:8px 10px;background:var(--bg-root);border-radius:var(--r-sm);border:1px solid var(--border)">
        Credit: <strong id="lbl_credit">$5.00</strong> &nbsp;&middot;&nbsp; Debit: <strong id="lbl_debit">$3.00</strong>
        &nbsp;&middot;&nbsp; <span style="color:var(--amber)">+10% of balance will be added once balance check is complete.</span>
      </div>

      <p class="text-xs text-muted mb-8">Supported card data formats:</p>
      <div style="background:var(--bg-root);border:1px solid var(--border);border-radius:var(--r-sm);padding:10px;font-family:monospace;font-size:10.5px;color:var(--teal);margin-bottom:12px">
        %B4111222233334444^SMITH/JOHN^30121010000012340000?*;4111222233334444=3012101000001234?*:ps1234 <span style="color:var(--text-3)">→ DP+S + PIN</span><br>
        4532015112830366|12/27|456|John Doe||||||US|+12125550101|Credit<br>
        5425233430109903|08/26|232|Jane Smith||||||US||dp+s<br>
        <span style="color:var(--text-3)"># Track 1/2 uploads are detected as DP+S. PINs may follow as :1234, :ps1234, or :ps:1234.</span>
      </div>

      <form method="POST" enctype="multipart/form-data" id="upload-form">
        <input type="hidden" name="action" value="upload_inventory">
        <input type="hidden" name="base_price_credit" id="hid_credit" value="5.00">
        <input type="hidden" name="base_price_debit"  id="hid_debit"  value="3.00">

        <!-- Source tabs -->
        <div style="display:flex;gap:0;margin-bottom:12px;border:1px solid var(--border);border-radius:var(--r-sm);overflow:hidden">
          <button type="button" id="tab-paste" onclick="switchTab('paste')"
                  style="flex:1;padding:7px 0;font-size:12px;font-weight:600;background:var(--accent);color:#fff;border:none;cursor:pointer">
            Paste Text
          </button>
          <button type="button" id="tab-file" onclick="switchTab('file')"
                  style="flex:1;padding:7px 0;font-size:12px;font-weight:600;background:var(--bg-input);color:var(--text-2);border:none;cursor:pointer">
            Upload File
          </button>
        </div>

        <!-- Paste panel -->
        <div id="panel-paste" class="form-group">
          <label class="form-label">Raw Card Data</label>
          <textarea class="form-input" id="raw-inventory" name="raw_inventory" rows="8" placeholder="Paste cards here..." oninput="parsePreview()"></textarea>
          <div class="form-hint"><span id="parsed-count">Paste data to preview count</span></div>
        </div>

        <!-- File upload panel -->
        <div id="panel-file" class="form-group" style="display:none">
          <label class="form-label">Card File (.txt / .csv)</label>
          <div id="drop-zone" style="border:2px dashed var(--border);border-radius:var(--r-md);padding:28px;text-align:center;cursor:pointer;transition:border-color .2s"
               onclick="document.getElementById('inventory_file').click()"
               ondragover="event.preventDefault();this.style.borderColor='var(--accent)'"
               ondragleave="this.style.borderColor='var(--border)'"
               ondrop="handleDrop(event)">
            <div style="font-size:28px;margin-bottom:8px">📂</div>
            <div class="fw-6" style="font-size:13px">Click to browse or drag &amp; drop</div>
            <div class="text-dim text-xs mt-4">Accepted: .txt, .csv — Track 1/2 or pipe/comma/tab format</div>
            <div id="drop-filename" class="text-xs mt-6" style="color:var(--green);display:none"></div>
          </div>
          <input type="file" id="inventory_file" name="inventory_file" accept=".txt,.csv,.tsv"
                 style="display:none" onchange="showFileName(this)">
        </div>

        <div class="parser-preview" id="parser-preview">Paste raw card data above to preview...</div>

        <button class="btn btn-primary mt-12" id="import-btn" style="width:100%;justify-content:center;margin-top:12px">Import Cards</button>
      </form>
    </div>
  </div>

  <div>
    <div class="card">
      <div class="section-title">Seller Info</div>
      <div class="flex flex-col gap-8" style="font-size:12.5px">
        <div class="flex justify-between"><span class="text-dim">Commission</span><span class="fw-6">10% per sale</span></div>
        <div class="flex justify-between"><span class="text-dim">Bond required</span><span class="fw-6 text-green">$0 — None</span></div>
        <div class="flex justify-between"><span class="text-dim">Instant activation</span><span class="fw-6 text-green">Yes</span></div>
        <div class="flex justify-between"><span class="text-dim">Payout</span><span class="fw-6">Instant to balance</span></div>
        <div class="flex justify-between"><span class="text-dim">Refund window (buyers)</span><span class="fw-6">60 minutes</span></div>
      </div>
    </div>
  </div>
</div>

<div class="card mt-16">
  <div class="section-title">My Cards</div>
  <?php if (empty($cards)): ?>
    <div class="text-dim text-sm">No cards listed yet. Upload inventory above.</div>
  <?php else: ?>
  <div class="table-wrap" style="border:none">
    <table>
      <thead><tr><th>Number</th><th>Brand</th><th>Exp</th><th>Bank</th><th>CC</th><th>Status</th><th>Price</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($cards as $c): ?>
        <tr>
          <td class="td-mono"><?= h(substr($c['number'],0,6)) ?>••••••<?= h(substr($c['number'],-4)) ?></td>
          <td><span class="badge badge-gray"><?= h($c['brand']) ?></span></td>
          <td class="td-mono text-dim"><?= h($c['exp']) ?></td>
          <td style="font-size:11px"><?= h($c['bank']) ?></td>
          <td><span class="badge badge-gray"><?= h($c['country']) ?></span></td>
          <td><?php
            $s=$c['status'];
            $cls=match($s){ 'available'=>'badge-green','reserved'=>'badge-amber','sold'=>'badge-purple', default=>'badge-gray' };
            echo "<span class='badge $cls'>$s</span>";
          ?></td>
          <td>
            <?php if ($c['status']==='available'): ?>
            <form method="POST" class="flex gap-4" style="display:inline-flex;gap:4px">
              <input type="hidden" name="action" value="update_price">
              <input type="hidden" name="card_id" value="<?= $c['id'] ?>">
              <input class="form-input" type="number" name="price" value="<?= $c['price'] ?>" step="0.01" min="0.01" style="width:70px;padding:4px 6px;font-size:11px">
              <button class="btn btn-ghost btn-xs">Set</button>
            </form>
            <?php else: ?>
              <span class="td-price">$<?= number_format((float)$c['price'],2) ?></span>
            <?php endif; ?>
          </td>
          <td>
            <?php if ($c['status']==='available'): ?>
            <form method="POST" onsubmit="return confirm('Remove this card?')">
              <input type="hidden" name="action" value="delete_card">
              <input type="hidden" name="card_id" value="<?= $c['id'] ?>">
              <button class="btn btn-danger btn-xs">Remove</button>
            </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<script>
function syncPrices() {
  var c = parseFloat(document.getElementById('inp_credit').value) || 0;
  var d = parseFloat(document.getElementById('inp_debit').value)  || 0;
  document.getElementById('lbl_credit').textContent = '$' + c.toFixed(2);
  document.getElementById('lbl_debit').textContent  = '$' + d.toFixed(2);
  document.getElementById('hid_credit').value = c.toFixed(2);
  document.getElementById('hid_debit').value  = d.toFixed(2);
}
function switchTab(tab) {
  var isPaste = tab === 'paste';
  document.getElementById('panel-paste').style.display = isPaste ? '' : 'none';
  document.getElementById('panel-file').style.display  = isPaste ? 'none' : '';
  document.getElementById('tab-paste').style.background = isPaste ? 'var(--accent)' : 'var(--bg-input)';
  document.getElementById('tab-paste').style.color      = isPaste ? '#fff' : 'var(--text-2)';
  document.getElementById('tab-file').style.background  = isPaste ? 'var(--bg-input)' : 'var(--accent)';
  document.getElementById('tab-file').style.color       = isPaste ? 'var(--text-2)' : '#fff';
  if (isPaste) {
    var fi = document.getElementById('inventory_file');
    if (fi) { var dt = new DataTransfer(); fi.files = dt.files; }
  } else {
    document.getElementById('raw-inventory').value = '';
  }
}
function showFileName(input) {
  var lbl = document.getElementById('drop-filename');
  if (input.files[0]) { lbl.textContent = '✓ ' + input.files[0].name; lbl.style.display = 'block'; }
}
function handleDrop(e) {
  e.preventDefault();
  document.getElementById('drop-zone').style.borderColor = 'var(--border)';
  var file = e.dataTransfer.files[0];
  if (!file) return;
  var dt = new DataTransfer(); dt.items.add(file);
  var fi = document.getElementById('inventory_file');
  fi.files = dt.files;
  showFileName(fi);
}
function parsePreview() {
  var raw = document.getElementById('raw-inventory').value;
  var lines = raw.split('\n').map(function(l){ return l.trim(); }).filter(function(l){ return l && !l.startsWith('#'); });
      var FIELDS = ['number','exp','cvv','name','address','address2','city','state','zipcode','country','phone','type'];
  var REQUIRED = ['number','exp','cvv','name','address','city','state','zipcode'];
  var parsed = [];
  var skipped = 0;

  lines.forEach(function(line) {
    var card = {};
    var t1Match = line.match(/%?B?(\d{13,19})\^([^\^]+)\^(\d{2})(\d{2})[^\?]*\??.*?(?::(\d{4,8}))?$/i);
    var t2Match = line.match(/;?(\d{13,19})=(\d{2})(\d{2})[^\?]*\??.*?(?::(\d{4,8}))?$/);

    if (t1Match) {
      card.number = t1Match[1];
      var rawName = t1Match[2].trim();
      card.name = rawName.includes('/') ? rawName.split('/').reverse().join(' ').trim() : rawName;
      card.exp = t1Match[4] + '/' + t1Match[3];
      card.country = 'US';
      if (t1Match[5]) { card.pin = t1Match[5]; }
      parsed.push(card);
    } else if (t2Match) {
      card.number = t2Match[1];
      card.exp = t2Match[3] + '/' + t2Match[2];
      card.country = 'US';
      if (t2Match[4]) { card.pin = t2Match[4]; }
      parsed.push(card);
    } else {
      var parts = line.split(/[|;,\t]/);
      FIELDS.forEach(function(f, i) { card[f] = (parts[i] || '').trim(); });
      card.number = card.number.replace(/\D/g, '');

      var missing = REQUIRED.filter(function(f) {
        if (f === 'number') return card.number.length < 13 || card.number.length > 19;
        return card[f] === '';
      });

      if (missing.length) { skipped++; return; }

      if (!card.address2) delete card.address2;
      if (!card.country)  card.country = 'US';
      if (!card.phone)    delete card.phone;
      parsed.push(card);
    }
  });

  var countEl   = document.getElementById('parsed-count');
  var previewEl = document.getElementById('parser-preview');

  if (lines.length === 0) {
    countEl.textContent   = 'Paste data to preview count';
    previewEl.textContent = 'Paste raw card data above to preview...';
    return;
  }

  var countMsg = parsed.length + ' card(s) detected';
  if (skipped) countMsg += ' · ' + skipped + ' line(s) skipped';
  countEl.textContent = countMsg;

  if (parsed.length === 0) {
    previewEl.textContent = 'No valid card formats detected.';
  } else {
    previewEl.textContent = JSON.stringify(parsed.slice(0, 5), null, 2) + (parsed.length > 5 ? '\n…and ' + (parsed.length - 5) + ' more' : '');
  }
}
document.addEventListener('DOMContentLoaded', function() { syncPrices(); parsePreview(); });
</script>
<?php
    return ob_get_clean();
}