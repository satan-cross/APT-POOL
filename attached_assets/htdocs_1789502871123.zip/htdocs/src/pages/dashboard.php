<?php
declare(strict_types=1);

function page_dashboard(): string {
    require_login();
    $user = current_user();
    $pdo  = db();
    $uid  = (int)$user['id'];

    $open_tickets = $pdo->prepare("SELECT COUNT(*) FROM tickets WHERE user_id=? AND status='open'");
    $open_tickets->execute([$uid]);
    $open_tickets = (int)$open_tickets->fetchColumn();
    $pending_deposits = $pdo->prepare("SELECT COUNT(*) FROM deposits WHERE user_id=? AND status='pending'");
    $pending_deposits->execute([$uid]);
    $pending_deposits = (int)$pending_deposits->fetchColumn();

    ob_start(); ?>
<div class="topbar"><h1 class="page-title">Dashboard</h1>
  <a href="/?p=deposit" class="btn btn-primary btn-sm">+ Deposit</a>
</div>

<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-label">Balance</div>
    <div class="stat-value green">$<?= number_format((float)$user['balance'], 2) ?></div>
    <div class="stat-sub">Available funds</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Open Tickets</div>
    <div class="stat-value"><?= $open_tickets ?></div>
    <div class="stat-sub">Support requests</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Pending Deposits</div>
    <div class="stat-value <?= $pending_deposits > 0 ? 'red' : '' ?>"><?= $pending_deposits ?></div>
    <div class="stat-sub">Awaiting review</div>
  </div>
  <div class="stat-card">
    <div class="stat-label">Access Level</div>
    <div class="stat-value" style="font-size:18px;text-transform:capitalize"><?= h($user['role']) ?></div>
    <div class="stat-sub">Current workspace role</div>
  </div>
</div>

<div class="card">
  <div class="section-title">Task Console</div>
  <div class="empty-state">
    <h3>Ready for your next workflow</h3>
    <p>Choose an authorized task from the console to record what you want to review.</p>
    <a href="/?p=marketplace" class="btn btn-primary mt-16">Open Task Console</a>
  </div>
</div>
<?php
    return ob_get_clean();
}
