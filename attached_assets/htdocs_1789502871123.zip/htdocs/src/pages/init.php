<?php
declare(strict_types=1);
/**
 * init.php — Application Bootstrap
 *
 * Defines every shared helper: db(), session helpers, flash, cart, checkout,
 * wallet-address validation, and the SQLite schema initialiser.
 *
 * Loaded automatically by index.php and by standalone endpoints
 * (check_deposits.php) that probe for this file.
 */

// ── Session ──────────────────────────────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_name('cardmkt_sess');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// ── Database (SQLite) ────────────────────────────────────────────────────────
function db(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $db_path = __DIR__ . '/data/app.sqlite';
    if (!is_dir(__DIR__ . '/data')) {
        mkdir(__DIR__ . '/data', 0755, true);
    }
    $pdo = new PDO('sqlite:' . $db_path, null, null, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $pdo->exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;');

    _init_schema($pdo);
    return $pdo;
}

function _init_schema(PDO $pdo): void {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            username      TEXT    UNIQUE NOT NULL,
            telegram_username TEXT,
            password_hash TEXT    NOT NULL,
            role          TEXT    NOT NULL DEFAULT 'buyer',
            balance       REAL    NOT NULL DEFAULT 0,
            created_at    INTEGER NOT NULL DEFAULT (strftime('%s','now'))
        );

        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT NOT NULL DEFAULT ''
        );

        CREATE TABLE IF NOT EXISTS cards (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_id   INTEGER NOT NULL,
            number      TEXT    NOT NULL,
            exp         TEXT,
            cvv         TEXT,
            name        TEXT,
            address     TEXT,
            address2    TEXT,
            city        TEXT,
            state       TEXT,
            zipcode     TEXT,
            country     TEXT,
            card_type   TEXT,
            brand       TEXT,
            bank        TEXT,
            price       REAL    NOT NULL DEFAULT 10,
            balance     REAL,
            phone       TEXT,
            status      TEXT    NOT NULL DEFAULT 'available',
            pin_hash    TEXT,
            raw_data    TEXT,
            filename    TEXT,
            created_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
        );

        CREATE TABLE IF NOT EXISTS cart_items (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id         INTEGER NOT NULL,
            card_id         INTEGER NOT NULL UNIQUE,
            reserved_until  INTEGER NOT NULL,
            created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
        );

        CREATE TABLE IF NOT EXISTS orders (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL,
            seller_id    INTEGER NOT NULL,
            card_id      INTEGER NOT NULL,
            price        REAL    NOT NULL,
            status       TEXT    NOT NULL DEFAULT 'delivered',
            purchased_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
        );

        CREATE TABLE IF NOT EXISTS deposits (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id         INTEGER NOT NULL,
            method          TEXT    NOT NULL,
            amount          REAL    NOT NULL,
            cp_invoice_id   TEXT,
            cp_checkout_url TEXT,
            deposit_address TEXT,
            cp_amount_crypto TEXT,
            status          TEXT    NOT NULL DEFAULT 'pending',
            txid            TEXT,
            confirmed_at    INTEGER,
            created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
        );

        CREATE TABLE IF NOT EXISTS withdrawals (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id        INTEGER NOT NULL,
            amount         REAL    NOT NULL,
            fee            REAL    NOT NULL DEFAULT 0,
            net_amount     REAL    NOT NULL,
            method         TEXT    NOT NULL,
            wallet_address TEXT    NOT NULL,
            status         TEXT    NOT NULL DEFAULT 'pending',
            txid           TEXT,
            admin_note     TEXT,
            processed_at   INTEGER,
            created_at     INTEGER NOT NULL DEFAULT (strftime('%s','now'))
        );

        CREATE TABLE IF NOT EXISTS tickets (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL,
            subject    TEXT    NOT NULL,
            status     TEXT    NOT NULL DEFAULT 'open',
            created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
        );

        CREATE TABLE IF NOT EXISTS ticket_messages (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id  INTEGER NOT NULL,
            sender_id  INTEGER NOT NULL,
            body       TEXT    NOT NULL,
            created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
        );

        CREATE TABLE IF NOT EXISTS seller_inventory (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_id  INTEGER NOT NULL,
            raw_data   TEXT,
            filename   TEXT,
            created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
        );
    ");

    // Migrate: add phone column to cards if missing
    try { $pdo->exec("ALTER TABLE cards ADD COLUMN phone TEXT"); } catch (\Throwable) {}

    // Migrate: add CoinPayments columns to existing deposits tables
    foreach ([
        'cp_invoice_id   TEXT',
        'cp_checkout_url TEXT',
        'cp_amount_crypto TEXT',
        'admin_note      TEXT',
    ] as $col) {
        try { $pdo->exec("ALTER TABLE deposits ADD COLUMN $col"); } catch (\Throwable) {}
    }

    // ── Seed default data if empty ───────────────────────────────────────────
    $has_users = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    if ($has_users === 0) {
        $stmt = $pdo->prepare(
            "INSERT INTO users (username, telegram_username, password_hash, role, balance) VALUES (?,?,?,?,?)"
        );
        // admin / admin123
        $stmt->execute(['admin',   'admin@example.com',  password_hash('admin123',  PASSWORD_BCRYPT), 'admin',  0]);
        // buyer demo
        $stmt->execute(['buyer1',  'buyer1@example.com', password_hash('buyer123',  PASSWORD_BCRYPT), 'buyer',  250]);
        // vendor demo
        $stmt->execute(['vendor1', 'vendor@example.com', password_hash('seller123', PASSWORD_BCRYPT), 'seller', 0]);
        // support bot (id=3 is auto-reply sender)
        $stmt->execute(['support', 'support@example.com',password_hash(bin2hex(random_bytes(16)), PASSWORD_BCRYPT), 'admin', 0]);
    }

    $has_settings = (int)$pdo->query('SELECT COUNT(*) FROM settings')->fetchColumn();
    if ($has_settings === 0) {
        $defaults = [
            'shop_open'           => '1',
            'shop_closed_reason'  => '',
            'withdrawal_fee_pct'  => '0',
            'withdrawal_min'      => '10',
            'cron_secret'         => bin2hex(random_bytes(24)),
            'sync_secret'         => bin2hex(random_bytes(24)),
        ];
        $ins = $pdo->prepare("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)");
        foreach ($defaults as $k => $v) $ins->execute([$k, $v]);
    }
}

// ── Settings helpers ─────────────────────────────────────────────────────────
// Shared cache across get_setting / set_setting in the same request.
$GLOBALS['_settings_cache'] = [];

function get_setting(string $key, string $default = ''): string {
    if (array_key_exists($key, $GLOBALS['_settings_cache'])) {
        return $GLOBALS['_settings_cache'][$key];
    }
    try {
        $s = db()->prepare('SELECT value FROM settings WHERE key=?');
        $s->execute([$key]);
        $val = $s->fetchColumn();
        $result = $val !== false ? (string)$val : $default;
        $GLOBALS['_settings_cache'][$key] = $result;
        return $result;
    } catch (\Throwable) {
        return $default;
    }
}

function set_setting(string $key, string $value): void {
    try {
        db()->prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)")->execute([$key, $value]);
        $GLOBALS['_settings_cache'][$key] = $value;
    } catch (\Throwable $e) {
        error_log('[init] set_setting failed: ' . $e->getMessage());
    }
}

// ── Session helpers ───────────────────────────────────────────────────────────
function is_logged_in(): bool {
    return !empty($_SESSION['user_id']);
}

function current_user(): array {
    if (!is_logged_in()) return [];
    if (!empty($_SESSION['user'])) return $_SESSION['user'];

    $pdo  = db();
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id=?');
    $stmt->execute([(int)$_SESSION['user_id']]);
    $user = $stmt->fetch() ?: [];
    if ($user) $_SESSION['user'] = $user;
    return $user;
}

function require_login(): void {
    if (!is_logged_in()) {
        header('Location: /?p=login');
        exit;
    }
}

function require_admin(): void {
    require_login();
    if ((current_user()['role'] ?? '') !== 'admin') {
        http_response_code(403);
        exit('Forbidden');
    }
}

function require_seller(): void {
    require_login();
    $role = current_user()['role'] ?? '';
    if (!in_array($role, ['seller', 'admin'], true)) {
        header('Location: /?p=become_seller');
        exit;
    }
}

// ── Flash messages ────────────────────────────────────────────────────────────
function flash(string $msg, string $type = 'info'): void {
    $_SESSION['_flash'][] = ['msg' => $msg, 'type' => $type];
}

function get_flash(): array {
    $msgs = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $msgs;
}

// ── Input helpers ─────────────────────────────────────────────────────────────
function get(string $key, string $default = ''): string {
    return isset($_GET[$key]) ? (string)$_GET[$key] : $default;
}

function post(string $key, string $default = ''): string {
    return isset($_POST[$key]) ? (string)$_POST[$key] : $default;
}

function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

// ── Shop state ────────────────────────────────────────────────────────────────
function shop_is_open(): bool {
    return get_setting('shop_open', '1') === '1';
}

// ── Cart helpers ──────────────────────────────────────────────────────────────
function expire_cart_items(): void {
    try {
        db()->prepare('DELETE FROM cart_items WHERE reserved_until < ?')->execute([time()]);
    } catch (\Throwable) {}
}

function add_to_cart(int $user_id, int $card_id): bool {
    $pdo     = db();
    $reserve = time() + 600; // 10-minute reservation
    try {
        $pdo->prepare(
            'INSERT INTO cart_items (user_id, card_id, reserved_until) VALUES (?, ?, ?)'
        )->execute([$user_id, $card_id, $reserve]);
        return true;
    } catch (\Throwable) {
        return false;
    }
}

function get_cart(int $user_id): array {
    expire_cart_items();
    $stmt = db()->prepare(
        'SELECT ci.*, c.number, c.brand, c.country, c.price, c.card_type
           FROM cart_items ci JOIN cards c ON c.id = ci.card_id
          WHERE ci.user_id = ? AND c.status = \'available\'
          ORDER BY ci.created_at DESC'
    );
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

// ── Checkout ──────────────────────────────────────────────────────────────────
function checkout(int $user_id): array {
    $pdo   = db();
    $items = get_cart($user_id);

    if (empty($items)) {
        return ['ok' => false, 'msg' => 'Your cart is empty.'];
    }

    $user  = current_user();
    $total = array_sum(array_column($items, 'price'));

    if ((float)$user['balance'] < $total) {
        return ['ok' => false, 'msg' => 'Insufficient balance. Please deposit more funds.'];
    }

    try {
        $pdo->beginTransaction();

        // Debit buyer
        $pdo->prepare('UPDATE users SET balance = balance - ? WHERE id = ?')
            ->execute([$total, $user_id]);

        $credit = $pdo->prepare('UPDATE users SET balance = balance + ? WHERE id = ?');
        $sold   = $pdo->prepare("UPDATE cards SET status = 'sold' WHERE id = ?");
        $del    = $pdo->prepare('DELETE FROM cart_items WHERE card_id = ?');
        $order  = $pdo->prepare(
            'INSERT INTO orders (user_id, seller_id, card_id, price) VALUES (?, ?, ?, ?)'
        );

        foreach ($items as $item) {
            $order->execute([$user_id, $item['seller_id'], $item['card_id'], $item['price']]);
            $credit->execute([$item['price'] * 0.9, $item['seller_id']]);
            $sold->execute([$item['card_id']]);
            $del->execute([$item['card_id']]);
        }

        $pdo->commit();

        // Refresh session balance
        $_SESSION['user']['balance'] = round((float)$user['balance'] - $total, 2);

        return ['ok' => true, 'count' => count($items), 'total' => $total];

    } catch (\Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('[checkout] ' . $e->getMessage());
        return ['ok' => false, 'msg' => 'Checkout failed — please try again.'];
    }
}

// ── Wallet address validation (for withdrawals) ────────────────────────────────
function validate_wallet_address(string $address, string $method): bool {
    $address = trim($address);
    if ($address === '') return false;
    switch (strtolower($method)) {
        case 'btc':
            return (bool)preg_match('/^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/', $address);
        case 'btc_segwit':
        case 'bitcoin_segwit':
            return (bool)preg_match('/^bc1[a-z0-9]{6,87}$/i', $address);
        case 'ltc':
            return (bool)preg_match('/^([LM][a-km-zA-HJ-NP-Z1-9]{25,34}|ltc1[a-z0-9]{6,87})$/i', $address);
        case 'ltc_segwit':
            return (bool)preg_match('/^ltc1[a-z0-9]{6,87}$/i', $address);
        case 'usdt_trc20':
        case 'trc20':
            return (bool)preg_match('/^T[a-km-zA-HJ-NP-Z1-9]{33}$/', $address);
        case 'xmr':
        case 'monero':
            return (bool)preg_match('/^4[0-9A-Za-z]{94}$/', $address);
        default:
            return strlen($address) >= 10;
    }
}

// ── CoinPayments client ──────────────────────────────────────────────────────
require_once __DIR__ . '/lib/CoinPayments.php';
