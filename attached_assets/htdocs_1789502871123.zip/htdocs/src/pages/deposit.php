<?php
declare(strict_types=1);

function page_deposit(): string {
    require_login();
    $uid  = (int)$_SESSION['user_id'];
    $pdo  = db();

    // ── POST handlers ─────────────────────────────────────────────────────────
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $act = post('action');

        if (!shop_is_open()) {
            flash('Deposits are disabled while the shop is closed.', 'error');
            header('Location: /?p=deposit'); exit;
        }

        // ── Create a PayGate deposit ──────────────────────────────────────────
        if ($act === 'create_deposit') {
            $symbol = strtoupper(trim(post('coin', 'BTC')));
            $amount = round(max(35.0, (float)post('amount', 0)), 2);

            $enabled_coins = PayGate::getEnabledCoins();
            if (!isset($enabled_coins[$symbol])) {
                flash('Invalid or unsupported coin: ' . h($symbol) . '. Please select an enabled coin.', 'error');
                header('Location: /?p=deposit'); exit;
            }

            // Insert a pending row first so we have a stable ID for the callback URL
            $pdo->prepare(
                'INSERT INTO deposits (user_id, method, amount, status) VALUES (?, ?, ?, ?)'
            )->execute([$uid, $symbol, $amount, 'pending']);
            $dep_id = (int)$pdo->lastInsertId();

            // Build the callback URL (includes HMAC token to prevent spoofing)
            $secret   = get_setting('pg_callback_secret', '');
            $cb_token = hash_hmac('sha256', 'dep_' . $dep_id . '_uid_' . $uid, $secret);
            $proto    = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $host     = $_SERVER['HTTP_HOST'] ?? 'localhost';
            $callback_url = $proto . '://' . $host . '/pg_callback.php?' . http_build_query([
                'dep_id' => $dep_id,
                'uid'    => $uid,
                'token'  => $cb_token,
            ]);

            // Create unique receiving wallet via PayGate
            $pg = PayGate::createWallet($symbol, $callback_url);

            if (!$pg['ok']) {
                $pdo->prepare('DELETE FROM deposits WHERE id=?')->execute([$dep_id]);
                flash('Payment gateway error: ' . ($pg['error'] ?? 'Unknown error') . '. Please try again or contact support.', 'error');
                header('Location: /?p=deposit'); exit;
            }

            // Get crypto amount for the deposit (non-fatal if API fails)
            $conversion    = PayGate::convertToCrypto($symbol, $amount);
            $amount_crypto = $conversion['amount_crypto'] ?? null;

            $pdo->prepare(
                'UPDATE deposits
                    SET cp_invoice_id=?, deposit_address=?, cp_amount_crypto=?
                  WHERE id=?'
            )->execute([
                $pg['ipn_token']  ?? null,   // store IPN token in cp_invoice_id column
                $pg['address_in'],
                $amount_crypto,
                $dep_id,
            ]);

            header("Location: /?p=deposit&show={$dep_id}"); exit;
        }
    }

    // ── Active deposit to show ────────────────────────────────────────────────
    $show_id    = (int)($_GET['show'] ?? 0);
    $active_dep = null;
    if ($show_id > 0) {
        $stmt = $pdo->prepare('SELECT * FROM deposits WHERE id=? AND user_id=?');
        $stmt->execute([$show_id, $uid]);
        $active_dep = $stmt->fetch() ?: null;
    }

    $history = $pdo->prepare('SELECT * FROM deposits WHERE user_id=? ORDER BY created_at DESC LIMIT 30');
    $history->execute([$uid]);
    $history = $history->fetchAll();

    $user      = current_user();
    $shop_open = shop_is_open();

    // ── Load enabled coins ───────────────────────────────────────────────────
    $enabled_coins = PayGate::getEnabledCoins();
    $all_coins     = PayGate::getCoins();
    $total_enabled = count($enabled_coins);

    ob_start(); ?>
<div class="topbar">
  <h1 class="page-title">Deposit Funds</h1>
  <div style="font-size:12px;color:var(--text-3)">Powered by PayGate.to · <?= $total_enabled ?> cryptocurrencies available</div>
</div>

<?php if (!$shop_open): ?>
<div class="alert alert-error" style="margin-bottom:20px">
  🔒 Deposits are currently disabled. The shop is closed.
</div>
<?php endif; ?>

<?php if ($total_enabled === 0): ?>
<div class="alert alert-error" style="margin-bottom:20px">
  ⚠ No deposit methods are currently configured. Please contact support.
</div>
<?php endif; ?>

<!-- ── Active deposit panel ──────────────────────────────────────────────── -->
<?php if ($active_dep): ?>
<?php
  $act_symbol    = strtoupper($active_dep['method'] ?? 'CRYPTO');
  $coin_def      = $all_coins[$act_symbol] ?? ['name' => $act_symbol, 'network_label' => ''];
  $pay_address   = $active_dep['deposit_address']  ?? '';
  $amount_crypto = $active_dep['cp_amount_crypto'] ?? '';
  $ipn_token     = $active_dep['cp_invoice_id']    ?? '';  // PayGate IPN token stored here
  $is_pending    = $active_dep['status'] !== 'confirmed';
?>
<div class="card" style="margin-bottom:22px;border-color:<?= $is_pending ? 'var(--amber)' : 'var(--green)' ?>30">
  <div style="display:flex;align-items:center;gap:10px;margin-bottom:18px">
    <span class="badge <?= $is_pending ? 'badge-amber' : 'badge-green' ?>" id="status-badge"
          style="font-size:13px;padding:4px 12px">
      <?= $is_pending ? '⏳ Awaiting Payment' : '✓ Confirmed' ?>
    </span>
    <span class="text-dim" style="font-size:12px">
      Deposit #<?= $active_dep['id'] ?> &middot; <?= h($coin_def['name']) ?> (<?= h($act_symbol) ?>)
      <?php if ($coin_def['network_label']): ?>
        <span class="badge badge-gray" style="font-size:10px"><?= h($coin_def['network_label']) ?></span>
      <?php endif; ?>
    </span>
  </div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px">
    <div>
      <div class="stat-label">USD Amount</div>
      <div class="stat-value green" style="font-size:22px">$<?= number_format((float)$active_dep['amount'], 2) ?></div>
    </div>
    <?php if ($amount_crypto): ?>
    <div>
      <div class="stat-label">Exact Amount to Send</div>
      <div class="stat-value" style="font-size:18px;font-family:monospace">
        <?= h($amount_crypto) ?> <?= h($act_symbol) ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <?php if ($pay_address): ?>
  <div style="margin-bottom:16px">
    <div class="stat-label" style="margin-bottom:6px">
      Send <?= h($act_symbol) ?> to this address
      <span class="text-dim" style="font-weight:400;font-size:10px;margin-left:6px">
        — Funds are automatically forwarded to our wallet &amp; your balance is credited instantly
      </span>
    </div>
    <div style="display:flex;align-items:center;gap:8px">
      <code id="pay-addr" style="flex:1;background:var(--bg-3);border:1px solid var(--border-2);border-radius:8px;
            padding:10px 12px;font-size:12px;word-break:break-all;color:var(--amber)">
        <?= h($pay_address) ?>
      </code>
      <button class="btn btn-secondary btn-sm" onclick="copyAddr()" title="Copy address">⧉</button>
    </div>
    <?php if ($amount_crypto): ?>
    <div class="text-dim" style="font-size:11px;margin-top:6px;line-height:1.6">
      ⚠ Send <strong style="color:var(--text-1)"><?= h($amount_crypto) ?> <?= h($act_symbol) ?></strong> exactly —
      any amount above the minimum will be accepted and credited at current exchange rate.
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <?php if ($is_pending): ?>
  <div id="confirm-tracker"
       style="background:var(--bg-3);border-radius:8px;padding:12px 16px;font-size:13px">
    <div style="display:flex;align-items:center;gap:10px">
      <span style="color:var(--text-2)">Payment status:</span>
      <span id="status-label" style="color:var(--amber)">Waiting for blockchain confirmation…</span>
    </div>
    <div style="display:flex;align-items:center;gap:8px;margin-top:10px">
      <button id="check-btn" class="btn btn-secondary btn-sm"
              onclick="checkNow(<?= (int)$active_dep['id'] ?>)">🔄 Check Now</button>
      <span id="last-checked" class="text-dim" style="font-size:11px">Checking…</span>
    </div>
    <div class="text-dim" style="font-size:11px;margin-top:8px;line-height:1.6">
      Your balance is credited automatically once PayGate confirms the transaction on-chain.
      This page refreshes automatically every 20 seconds.
    </div>
  </div>
  <div id="txid-row" style="display:none;margin-top:10px">
    <span class="text-dim" style="font-size:12px">TxID:</span>
    <code id="txid-val" style="font-size:11px;color:var(--indigo);margin-left:6px"></code>
  </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- ── New deposit form ───────────────────────────────────────────────────── -->
<?php if ($shop_open && $total_enabled > 0): ?>
<div class="card" style="margin-bottom:22px">
  <div class="section-title" style="margin-bottom:4px">New Deposit via PayGate.to</div>
  <div class="text-dim" style="font-size:12px;margin-bottom:20px">
    Select a cryptocurrency, enter the amount, and receive a unique deposit address.
    Funds are credited instantly after 1 blockchain confirmation. No account required — powered by PayGate.to.
  </div>

  <form method="POST" id="deposit-form" onsubmit="return validateForm()">
    <input type="hidden" name="action" value="create_deposit">
    <input type="hidden" name="coin"   id="selected-coin" value="">

    <!-- Amount -->
    <div style="margin-bottom:22px">
      <label class="form-label">Deposit Amount (USD)</label>
      <div style="display:flex;align-items:center;gap:8px;max-width:260px">
        <span style="color:var(--text-3);font-size:18px">$</span>
        <input class="form-input" type="number" id="amount-input" name="amount"
               min="35" step="0.01" placeholder="e.g. 50.00" required
               style="font-size:16px;font-weight:600">
      </div>
      <div class="text-dim" style="font-size:11px;margin-top:4px">Minimum $35.00</div>
    </div>

    <!-- Coin selector -->
    <div style="margin-bottom:22px">
      <label class="form-label" style="margin-bottom:10px">Select Cryptocurrency</label>
      <div id="coin-tiles" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px">
        <?php foreach ($enabled_coins as $sym => $c): ?>
        <button type="button"
                onclick="selectCoin('<?= h($sym) ?>')"
                class="coin-tile" data-symbol="<?= h($sym) ?>"
                style="background:var(--bg-3);border:2px solid var(--border-2);border-radius:10px;
                       padding:12px 14px;cursor:pointer;color:var(--text-1);transition:all .12s;
                       text-align:left;display:flex;flex-direction:column;gap:2px">
          <div style="font-weight:700;font-size:13px"><?= h($sym) ?></div>
          <div style="font-size:11px;color:var(--text-3)"><?= h($c['name']) ?></div>
          <div style="font-size:10px;color:var(--text-3);margin-top:2px">
            <span class="badge badge-gray" style="font-size:9px"><?= h($c['network_label']) ?></span>
          </div>
        </button>
        <?php endforeach; ?>
      </div>
      <div id="selected-coin-display" style="margin-top:10px;font-size:13px;color:var(--text-2)">
        Selected: <strong id="selected-coin-label" style="color:var(--amber)">— choose a coin above —</strong>
      </div>
    </div>

    <button type="submit" class="btn btn-primary" style="min-width:220px">
      Generate Deposit Address →
    </button>
    <div class="text-dim" style="font-size:11px;margin-top:8px;max-width:440px;line-height:1.6">
      You will receive a unique crypto address to send funds to. Your balance is credited automatically
      after 1 on-chain confirmation via PayGate.to — no KYC, instant forwarding.
    </div>
  </form>
</div>
<?php endif; ?>

<!-- ── Deposit history ────────────────────────────────────────────────────── -->
<?php if (!empty($history)): ?>
<div class="card">
  <div class="section-title" style="margin-bottom:14px">Deposit History</div>
  <div class="table-wrap" style="border:none">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Coin</th>
          <th>USD</th>
          <th>Crypto Amount</th>
          <th>Address</th>
          <th>Status</th>
          <th>Date</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($history as $dep): ?>
      <?php
        $sc = match($dep['status']) {
            'confirmed' => 'badge-green',
            'rejected', 'cancelled' => 'badge-red',
            default     => 'badge-amber',
        };
        $dep_sym  = strtoupper($dep['method'] ?? '?');
        $dep_addr = $dep['deposit_address'] ?? '';
      ?>
      <tr>
        <td class="td-mono"><?= $dep['id'] ?></td>
        <td><span class="badge badge-gray"><?= h($dep_sym) ?></span></td>
        <td class="td-price">$<?= number_format((float)$dep['amount'], 2) ?></td>
        <td class="text-dim" style="font-size:11px;font-family:monospace">
          <?= $dep['cp_amount_crypto'] ? h(substr($dep['cp_amount_crypto'], 0, 14)) : '—' ?>
        </td>
        <td class="text-dim" style="font-size:10px;font-family:monospace;max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
          <?= $dep_addr ? h(substr($dep_addr, 0, 20)) . '…' : '—' ?>
        </td>
        <td><span class="badge <?= $sc ?>"><?= h($dep['status']) ?></span></td>
        <td class="text-dim" style="font-size:11px">
          <?= date('M j Y H:i', (int)$dep['created_at']) ?>
        </td>
        <td>
          <?php if ($dep['status'] === 'pending'): ?>
          <a href="/?p=deposit&show=<?= $dep['id'] ?>" class="btn btn-ghost btn-xs">View</a>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<style>
.coin-tile:hover { border-color:var(--border-2)!important; background:var(--bg-2)!important; }
.coin-tile.selected { border-color:var(--amber)!important; background:rgba(245,158,11,.08)!important; }
</style>

<script>
let currentSymbol = '';

function selectCoin(symbol) {
  currentSymbol = symbol;
  document.getElementById('selected-coin').value = symbol;

  const coinNames = {
    <?php foreach ($enabled_coins as $sym => $c): ?>
    '<?= h($sym) ?>': '<?= h(addslashes($c['name'])) ?> (<?= h($sym) ?>)',
    <?php endforeach; ?>
  };
  document.getElementById('selected-coin-label').textContent = coinNames[symbol] || symbol;

  document.querySelectorAll('.coin-tile').forEach(t => {
    t.classList.toggle('selected', t.dataset.symbol === symbol);
  });
}

function validateForm() {
  if (!currentSymbol) {
    alert('Please select a cryptocurrency.');
    return false;
  }
  const amount = parseFloat(document.getElementById('amount-input').value);
  if (isNaN(amount) || amount < 35) {
    alert('Please enter an amount of at least $35.00.');
    return false;
  }
  return true;
}

<?php if ($active_dep && $active_dep['status'] !== 'confirmed'): ?>
// ── Deposit status polling ────────────────────────────────────────────────────
// PayGate is callback-driven — we poll our own DB status (set by pg_callback.php)
const DEP_ID = <?= (int)$active_dep['id'] ?>;
let pollTimer;

async function checkNow(id) {
  const btn = document.getElementById('check-btn');
  const lc  = document.getElementById('last-checked');
  if (btn) btn.disabled = true;
  if (lc)  lc.textContent = 'Checking…';
  try {
    const r = await fetch('check_deposits.php?id=' + id);
    const d = await r.json();
    if (lc) lc.textContent = 'Last checked: ' + new Date().toLocaleTimeString();

    if (d.txid) {
      const tr = document.getElementById('txid-row');
      const tv = document.getElementById('txid-val');
      if (tr) tr.style.display = 'block';
      if (tv) tv.textContent   = d.txid.substring(0, 28) + '…';
    }

    if (d.status === 'confirmed') {
      clearInterval(pollTimer);
      const badge = document.getElementById('status-badge');
      if (badge) badge.outerHTML = '<span class="badge badge-green" style="font-size:13px;padding:4px 12px">✓ Confirmed</span>';
      const tracker = document.getElementById('confirm-tracker');
      if (tracker) tracker.innerHTML = '<div style="color:#22c55e;font-size:13px;padding:4px 0">✓ Payment confirmed — refreshing…</div>';
      setTimeout(() => location.reload(), 1500);
    } else {
      const sl = document.getElementById('status-label');
      if (sl) sl.textContent = 'Waiting for blockchain confirmation…';
    }
  } catch (e) {
    if (lc) lc.textContent = 'Check failed — retrying…';
  }
  if (btn) btn.disabled = false;
}

function copyAddr() {
  const el = document.getElementById('pay-addr');
  if (el) {
    navigator.clipboard.writeText(el.textContent.trim()).then(() => {
      const btn = document.querySelector('[onclick="copyAddr()"]');
      if (btn) { btn.textContent = '✓'; setTimeout(() => btn.textContent = '⧉', 1500); }
    });
  }
}

checkNow(DEP_ID);
pollTimer = setInterval(() => checkNow(DEP_ID), 20000);
<?php endif; ?>
</script>

<?php
    return ob_get_clean();
}
