<?php
declare(strict_types=1);
/**
 * wallet_functions.php — Replaced by CoinPayments integration
 *
 * The HD wallet / xpub address derivation system has been replaced by the
 * CoinPayments Commerce API (see lib/CoinPayments.php).
 *
 * This stub is kept for backward compatibility in case any code still
 * requires it. All deposit flows now go through CoinPayments::createInvoice().
 */

// No-op stubs so any legacy call doesn't crash
if (!function_exists('derive_deposit_address')) {
    function derive_deposit_address(string $xpub, int $index, string $coin): ?string {
        return null; // Replaced by CoinPayments — not used
    }
}

if (!function_exists('next_deposit_index')) {
    function next_deposit_index(): int {
        return 0; // Replaced by CoinPayments — not used
    }
}
