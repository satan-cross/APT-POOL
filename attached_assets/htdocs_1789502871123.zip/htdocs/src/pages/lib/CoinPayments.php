<?php
declare(strict_types=1);
/**
 * CoinPayments.php — CoinPayments Commerce API v1 client
 *
 * API base: https://api.coinpayments.net
 * Auth:     HMAC-SHA256 over canonical request string (key = base64_decode(CLIENT_SECRET))
 *
 * Public surface:
 *   CoinPayments::getCurrencies()          → full list of supported coins from the API
 *   CoinPayments::createInvoice(...)       → create a hosted payment invoice
 *   CoinPayments::getInvoice($invoice_id)  → poll invoice status
 *   CoinPayments::refreshCurrencies()      → force-refresh the cached currency list
 */
class CoinPayments
{
    // ── Credentials ───────────────────────────────────────────────────────────
    const API_BASE = 'https://api.coinpayments.net';

    /**
     * Read CLIENT_ID from DB settings (key: cp_client_id).
     * Falls back to the hardcoded value if not set.
     */
    public static function clientId(): string
    {
        static $v = null;
        if ($v === null) {
            $v = get_setting('cp_client_id', '');
        }
        return $v;
    }

    /**
     * Read CLIENT_SECRET from DB settings (key: cp_client_secret).
     * Value is stored as base64-encoded bytes, same as the old constant.
     */
    public static function clientSecret(): string
    {
        static $v = null;
        if ($v === null) {
            $v = get_setting('cp_client_secret', '');
        }
        return $v;
    }

    /**
     * Cache TTL for the currencies list (seconds).
     * The list almost never changes; 6 hours is safe.
     */
    const CURRENCIES_TTL = 21600; // 6 hours

    /**
     * Coins to pin at the top of the deposit UI as quick-select tiles.
     * These are just display hints — the full list is fetched from the API.
     * XMR (Monero) intentionally excluded.
     */
    const POPULAR_SYMBOLS = [
        'BTC', 'ETH', 'LTC', 'USDT', 'USDC', 'BNB', 'DOGE', 'SOL',
        'ADA', 'TRX', 'MATIC', 'DASH', 'BCH', 'XRP', 'DOT', 'AVAX',
    ];

    // ── Currency list ─────────────────────────────────────────────────────────

    /**
     * Return all CoinPayments-supported cryptocurrencies.
     *
     * Results are cached in PHP static memory for the lifetime of the request,
     * and in the DB `settings` table for CURRENCIES_TTL seconds between requests.
     *
     * Structure of each item:
     *   ['id' => '5057', 'symbol' => 'BTC', 'name' => 'Bitcoin', 'type' => 'crypto', ...]
     *
     * Returns an empty array on failure (caller should fall back gracefully).
     *
     * @param bool $force_refresh  Bypass the DB cache and re-fetch from the API.
     * @return array<string, array>  Keyed by uppercased symbol.
     */
    public static function getCurrencies(bool $force_refresh = false): array
    {
        static $cache = null;
        if ($cache !== null && !$force_refresh) {
            return $cache;
        }

        // ── Try the DB cache ────────────────────────────────────────────────
        if (!$force_refresh) {
            try {
                $pdo     = db();
                $row_ts  = $pdo->prepare("SELECT value FROM settings WHERE key='cp_currencies_ts'");
                $row_ts->execute();
                $ts      = (int)($row_ts->fetchColumn() ?: 0);
                $age     = time() - $ts;
                if ($age < self::CURRENCIES_TTL) {
                    $row_data = $pdo->prepare("SELECT value FROM settings WHERE key='cp_currencies_json'");
                    $row_data->execute();
                    $json = $row_data->fetchColumn() ?: '';
                    if ($json) {
                        $decoded = json_decode($json, true);
                        if (is_array($decoded) && count($decoded) > 0) {
                            $cache = $decoded;
                            return $cache;
                        }
                    }
                }
            } catch (\Throwable $e) {
                error_log('[CoinPayments::getCurrencies] DB cache read failed: ' . $e->getMessage());
            }
        }

        // ── Fetch live from API ──────────────────────────────────────────────
        $result = self::request('GET', '/api/v1/currencies');
        if (!$result['ok']) {
            error_log('[CoinPayments::getCurrencies] API fetch failed: ' . ($result['error'] ?? 'unknown'));
            // Return cached data even if stale, or empty
            $cache = $cache ?? self::_fallbackCurrencies();
            return $cache;
        }

        $raw = $result['data'];
        // Response shape: { "items": [...] }  or  { "currencies": [...] }  or  [...]
        $items = $raw['items'] ?? ($raw['currencies'] ?? (isset($raw[0]) ? $raw : []));

        if (!is_array($items) || count($items) === 0) {
            error_log('[CoinPayments::getCurrencies] Unexpected response: ' . json_encode(array_slice($raw, 0, 3)));
            $cache = $cache ?? self::_fallbackCurrencies();
            return $cache;
        }

        // Normalise: key by uppercased symbol, exclude XMR
        $by_symbol = [];
        foreach ($items as $c) {
            $symbol = strtoupper((string)($c['symbol'] ?? ''));
            if ($symbol === '' || $symbol === 'XMR') {
                continue;
            }
            // Only include crypto (skip fiat)
            $type = strtolower((string)($c['type'] ?? 'crypto'));
            if ($type === 'fiat') {
                continue;
            }
            $id   = (string)($c['id'] ?? $c['currencyId'] ?? '');
            $name = (string)($c['name'] ?? $c['fullName'] ?? $symbol);
            if ($id === '') {
                continue;
            }
            $by_symbol[$symbol] = [
                'id'     => $id,
                'symbol' => $symbol,
                'name'   => $name,
                'type'   => $type,
            ];
        }

        if (count($by_symbol) === 0) {
            $by_symbol = self::_fallbackCurrencies();
        }

        // Sort: popular first, then alphabetical
        $popular = array_flip(self::POPULAR_SYMBOLS);
        uksort($by_symbol, function (string $a, string $b) use ($popular): int {
            $pa = $popular[$a] ?? 9999;
            $pb = $popular[$b] ?? 9999;
            if ($pa !== $pb) return $pa - $pb;
            return strcmp($a, $b);
        });

        // ── Persist in DB cache ──────────────────────────────────────────────
        try {
            $pdo = db();
            $pdo->prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('cp_currencies_json', ?)")
                ->execute([json_encode($by_symbol)]);
            $pdo->prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('cp_currencies_ts', ?)")
                ->execute([(string)time()]);
        } catch (\Throwable $e) {
            error_log('[CoinPayments::getCurrencies] DB cache write failed: ' . $e->getMessage());
        }

        $cache = $by_symbol;
        return $cache;
    }

    /**
     * Force a fresh fetch from the API, bypassing the DB cache.
     * Returns the new currency list, or false on failure.
     */
    public static function refreshCurrencies(): array|false
    {
        $list = self::getCurrencies(true);
        return count($list) > 0 ? $list : false;
    }

    // ── Invoice operations ────────────────────────────────────────────────────

    /**
     * Create a CoinPayments invoice for any supported coin.
     *
     * @param float  $amount_usd   USD amount the customer should deposit.
     * @param string $symbol       Coin symbol, e.g. 'BTC', 'ETH', 'USDT'. Must exist in getCurrencies().
     * @param string $invoice_ref  Unique reference string stored in the DB (e.g. "dep_42_7").
     * @param string $description  Short description shown on the CoinPayments checkout page.
     *
     * @return array {
     *   ok:             bool,
     *   invoice_id:     string,       // CoinPayments invoice ID — store in DB
     *   checkout_url:   string,       // Hosted checkout URL to show the user
     *   address:        string|null,  // Crypto pay address (if immediately returned)
     *   amount_crypto:  string|null,  // Amount in crypto (if immediately returned)
     *   symbol:         string,
     *   coin_name:      string,
     *   error:          string        // present only on failure
     * }
     */
    public static function createInvoice(
        float  $amount_usd,
        string $symbol,
        string $invoice_ref,
        string $description = 'Account deposit'
    ): array {
        $symbol    = strtoupper($symbol);
        $currencies = self::getCurrencies();
        $coin       = $currencies[$symbol] ?? null;

        if ($coin === null) {
            return ['ok' => false, 'error' => 'Unsupported coin: ' . $symbol . '. Try refreshing the currency list.'];
        }

        if (self::clientId() === '' || self::clientSecret() === '') {
            return ['ok' => false, 'error' => 'CoinPayments API credentials not configured. Please set them in Admin → CoinPayments.'];
        }

        $body = [
            'clientId'    => self::clientId(),
            'invoiceId'   => $invoice_ref,
            'amount'      => [
                'currencyId' => 'USD',   // Bill in USD; CP converts to the selected coin
                'value'      => number_format($amount_usd, 2, '.', ''),
            ],
            'currency'    => $coin['id'],   // Coin the customer pays with
            'description' => $description,
            'requireBuyerNameAndEmail' => false,
        ];

        $result = self::request('POST', '/api/v1/merchant/invoices', $body);

        if (!$result['ok']) {
            return ['ok' => false, 'error' => $result['error'] ?? 'API request failed'];
        }

        $data = $result['data'] ?? [];

        // Response can be nested under 'invoice' key
        $inv          = $data['invoice'] ?? $data;
        $invoice_id   = (string)($inv['id'] ?? '');
        $checkout_url = (string)($inv['checkoutUrl'] ?? '');

        // Payment address (if immediately available — depends on coin)
        $pay           = $inv['payment'] ?? [];
        $address       = $pay['address'] ?? null;
        $amount_crypto = $pay['amount']  ?? null;

        if ($invoice_id === '') {
            error_log('[CoinPayments::createInvoice] No ID in response: ' . json_encode($data));
            return ['ok' => false, 'error' => 'CoinPayments did not return an invoice ID. Response: ' . json_encode(array_slice($data, 0, 5))];
        }

        return [
            'ok'            => true,
            'invoice_id'    => $invoice_id,
            'checkout_url'  => $checkout_url,
            'address'       => $address,
            'amount_crypto' => $amount_crypto,
            'symbol'        => $coin['symbol'],
            'coin_name'     => $coin['name'],
        ];
    }

    /**
     * Fetch the current status of an invoice.
     *
     * @param string $invoice_id  The CoinPayments invoice ID (from createInvoice).
     *
     * @return array {
     *   ok:             bool,
     *   status:         string,       // 'pending' | 'confirmed' | 'cancelled'
     *   confirmations:  int,
     *   txid:           string|null,
     *   address:        string|null,
     *   amount_crypto:  string|null,
     *   checkout_url:   string|null,
     *   error:          string        // present only on failure
     * }
     */
    public static function getInvoice(string $invoice_id): array
    {
        $result = self::request('GET', '/api/v1/merchant/invoices/' . rawurlencode($invoice_id));

        if (!$result['ok']) {
            return [
                'ok'            => false,
                'status'        => 'unknown',
                'confirmations' => 0,
                'txid'          => null,
                'error'         => $result['error'] ?? 'API request failed',
            ];
        }

        $data = $result['data'] ?? [];
        $inv  = $data['invoice'] ?? $data;

        // Normalise status string
        $raw_status = strtolower((string)($inv['status'] ?? 'unknown'));
        $status = match (true) {
            in_array($raw_status, ['complete', 'completed', 'paid', 'confirmed']) => 'confirmed',
            in_array($raw_status, ['cancelled', 'canceled', 'expired'])           => 'cancelled',
            default                                                                 => 'pending',
        };

        $pay           = $inv['payment'] ?? [];
        $address       = $pay['address']       ?? null;
        $amount_crypto = $pay['amount']         ?? null;
        $txid          = $pay['txid']           ?? ($pay['transactionId'] ?? null);
        $confirmations = (int)($pay['confirmations'] ?? ($inv['confirmations'] ?? 0));
        $checkout_url  = $inv['checkoutUrl']    ?? null;

        return [
            'ok'            => true,
            'status'        => $status,
            'confirmations' => $confirmations,
            'txid'          => $txid,
            'address'       => $address,
            'amount_crypto' => $amount_crypto,
            'checkout_url'  => $checkout_url,
        ];
    }

    // ── Internal HTTP helpers ─────────────────────────────────────────────────

    /**
     * Make an authenticated request to the CoinPayments API.
     *
     * @param string $method  'GET' or 'POST'
     * @param string $path    API path, e.g. '/api/v1/invoices'
     * @param array  $body    Payload for POST requests (JSON-encoded automatically).
     *
     * @return array { ok: bool, data: array, error: string }
     */
    private static function request(string $method, string $path, array $body = []): array
    {
        $method    = strtoupper($method);
        $timestamp = (string)time();
        $host      = parse_url(self::API_BASE, PHP_URL_HOST);
        $json_body = ($method === 'POST' && !empty($body))
            ? json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            : '';
        $query     = '';

        $signature = self::sign($method, $host, $path, $query, $timestamp, $json_body);

        $headers = [
            'Content-Type: application/json',
            'X-CoinPayments-Client-Id: ' . self::clientId(),
            'X-CoinPayments-Timestamp: ' . $timestamp,
            'X-CoinPayments-Signature: ' . $signature,
        ];

        $url = self::API_BASE . $path;
        if (!function_exists('curl_init')) {
            return ['ok' => false, 'error' => 'cURL is not available on this server'];
        }

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_FOLLOWLOCATION => true,
        ]);

        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $json_body);
        }

        $raw       = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_err  = curl_error($ch);
        curl_close($ch);

        if ($raw === false) {
            error_log('[CoinPayments] cURL error on ' . $method . ' ' . $path . ': ' . $curl_err);
            return ['ok' => false, 'error' => 'Network error: ' . $curl_err];
        }

        $decoded = json_decode((string)$raw, true);
        if (!is_array($decoded)) {
            error_log('[CoinPayments] Non-JSON response (' . $http_code . ') for ' . $method . ' ' . $path . ': ' . substr($raw, 0, 500));
            return ['ok' => false, 'error' => 'Non-JSON response from CoinPayments (HTTP ' . $http_code . ')'];
        }

        if ($http_code < 200 || $http_code >= 300) {
            $raw_msg = $decoded['message'] ?? ($decoded['error'] ?? ('HTTP ' . $http_code));
            error_log('[CoinPayments] API error ' . $http_code . ' on ' . $method . ' ' . $path . ': ' . json_encode($decoded));
            // Detect rate-limit / quota errors
            $err_lower = strtolower((string)$raw_msg);
            if ($http_code === 429 || str_contains($err_lower, 'quota') || str_contains($err_lower, 'rate limit') || str_contains($err_lower, 'daily')) {
                $err_msg = 'quota_exceeded';
            } else {
                $err_msg = $raw_msg;
            }
            return ['ok' => false, 'error' => $err_msg, 'quota' => ($err_msg === 'quota_exceeded'), 'data' => $decoded];
        }

        return ['ok' => true, 'data' => $decoded];
    }

    /**
     * Compute the HMAC-SHA256 request signature.
     *
     * Canonical string (newline-joined):
     *   CLIENT_ID · TIMESTAMP · METHOD · HOST · PATH · QUERY_STRING · SHA256_HEX(BODY)
     * Key: base64_decode(CLIENT_SECRET)
     * Output: base64_encode(raw HMAC bytes)
     */
    private static function sign(
        string $method,
        string $host,
        string $path,
        string $query,
        string $timestamp,
        string $body
    ): string {
        $body_hash = hash('sha256', $body);  // lowercase hex SHA-256 of body
        $message   = implode("\n", [self::clientId(), $timestamp, $method, $host, $path, $query, $body_hash]);
        $key       = base64_decode(self::clientSecret());
        return base64_encode(hash_hmac('sha256', $message, $key, true));
    }

    // ── Fallback currency list ────────────────────────────────────────────────

    /**
     * Static fallback shown while the live API list has never been fetched.
     * XMR intentionally excluded.
     */
    private static function _fallbackCurrencies(): array
    {
        return [
            'BTC'   => ['id' => '5057', 'symbol' => 'BTC',   'name' => 'Bitcoin',           'type' => 'crypto'],
            'ETH'   => ['id' => '5060', 'symbol' => 'ETH',   'name' => 'Ethereum',           'type' => 'crypto'],
            'LTC'   => ['id' => '5058', 'symbol' => 'LTC',   'name' => 'Litecoin',           'type' => 'crypto'],
            'USDT'  => ['id' => '5776', 'symbol' => 'USDT',  'name' => 'Tether (ERC-20)',    'type' => 'crypto'],
            'USDC'  => ['id' => '5780', 'symbol' => 'USDC',  'name' => 'USD Coin',           'type' => 'crypto'],
            'BNB'   => ['id' => '5714', 'symbol' => 'BNB',   'name' => 'BNB',                'type' => 'crypto'],
            'DOGE'  => ['id' => '5061', 'symbol' => 'DOGE',  'name' => 'Dogecoin',           'type' => 'crypto'],
            'SOL'   => ['id' => '5714', 'symbol' => 'SOL',   'name' => 'Solana',             'type' => 'crypto'],
            'ADA'   => ['id' => '5065', 'symbol' => 'ADA',   'name' => 'Cardano',            'type' => 'crypto'],
            'TRX'   => ['id' => '5068', 'symbol' => 'TRX',   'name' => 'Tron',               'type' => 'crypto'],
            'BCH'   => ['id' => '5063', 'symbol' => 'BCH',   'name' => 'Bitcoin Cash',       'type' => 'crypto'],
            'DASH'  => ['id' => '5062', 'symbol' => 'DASH',  'name' => 'Dash',               'type' => 'crypto'],
            'XRP'   => ['id' => '5067', 'symbol' => 'XRP',   'name' => 'XRP',                'type' => 'crypto'],
            'MATIC' => ['id' => '5956', 'symbol' => 'MATIC', 'name' => 'Polygon',            'type' => 'crypto'],
            'DOT'   => ['id' => '5966', 'symbol' => 'DOT',   'name' => 'Polkadot',           'type' => 'crypto'],
            'AVAX'  => ['id' => '5971', 'symbol' => 'AVAX',  'name' => 'Avalanche',          'type' => 'crypto'],
            'LINK'  => ['id' => '5905', 'symbol' => 'LINK',  'name' => 'Chainlink',          'type' => 'crypto'],
            'SHIB'  => ['id' => '5990', 'symbol' => 'SHIB',  'name' => 'Shiba Inu',         'type' => 'crypto'],
            'UNI'   => ['id' => '5924', 'symbol' => 'UNI',   'name' => 'Uniswap',           'type' => 'crypto'],
            'ATOM'  => ['id' => '5966', 'symbol' => 'ATOM',  'name' => 'Cosmos',            'type' => 'crypto'],
            'ETC'   => ['id' => '5064', 'symbol' => 'ETC',   'name' => 'Ethereum Classic',  'type' => 'crypto'],
            'ZEC'   => ['id' => '5066', 'symbol' => 'ZEC',   'name' => 'Zcash',             'type' => 'crypto'],
            'XLM'   => ['id' => '5069', 'symbol' => 'XLM',   'name' => 'Stellar',           'type' => 'crypto'],
        ];
    }
}
