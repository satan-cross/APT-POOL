<?php
declare(strict_types=1);
/**
 * index.php — Main application router
 *
 * All pages are routed through here via ?p=<page_name>.
 * Each page file defines a page_<name>(): string function that returns HTML.
 */

require_once __DIR__ . '/init.php';

// ── Load page modules ─────────────────────────────────────────────────────────
foreach (['login','dashboard','marketplace','cart','orders','deposit','withdraw',
          'seller','become_seller','support','admin'] as $_page) {
    require_once __DIR__ . '/' . $_page . '.php';
}

// ── Route ─────────────────────────────────────────────────────────────────────
$p = preg_replace('/[^a-z_]/', '', strtolower(get('p', 'marketplace')));
if ($p === '') $p = 'marketplace';

// Public routes (no auth required)
$public = ['login'];

if (!is_logged_in() && !in_array($p, $public, true)) {
    header('Location: /?p=login');
    exit;
}

// Dispatch to page function
$fn = 'page_' . $p;
if (!function_exists($fn)) {
    $fn = function() { return '<div class="card empty-state"><h3>Page not found</h3><p class="text-muted">The page you are looking for does not exist.</p><a href="/" class="btn btn-primary mt-16">Go Home</a></div>'; };
}

$content = call_user_func($fn);
$flash   = get_flash();
$user    = is_logged_in() ? current_user() : null;

// ── Render full shell ─────────────────────────────────────────────────────────
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>BytePool — Crypto Mining Pool</title>
<style>
/* ── Reset ── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{font-size:14px;-webkit-font-smoothing:antialiased}
body{background:#09090b;color:#e4e4e7;font-family:system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;min-height:100vh;display:flex;flex-direction:column}
a{color:inherit;text-decoration:none}
img{display:block;max-width:100%}
button,input,select,textarea{font:inherit}
ul,ol{list-style:none}

/* ── CSS Variables ── */
:root{
  --bg:        #09090b;
  --bg-2:      #18181b;
  --bg-3:      #27272a;
  --border:    #27272a;
  --border-2:  #3f3f46;
  --text-1:    #e4e4e7;
  --text-2:    #a1a1aa;
  --text-3:    #71717a;
  --red:       #db143c;
  --red-2:     #ef4444;
  --green:     #22c55e;
  --amber:     #f59e0b;
  --purple:    #a855f7;
  --indigo:    #6366f1;
  --glow-red:  0 0 16px rgba(219,20,60,.35);
  --glow-green:0 0 16px rgba(34,197,94,.25);
}

/* ── Layout ── */
.shell{display:flex;flex:1;min-height:100vh}
.sidebar{width:220px;background:var(--bg-2);border-right:1px solid var(--border);display:flex;flex-direction:column;flex-shrink:0;position:sticky;top:0;height:100vh;overflow-y:auto}
.main{flex:1;min-width:0;display:flex;flex-direction:column}
.content{flex:1;padding:28px 32px;max-width:1400px;width:100%}

/* ── Sidebar ── */
.sidebar-logo{padding:20px 20px 12px;border-bottom:1px solid var(--border);margin-bottom:8px}
.sidebar-logo .hero{font-size:16px;font-weight:800;letter-spacing:-.3px;color:var(--text-1)}
.sidebar-logo .hero span{color:var(--red)}
.sidebar-logo .sub{font-size:11px;color:var(--text-3);margin-top:2px}
.nav-section{padding:6px 12px 2px;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--text-3);margin-top:8px}
.nav-link{display:flex;align-items:center;gap:9px;padding:8px 12px;border-radius:8px;margin:1px 8px;font-size:13px;font-weight:500;color:var(--text-2);transition:all .12s;cursor:pointer}
.nav-link:hover{background:var(--bg-3);color:var(--text-1)}
.nav-link.active{background:rgba(219,20,60,.12);color:var(--red);font-weight:600}
.nav-link .icon{width:16px;text-align:center;font-style:normal;flex-shrink:0}
.sidebar-footer{padding:12px;border-top:1px solid var(--border);margin-top:auto}
.user-chip{display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:8px;background:var(--bg-3)}
.user-avatar{width:28px;height:28px;border-radius:50%;background:rgba(219,20,60,.2);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:var(--red);flex-shrink:0}
.user-info .name{font-size:12px;font-weight:600;color:var(--text-1);line-height:1.2}
.user-info .role{font-size:10px;color:var(--text-3);text-transform:capitalize}
.user-balance{font-size:11px;font-weight:700;color:var(--green);margin-left:auto;white-space:nowrap}

/* ── Top header ── */
.topheader{padding:12px 32px;border-bottom:1px solid var(--border);background:rgba(9,9,11,.8);backdrop-filter:blur(12px);display:flex;align-items:center;gap:12px;min-height:54px}
.breadcrumb{font-size:13px;color:var(--text-3)}
.breadcrumb span{color:var(--text-1);font-weight:600}
.header-actions{margin-left:auto;display:flex;align-items:center;gap:8px}
.shop-status{display:inline-flex;align-items:center;gap:6px;padding:4px 10px;border-radius:99px;font-size:11px;font-weight:700}
.shop-open{background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.25);color:var(--green)}
.shop-closed{background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.25);color:var(--red-2)}
.dot{width:6px;height:6px;border-radius:50%;flex-shrink:0}
.dot-green{background:var(--green)}
.dot-red{background:var(--red-2);animation:blink 1.2s ease-in-out infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.35}}

/* ── Buttons ── */
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:8px 16px;border-radius:8px;border:none;font-size:13px;font-weight:600;cursor:pointer;transition:all .15s;line-height:1;white-space:nowrap;vertical-align:middle}
.btn svg{width:14px;height:14px;flex-shrink:0}
.btn-primary{background:var(--red);color:#fff}.btn-primary:hover{background:#b01030}
.btn-secondary{background:var(--bg-3);color:var(--text-1);border:1px solid var(--border-2)}.btn-secondary:hover{border-color:var(--text-3)}
.btn-ghost{background:transparent;border:1px solid var(--border-2);color:var(--text-2)}.btn-ghost:hover{color:var(--text-1);border-color:var(--text-3)}
.btn-danger{background:rgba(239,68,68,.15);color:var(--red-2);border:1px solid rgba(239,68,68,.2)}.btn-danger:hover{background:rgba(239,68,68,.25)}
.btn-green{background:#16a34a;color:#fff}.btn-green:hover{background:#15803d}
.btn-warning{background:#d97706;color:#fff}.btn-warning:hover{background:#b45309}
.btn-sm{padding:5px 12px;font-size:12px}
.btn-xs{padding:3px 8px;font-size:11px;border-radius:6px}
.btn:disabled{opacity:.45;cursor:not-allowed}
.w-full{width:100%}

/* ── Cards / containers ── */
.card{background:var(--bg-2);border:1px solid var(--border);border-radius:12px;padding:20px 24px;margin-bottom:16px}
.card:last-child{margin-bottom:0}
.section-title{font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--text-3);margin-bottom:16px}
.topbar{display:flex;align-items:center;gap:12px;margin-bottom:24px;flex-wrap:wrap}
.page-title{font-size:20px;font-weight:800;letter-spacing:-.3px;flex:1;min-width:0}
.page-title span{color:var(--red)}

/* ── Alerts / flash ── */
.alert{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:14px;display:flex;align-items:flex-start;gap:8px}
.alert-success{background:rgba(34,197,94,.08);border:1px solid rgba(34,197,94,.25);color:#86efac}
.alert-error  {background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.25);color:#fca5a5}
.alert-info   {background:rgba(99,102,241,.08);border:1px solid rgba(99,102,241,.25);color:#a5b4fc}
.alert-warn   {background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.25);color:#fde68a}

/* ── Stat grid ── */
.stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;margin-bottom:20px}
.stat-card{background:var(--bg-2);border:1px solid var(--border);border-radius:10px;padding:16px 18px}
.stat-label{font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:var(--text-3);margin-bottom:6px}
.stat-value{font-size:22px;font-weight:800;letter-spacing:-.5px;line-height:1}
.stat-value.green{color:var(--green)}
.stat-value.red{color:var(--red)}
.stat-sub{font-size:11px;color:var(--text-3);margin-top:4px}

/* ── Tables ── */
.table-wrap{border:1px solid var(--border);border-radius:10px;overflow:auto;margin-bottom:16px}
table{width:100%;border-collapse:collapse;font-size:13px}
thead{background:rgba(255,255,255,.02)}
th{padding:10px 14px;text-align:left;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--text-3);white-space:nowrap;border-bottom:1px solid var(--border)}
td{padding:10px 14px;border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.02)}
.td-mono{font-family:ui-monospace,monospace;font-size:12px}
.td-price{font-weight:700;color:var(--red)}

/* ── Badges ── */
.badge{display:inline-flex;align-items:center;padding:2px 8px;border-radius:99px;font-size:11px;font-weight:700;white-space:nowrap}
.badge-green {background:rgba(34,197,94,.15); color:var(--green); border:1px solid rgba(34,197,94,.25)}
.badge-red   {background:rgba(239,68,68,.15);  color:var(--red-2); border:1px solid rgba(239,68,68,.25)}
.badge-amber {background:rgba(245,158,11,.15); color:var(--amber); border:1px solid rgba(245,158,11,.25)}
.badge-purple{background:rgba(168,85,247,.15); color:var(--purple);border:1px solid rgba(168,85,247,.25)}
.badge-gray  {background:rgba(113,113,122,.15);color:var(--text-2);border:1px solid rgba(113,113,122,.2)}
.badge-blue  {background:rgba(59,130,246,.15); color:#60a5fa;      border:1px solid rgba(59,130,246,.25)}

/* ── Forms ── */
.form-group{margin-bottom:14px}
.form-label,.form-label-text{display:block;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--text-3);margin-bottom:5px}
.form-input,.form-select,.form-textarea{width:100%;background:var(--bg);border:1px solid var(--border-2);border-radius:8px;color:var(--text-1);padding:9px 12px;font-size:13px;transition:border-color .15s}
.form-input:focus,.form-select:focus,.form-textarea:focus{outline:none;border-color:var(--indigo)}
.form-textarea{resize:vertical;font-family:ui-monospace,monospace;font-size:12px}
select,input[type=text],input[type=password],input[type=email],input[type=number],input[type=search],textarea{background:var(--bg);border:1px solid var(--border-2);border-radius:8px;color:var(--text-1);padding:9px 12px;font-size:13px;transition:border-color .15s}
select:focus,input:focus,textarea:focus{outline:none;border-color:var(--indigo)}

/* ── Grid helpers ── */
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.grid-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
.flex{display:flex;align-items:center}
.flex-col{display:flex;flex-direction:column}
.gap-8{gap:8px}
.gap-12{gap:12px}
.gap-16{gap:16px}
.flex-wrap{flex-wrap:wrap}

/* ── Spacing helpers ── */
.mt-4 {margin-top:4px}.mt-8{margin-top:8px}.mt-12{margin-top:12px}.mt-16{margin-top:16px}.mt-24{margin-top:24px}
.mb-4 {margin-bottom:4px}.mb-8{margin-bottom:8px}.mb-12{margin-bottom:12px}.mb-16{margin-bottom:16px}

/* ── Text helpers ── */
.text-xs{font-size:11px}.text-sm{font-size:12px}.text-muted{color:var(--text-2)}.text-dim{color:var(--text-3)}
.text-red{color:var(--red)}.text-green{color:var(--green)}.text-amber{color:var(--amber)}.text-mono{font-family:ui-monospace,monospace}
.font-bold{font-weight:700}.font-mono{font-family:ui-monospace,monospace}
.truncate{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

/* ── Misc ── */
.empty-state{text-align:center;padding:48px 24px;color:var(--text-3)}
.empty-state h3{font-size:16px;font-weight:700;color:var(--text-2);margin-bottom:8px}
.empty-state p{font-size:13px;margin-bottom:0}
.divider{height:1px;background:var(--border);margin:20px 0}
.timer-badge{display:inline-flex;align-items:center;gap:5px;padding:4px 10px;border-radius:99px;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);font-size:12px;font-weight:700;color:var(--red-2)}

/* ── Login page ── */
.login-shell{display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;background:var(--bg)}
.login-box{width:100%;max-width:400px;background:var(--bg-2);border:1px solid var(--border);border-radius:16px;padding:32px 28px}
.login-logo{text-align:center;margin-bottom:24px}
.login-logo .hero{font-size:24px;font-weight:800;color:var(--text-1)}
.login-logo .hero span{color:var(--red)}
.login-logo .sub{font-size:12px;color:var(--text-3);margin-top:4px}
.login-tabs{display:flex;gap:4px;background:var(--bg);border-radius:8px;padding:3px;margin-bottom:20px}
.login-tab{flex:1;padding:7px;border-radius:6px;border:none;background:transparent;color:var(--text-3);font-size:13px;font-weight:600;cursor:pointer;transition:all .15s}
.login-tab.active{background:var(--bg-2);color:var(--text-1);box-shadow:0 1px 4px rgba(0,0,0,.4)}
.login-form-wrap .form-group{margin-bottom:12px}

/* ── Tabs ── */
.tabs{display:flex;gap:2px;border-bottom:1px solid var(--border);margin-bottom:24px;flex-wrap:wrap}
.tab{padding:10px 16px;font-size:13px;font-weight:600;color:var(--text-3);border-bottom:2px solid transparent;cursor:pointer;transition:color .15s;margin-bottom:-1px;background:none;border-top:none;border-left:none;border-right:none}
.tab:hover{color:var(--text-1)}
.tab.active{color:var(--text-1);border-bottom-color:var(--red)}
.tab-content{display:none}.tab-content.active{display:block}

/* ── Code / mono blocks ── */
.code-block{background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:12px 16px;font-family:ui-monospace,monospace;font-size:12px;color:var(--text-2);word-break:break-all;line-height:1.7}

/* ── Responsive ── */
@media(max-width:768px){
  .sidebar{display:none}
  .content{padding:16px}
  .topheader{padding:10px 16px}
  .stat-grid{grid-template-columns:1fr 1fr}
  .grid-2,.grid-3{grid-template-columns:1fr}
}
</style>
</head>
<body>

<?php if ($p === 'login'): ?>
  <?= $content ?>
<?php else: ?>
<div class="shell">
  <!-- ── Sidebar ── -->
  <aside class="sidebar">
    <div class="sidebar-logo">
       <div class="hero">Task<span>Console</span></div>
       <div class="sub">Crypto Mining Pool</div>
    </div>

    <nav>
      <div class="nav-section">Main</div>
       <a class="nav-link <?= $p==='marketplace'?'active':'' ?>" href="/?p=marketplace">
         <i class="icon">◈</i> Task Console
      </a>
      <a class="nav-link <?= $p==='cart'?'active':'' ?>" href="/?p=cart">
        <i class="icon">🛒</i> Cart
      </a>
      <a class="nav-link <?= $p==='orders'?'active':'' ?>" href="/?p=orders">
        <i class="icon">📋</i> Orders
      </a>

      <div class="nav-section">Account</div>
      <a class="nav-link <?= $p==='dashboard'?'active':'' ?>" href="/?p=dashboard">
        <i class="icon">📊</i> Dashboard
      </a>
      <a class="nav-link <?= $p==='deposit'?'active':'' ?>" href="/?p=deposit">
        <i class="icon">💰</i> Deposit
      </a>
      <a class="nav-link <?= $p==='support'?'active':'' ?>" href="/?p=support">
        <i class="icon">🎫</i> Support
      </a>

      <?php if (in_array($user['role'] ?? '', ['seller','admin'])): ?>
      <div class="nav-section">Seller</div>
      <a class="nav-link <?= $p==='seller'?'active':'' ?>" href="/?p=seller">
        <i class="icon">💳</i> My Cards
      </a>
      <a class="nav-link <?= $p==='withdraw'?'active':'' ?>" href="/?p=withdraw">
        <i class="icon">💸</i> Withdraw
      </a>
      <?php elseif (($user['role'] ?? '') === 'buyer'): ?>
      <div class="nav-section">Seller</div>
      <a class="nav-link <?= $p==='become_seller'?'active':'' ?>" href="/?p=become_seller">
        <i class="icon">⚡</i> Become Seller
      </a>
      <?php endif; ?>

      <?php if (($user['role'] ?? '') === 'admin'): ?>
      <div class="nav-section">Admin</div>
      <a class="nav-link <?= $p==='admin'?'active':'' ?>" href="/?p=admin">
        <i class="icon">🛠</i> Admin Panel
      </a>
      <a class="nav-link <?= $p==='wallet_setup'?'active':'' ?>" href="/wallet_setup.php">
        <i class="icon">🔑</i> Wallet Setup
      </a>
      <?php endif; ?>
    </nav>

    <div class="sidebar-footer">
      <?php if ($user): ?>
      <div class="user-chip">
        <div class="user-avatar"><?= strtoupper(substr($user['username'],0,1)) ?></div>
        <div class="user-info">
          <div class="name"><?= h($user['username']) ?></div>
          <div class="role"><?= h($user['role']) ?></div>
        </div>
        <div class="user-balance">$<?= number_format((float)$user['balance'],2) ?></div>
      </div>
      <a href="/?p=login&action=logout" class="btn btn-ghost w-full mt-8" style="font-size:12px;padding:6px">Sign Out</a>
      <?php endif; ?>
    </div>
  </aside>

  <!-- ── Main ── -->
  <div class="main">
    <header class="topheader">
      <div class="breadcrumb"><span><?= h($p === 'marketplace' ? 'Task Console' : ucfirst(str_replace('_',' ',$p))) ?></span></div>
      <div class="header-actions">
        <?php $open = shop_is_open(); ?>
        <div class="shop-status <?= $open?'shop-open':'shop-closed' ?>">
          <span class="dot <?= $open?'dot-green':'dot-red' ?>"></span>
          Shop <?= $open?'Open':'Closed' ?>
        </div>
        <?php if ($user): ?>
        <div style="font-size:12px;color:var(--text-3)">
          Balance: <strong style="color:var(--green)">$<?= number_format((float)$user['balance'],2) ?></strong>
        </div>
        <?php endif; ?>
      </div>
    </header>

    <div class="content">
      <!-- Flash messages -->
      <?php foreach ($flash as $f):
        $cls = match($f['type']) {
          'success' => 'alert-success',
          'error'   => 'alert-error',
          'warn'    => 'alert-warn',
          default   => 'alert-info',
        };
      ?>
      <div class="alert <?= $cls ?>"><?= h($f['msg']) ?></div>
      <?php endforeach; ?>

      <!-- Page content -->
      <?= $content ?>
    </div>
  </div>
</div>
<?php endif; ?>

<script>
// ── Countdown timers ─────────────────────────────────────────────────────────
document.querySelectorAll('[data-countdown]').forEach(el => {
  let secs = parseInt(el.dataset.countdown, 10);
  const fmt = s => {
    const m = Math.floor(s / 60), sec = s % 60;
    return m + ':' + String(sec).padStart(2, '0');
  };
  el.textContent = fmt(secs);
  const iv = setInterval(() => {
    secs = Math.max(0, secs - 1);
    el.textContent = fmt(secs);
    if (secs === 0) { clearInterval(iv); location.reload(); }
  }, 1000);
});

// ── Login tab switcher ────────────────────────────────────────────────────────
document.querySelectorAll('.login-tab').forEach(btn => {
  btn.addEventListener('click', () => {
    const tab = btn.dataset.tab;
    document.querySelectorAll('.login-tab').forEach(b => b.classList.toggle('active', b===btn));
    document.querySelectorAll('[data-form]').forEach(f => f.style.display = f.dataset.form===tab?'':'none');
  });
});

// ── Generic tab panels ────────────────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(btn => {
  btn.addEventListener('click', () => {
    const target = btn.dataset.tab;
    if (!target) return;
    const container = btn.closest('[data-tabs]') || document.body;
    container.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b===btn));
    container.querySelectorAll('.tab-content').forEach(c => c.classList.toggle('active', c.id===target));
  });
});
</script>
</body>
</html>
