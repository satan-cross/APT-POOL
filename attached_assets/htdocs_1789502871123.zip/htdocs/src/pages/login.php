<?php
declare(strict_types=1);

function page_login(): string {
    // Handle logout
    if (get('action') === 'logout') {
        do_logout();
        header('Location: /?p=login');
        exit;
    }

    // If already logged in, go home
    if (is_logged_in()) {
        header('Location: /?p=marketplace');
        exit;
    }

    $error = '';
    $tab   = !empty($_SESSION['pending_admin_id']) ? 'setup' : 'login';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = post('action', 'login');

        if ($action === 'login') {
            $username = post('username');
            $password = post('password');
            $pending = db()->prepare("SELECT * FROM users WHERE username=? AND role='admin' AND password=''");
            $pending->execute([trim($username)]);
            $pending_admin = $pending->fetch();
            if ($pending_admin) {
                $_SESSION['pending_admin_id'] = (int)$pending_admin['id'];
                $_SESSION['pending_admin_username'] = $pending_admin['username'];
                $tab = 'setup';
            } elseif (do_login($username, $password)) {
                header('Location: /?p=marketplace');
                exit;
            }
            if ($tab === 'login') $error = 'Invalid username or password.';
        } elseif ($action === 'setup_admin_password') {
            $tab = 'setup';
            $admin_id = (int)($_SESSION['pending_admin_id'] ?? 0);
            $password = (string)post('password');
            $confirm  = (string)post('confirm_password');
            if ($admin_id <= 0) {
                $error = 'Enter the new admin username first.';
            } elseif (strlen($password) < 6) {
                $error = 'Password too short (min 6 characters).';
            } elseif ($password !== $confirm) {
                $error = 'Passwords do not match.';
            } else {
                db()->prepare("UPDATE users SET password=? WHERE id=? AND role='admin' AND password=''")
                    ->execute([password_hash($password, PASSWORD_BCRYPT), $admin_id]);
                $row = db()->prepare('SELECT username FROM users WHERE id=?');
                $row->execute([$admin_id]);
                unset($_SESSION['pending_admin_id'], $_SESSION['pending_admin_username']);
                do_login((string)$row->fetchColumn(), $password);
                header('Location: /?p=marketplace');
                exit;
            }
        } elseif ($action === 'register') {
            $tab = 'register';
            $username = post('username');
            $password = post('password');
            $telegram_username = post('telegram_username');
            $result   = do_register($username, $password, $telegram_username);
            if ($result['ok']) {
                do_login($username, $password);
                header('Location: /?p=marketplace');
                exit;
            }
            $error = $result['msg'];
        }
    }

    ob_start(); ?>
<div class="login-shell">
  <div class="login-box">
    <div class="login-logo">
      <div class="hero">BYTEPOOL</div>
      <div class="sub">Crypto Mining Pool</div>
    </div>

    <?php if ($error): ?>
      <div class="alert alert-error"><?= h($error) ?></div>
    <?php endif; ?>

    <?php if ($tab !== 'setup'): ?><div class="login-tabs">
      <button class="login-tab <?= $tab==='login'?'active':'' ?>" data-tab="login">Sign In</button>
      <button class="login-tab <?= $tab==='register'?'active':'' ?>" data-tab="register">Register</button>
    </div><?php endif; ?>

    <!-- LOGIN FORM -->
    <div class="login-form-wrap">
      <?php if ($tab === 'setup'): ?>
      <form class="login-form" method="POST">
        <input type="hidden" name="action" value="setup_admin_password">
        <div class="alert alert-info">Admin account <strong><?= h($_SESSION['pending_admin_username'] ?? '') ?></strong> needs a password.</div>
        <div class="form-group"><label class="form-label">New Password</label>
          <input class="form-input" type="password" name="password" minlength="6" autocomplete="new-password" required></div>
        <div class="form-group"><label class="form-label">Confirm Password</label>
          <input class="form-input" type="password" name="confirm_password" minlength="6" autocomplete="new-password" required></div>
        <button class="btn btn-primary w-full mt-8" style="width:100%;justify-content:center">Set Admin Password</button>
      </form>
      <?php endif; ?>
      <form class="login-form" data-form="login" method="POST" style="<?= $tab!=='login'?'display:none':'' ?>">
        <input type="hidden" name="action" value="login">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input class="form-input" name="username" placeholder="username" autocomplete="username" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input class="form-input" type="password" name="password" placeholder="••••••••" autocomplete="current-password" required>
        </div>
        <button class="btn btn-primary w-full mt-8" style="width:100%;justify-content:center">Sign In</button>
      </form>

      <!-- REGISTER FORM -->
      <form class="login-form" data-form="register" method="POST" style="<?= $tab!=='register'?'display:none':'' ?>">
        <input type="hidden" name="action" value="register">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input class="form-input" name="username" placeholder="choose a username" required>
        </div>
        <div class="form-group">
          <label class="form-label">Telegram username (optional)</label>
          <input class="form-input" type="text" name="telegram_username" placeholder="@user" autocomplete="off">
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input class="form-input" type="password" name="password" placeholder="min 6 characters" required>
        </div>
        <button class="btn btn-primary w-full mt-8" style="width:100%;justify-content:center">Create Account</button>
        <p class="text-xs text-dim mt-8" style="text-align:center">No bond required. Instant activation.</p>
      </form>
    </div>
  </div>
</div>
<?php
    return ob_get_clean();
}
