<?php
declare(strict_types=1);

function page_withdraw(): string {
    require_login();
    $user = current_user();
    if (!in_array($user['role'], ['seller', 'admin'])) {
        header('Location: /?p=become_seller'); exit;
    }

    $uid = (int)$_SESSION['user_id'];
    $pdo = db();

    // Reload fresh user balance
    $fresh = $pdo->prepare('SELECT * FROM users WHERE id=?');
    $fresh->execute([$uid]);
    $user = $fresh->fetch();
    $_SESSION['user'] = $user;

    $fee_pct = (float)get_setting('withdrawal_fee_pct', '0');
    $min_wd  = (float)get_setting('withdrawal_min',     '10');

    // ── POST: submit withdrawal request ─────────────────────────
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $act = post('action');

        if ($act === 'request_withdrawal') {
            $amount  = round((float)post('amount', 0), 2);
            $method  = post('method', '');
            $address = trim(post('wallet_address', ''));

            // Validate
            $errors = [];
            if ($amount < $min_wd)               $errors[] = "Minimum withdrawal is \${$min_wd}.";
            if ($amount > (float)$user['balance']) $errors[] = 'Amount exceeds your available balance.';
            if (empty($method))                   $errors[] = 'Select a crypto method.';
            if (empty($address))                  $errors[] = 'Enter a wallet address.';
            if (!validate_wallet_address($address, $method)) {
                $errors[] = 'Wallet address format is invalid for ' . h($method) . '.';
            }

            // Check for an existing pending withdrawal
            $pending = $pdo->prepare("SELECT COUNT(*) FROM withdrawals WHERE user_id=? AND status='pending'");
            $pending->execute([$uid]);
            if ((int)$pending->fetchColumn() > 0) {
                $errors[] = 'You already have a pending withdrawal. Please wait for it to be processed.';
            }

            if ($errors) {
                foreach ($errors as $e) flash($e, 'error');
                header('Location: /?p=withdraw'); exit;
            }

            $fee        = round($amount * $fee_pct / 100, 8);
            $net_amount = round($amount - $fee, 8);

            try {
                $pdo->beginTransaction();
                // Deduct from balance immediately — held in escrow until processed/rejected
                $pdo->prepare('UPDATE users SET balance = balance - ? WHERE id = ?')->execute([$amount, $uid]);
                $pdo->prepare('INSERT INTO withdrawals (user_id,amount,fee,net_amount,method,wallet_address,status) VALUES (?,?,?,?,?,?,?)')
                    ->execute([$uid, $amount, $fee, $net_amount, $method, $address, 'pending']);
                $pdo->commit();
            } catch (\Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                error_log('[withdraw] DB error: ' . $e->getMessage());
                flash('A server error occurred while processing your withdrawal. Please try again.', 'error');
                header('Location: /?p=withdraw'); exit;
            }

            $_SESSION['user']['balance'] = round((float)$user['balance'] - $amount, 2);
            flash("Withdrawal of \${$amount} requested! You'll receive \${$net_amount} to {$address}.", 'success');
            header('Location: /?p=withdraw'); exit;
        }

        if ($act === 'cancel_withdrawal') {
            $wid = (int)post('withdrawal_id');
            $wd  = $pdo->prepare('SELECT * FROM withdrawals WHERE id=? AND user_id=? AND status=?');
            $wd->execute([$wid, $uid, 'pending']);
            $wd = $wd->fetch();
            if ($wd) {
                try {
                    $pdo->beginTransaction();
                    $pdo->prepare("UPDATE withdrawals SET status='cancelled', processed_at=? WHERE id=?")->execute([time(), $wid]);
                    $pdo->prepare('UPDATE users SET balance = balance + ? WHERE id = ?')->execute([$wd['amount'], $uid]);
                    $pdo->commit();
                } catch (\Throwable $e) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    error_log('[withdraw] cancel DB error: ' . $e->getMessage());
                    flash('A server error occurred while cancelling. Please try again.', 'error');
                    header('Location: /?p=withdraw'); exit;
                }
                $_SESSION['user']['balance'] = round((float)$user['balance'] + (float)$wd['amount'], 2);
                flash('Withdrawal #' . $wid . ' cancelled — $' . number_format($wd['amount'], 2) . ' returned to your balance.', 'info');
            }
            header('Location: /?p=withdraw'); exit;
        }
    }

    // ── Data ─────────────────────────────────────────────────────
    $withdrawals = $pdo->prepare('SELECT * FROM withdrawals WHERE user_id=? ORDER BY created_at DESC LIMIT 50');
    $withdrawals->execute([$uid]);
    $withdrawals = $withdrawals->fetchAll();

    $pending_count = count(array_filter($withdrawals, fn($w) => $w['status'] === 'pending'));
    $total_withdrawn = array_sum(array_map(fn($w) => $w['status'] === 'completed' ? $w['net_amount'] : 0, $withdrawals));

    $methods = [
        'BTC_SEGWIT' => ['name'=>'Bitcoin',    'sub'=>'Native SegWit (bc1q…)', 'icon'=>'₿', 'color'=>'#F7931A', 'hint'=>'bc1q… (42 chars)'],
        'BTC'        => ['name'=>'Bitcoin',    'sub'=>'Legacy (1…)',            'icon'=>'₿', 'color'=>'#d4860a', 'hint'=>'1… or 3… (26–34 chars)'],
        'LTC'        => ['name'=>'Litecoin',   'sub'=>'L… address',            'icon'=>'Ł', 'color'=>'#C2A633', 'hint'=>'L… (26–34 chars)'],
        'USDT_TRC20' => ['name'=>'USDT',       'sub'=>'TRC20 (Tron)',          'icon'=>'₮', 'color'=>'#26A17B', 'hint'=>'T… (34 chars)'],
        'ETH'        => ['name'=>'Ethereum',   'sub'=>'ERC-20 address',        'icon'=>'Ξ', 'color'=>'#627EEA', 'hint'=>'0x… (42 chars)'],
        'USDC'       => ['name'=>'USDC',       'sub'=>'ERC-20 (USD Coin)',     'icon'=>'$', 'color'=>'#2775CA', 'hint'=>'0x… (42 chars)'],
    ];

    ob_start(); ?>
<div class="topbar">
  <h1 class="page-title">Withdraw <span>Earnings</span></h1>
  <div style="display:flex;gap:8px;align-items:center">
    <div class="badge badge-green"><span class="dot dot-green"></span> Balance: $<?= number_format((float)$user['balance'], 2) ?></div>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start">

  <!-- LEFT: Request form -->
  <div>
    <?php if ($pending_count > 0): ?>
    <div style="display:flex;align-items:center;gap:12px;padding:14px 16px;border-radius:var(--r-md);border:1px solid rgba(251,191,36,.3);background:rgba(251,191,36,.06);margin-bottom:16px">
      <span style="font-size:20px">⏳</span>
      <div>
        <div class="fw-6 text-sm" style="color:#fbbf24">Withdrawal Pending</div>
        <div class="text-dim text-xs mt-2">You have a withdrawal in progress. Cancel it below if you need to change details, or wait for admin to process it.</div>
      </div>
    </div>
    <?php endif; ?>

    <div class="card">
      <div class="section-title">Request Withdrawal</div>

      <form method="POST" id="wd-form">
        <input type="hidden" name="action" value="request_withdrawal">

        <!-- Coin selector -->
        <div class="form-group">
          <label class="form-label">Cryptocurrency</label>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:6px" id="method-grid">
            <?php foreach ($methods as $mk => $mv): ?>
            <label class="method-tile" for="m-<?= $mk ?>" style="display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:var(--r-sm);border:1px solid var(--border);cursor:pointer;transition:border-color .15s">
              <input type="radio" name="method" id="m-<?= $mk ?>" value="<?= $mk ?>" style="display:none" onchange="onMethodChange('<?= $mk ?>', '<?= addslashes($mv['hint']) ?>')">
              <div style="width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;background:<?= h($mv['color']) ?>22;color:<?= h($mv['color']) ?>;border:1px solid <?= h($mv['color']) ?>44;flex-shrink:0"><?= h($mv['icon']) ?></div>
              <div style="min-width:0">
                <div class="fw-6" style="font-size:12px"><?= h($mv['name']) ?></div>
                <div class="text-dim text-xs" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= h($mv['sub']) ?></div>
              </div>
            </label>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Wallet address -->
        <div class="form-group">
          <label class="form-label">Your Wallet Address</label>
          <input class="form-input" type="text" name="wallet_address" id="wallet-addr"
                 placeholder="Select a coin first…" autocomplete="off" spellcheck="false"
                 style="font-family:monospace;font-size:12px" required>
          <div class="text-dim text-xs mt-4" id="addr-hint">Select a coin to see the expected address format.</div>
        </div>

        <!-- Amount + fee preview -->
        <div class="form-row">
          <div class="form-group" style="flex:1">
            <label class="form-label">Amount (USD)</label>
            <input class="form-input" type="number" name="amount" id="wd-amount"
                   step="0.01" min="<?= $min_wd ?>" max="<?= number_format((float)$user['balance'], 2, '.', '') ?>"
                   placeholder="<?= $min_wd ?>.00" oninput="calcFee()" required>
            <div class="text-dim text-xs mt-4">Min: $<?= number_format($min_wd, 2) ?> · Max: $<?= number_format((float)$user['balance'], 2) ?></div>
          </div>
          <div class="form-group" style="flex:1">
            <label class="form-label">You Receive</label>
            <div style="padding:9px 12px;background:var(--bg-root);border:1px solid var(--border);border-radius:var(--r-sm);font-family:monospace;font-size:13px;min-height:38px" id="net-preview">
              <span class="text-dim">Enter amount</span>
            </div>
            <?php if ($fee_pct > 0): ?>
            <div class="text-dim text-xs mt-4">Platform fee: <?= $fee_pct ?>% deducted</div>
            <?php else: ?>
            <div class="text-dim text-xs mt-4" style="color:#22c55e">No platform fee</div>
            <?php endif; ?>
          </div>
        </div>

        <button class="btn btn-primary" id="wd-submit" style="width:100%;justify-content:center;margin-top:4px"
                <?= $pending_count > 0 ? 'disabled' : '' ?>>
          <?= $pending_count > 0 ? 'Pending withdrawal in progress' : 'Request Withdrawal' ?>
        </button>
        <?php if ((float)$user['balance'] < $min_wd): ?>
        <div style="margin-top:8px;font-size:12px;color:var(--red);text-align:center">
          Insufficient balance (minimum $<?= number_format($min_wd, 2) ?>)
        </div>
        <?php endif; ?>
      </form>
    </div>

    <!-- Withdrawal history -->
    <div class="card mt-16">
      <div class="section-title">Withdrawal History</div>
      <?php if (empty($withdrawals)): ?>
        <div class="text-dim text-sm">No withdrawals yet.</div>
      <?php else: ?>
      <div style="display:flex;flex-direction:column;gap:8px">
        <?php foreach ($withdrawals as $w): ?>
        <?php
          $sc = match($w['status']) {
            'completed'  => ['badge-green',   '✓ Completed'],
            'processing' => ['badge-amber',   '⟳ Processing'],
            'pending'    => ['badge-amber',   '⏳ Pending'],
            'rejected'   => ['badge-red',     '✕ Rejected'],
            'cancelled'  => ['badge-gray',    '— Cancelled'],
            default      => ['badge-gray',     h($w['status'])],
          };
        ?>
        <div class="card-sm" style="border-color:<?= $w['status']==='pending'?'rgba(251,191,36,.2)':'var(--border)' ?>">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap">
            <div style="flex:1;min-width:0">
              <div class="flex items-center gap-8">
                <span class="fw-7 text-sm">$<?= number_format((float)$w['amount'], 2) ?></span>
                <span class="text-dim text-xs">→ <?= h($w['method']) ?></span>
                <span class="badge <?= $sc[0] ?>" style="font-size:9px"><?= $sc[1] ?></span>
              </div>
              <div style="font-family:monospace;font-size:10px;color:var(--teal);margin-top:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= h($w['wallet_address']) ?></div>
              <?php if ($w['txid']): ?>
              <div class="text-dim text-xs mt-2">TXID: <span style="font-family:monospace;color:var(--teal)"><?= h(substr($w['txid'],0,24)) ?>…</span></div>
              <?php endif; ?>
              <?php if ($w['admin_note']): ?>
              <div class="text-dim text-xs mt-2" style="color:var(--red)">Note: <?= h($w['admin_note']) ?></div>
              <?php endif; ?>
              <div class="text-dim text-xs mt-2"><?= date('M j, Y H:i', (int)$w['created_at']) ?></div>
            </div>
            <div style="text-align:right;flex-shrink:0">
              <div class="fw-7" style="font-size:15px;<?= $w['status']==='completed'?'color:var(--green)':'' ?>">$<?= number_format((float)$w['net_amount'], 2) ?></div>
              <div class="text-dim text-xs">net</div>
              <?php if ($w['status'] === 'pending'): ?>
              <form method="POST" style="margin-top:6px" onsubmit="return confirm('Cancel this withdrawal? Your balance will be restored.')">
                <input type="hidden" name="action" value="cancel_withdrawal">
                <input type="hidden" name="withdrawal_id" value="<?= $w['id'] ?>">
                <button class="btn btn-ghost btn-xs" style="color:var(--red)">Cancel</button>
              </form>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- RIGHT: Info panel -->
  <div>
    <div class="card mb-16">
      <div class="section-title">Earnings Summary</div>
      <div style="display:flex;flex-direction:column;gap:10px;font-size:13px">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span class="text-dim">Available Balance</span>
          <span class="fw-7" style="color:var(--green)">$<?= number_format((float)$user['balance'], 2) ?></span>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span class="text-dim">Total Withdrawn</span>
          <span class="fw-6">$<?= number_format($total_withdrawn, 2) ?></span>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span class="text-dim">Pending</span>
          <span class="fw-6" style="color:<?= $pending_count?'#fbbf24':'var(--text-dim)' ?>"><?= $pending_count > 0 ? $pending_count . ' request' : 'None' ?></span>
        </div>
        <div style="height:1px;background:var(--border);margin:4px 0"></div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span class="text-dim">Platform Fee</span>
          <span class="fw-6"><?= $fee_pct > 0 ? $fee_pct . '%' : '<span style="color:var(--green)">0% — Free</span>' ?></span>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span class="text-dim">Min. Withdrawal</span>
          <span class="fw-6">$<?= number_format($min_wd, 2) ?></span>
        </div>
      </div>
    </div>

    <div class="card mb-16" style="border-color:rgba(99,102,241,.25);background:rgba(99,102,241,.05)">
      <div class="section-title" style="color:#818cf8">How It Works</div>
      <ol class="text-dim text-xs" style="margin:0;padding-left:16px;line-height:2">
        <li>Enter amount and your wallet address</li>
        <li>Funds held from balance immediately</li>
        <li>Admin reviews and sends the crypto</li>
        <li>TXID posted — withdrawal marked complete</li>
        <li>Cancel anytime while status is Pending</li>
      </ol>
    </div>

    <div class="card" style="border-color:rgba(219,20,60,.2);background:rgba(219,20,60,.04)">
      <div class="section-title" style="color:var(--red)">Important</div>
      <ul class="text-dim text-xs" style="margin:0;padding-left:14px;line-height:2">
        <li>Double-check your wallet address</li>
        <li>Wrong address = <strong style="color:var(--fg)">unrecoverable loss</strong></li>
        <li>Processing time: 1–24 hours</li>
        <li>Minimum confirmations before release</li>
      </ul>
    </div>
  </div>
</div>

<style>
.method-tile:has(input:checked) { border-color:var(--red) !important; background:rgba(219,20,60,.06); }
.method-tile:hover { border-color:var(--red-dim); }
</style>

<script>
const FEE_PCT  = <?= $fee_pct ?>;
const BALANCE  = <?= (float)$user['balance'] ?>;

function onMethodChange(key, hint) {
  document.querySelectorAll('.method-tile').forEach(t => t.style.borderColor = '');
  const lbl = document.querySelector('label[for="m-'+key+'"]');
  if (lbl) lbl.style.borderColor = 'var(--red)';
  document.getElementById('addr-hint').textContent = 'Expected format: ' + hint;
  document.getElementById('wallet-addr').placeholder = hint;
}

function calcFee() {
  const amt = parseFloat(document.getElementById('wd-amount').value) || 0;
  const fee = Math.round(amt * FEE_PCT / 100 * 100) / 100;
  const net = Math.round((amt - fee) * 100) / 100;
  const el  = document.getElementById('net-preview');
  if (amt < <?= $min_wd ?>) {
    el.innerHTML = '<span style="color:var(--red)">Below minimum</span>';
  } else if (amt > BALANCE) {
    el.innerHTML = '<span style="color:var(--red)">Exceeds balance</span>';
  } else {
    el.innerHTML = '<span style="color:var(--green);font-weight:700">$' + net.toFixed(2) + '</span>';
  }
}

// Select BTC SegWit by default
document.getElementById('m-BTC_SEGWIT').checked = true;
onMethodChange('BTC_SEGWIT', 'bc1q… (42 chars)');
</script>
<?php
    return ob_get_clean();
}

// Basic wallet address format validation
function validate_wallet_address(string $addr, string $method): bool {
    $addr = trim($addr);
    if (empty($addr)) return false;
    return match(strtoupper($method)) {
        'BTC_SEGWIT' => (bool)preg_match('/^bc1q[ac-hj-np-z02-9]{6,87}$/i', $addr),
        'BTC'        => (bool)preg_match('/^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/', $addr),
        'LTC'        => (bool)preg_match('/^[LM3][a-km-zA-HJ-NP-Z1-9]{25,34}$/', $addr),
        'USDT_TRC20' => (bool)preg_match('/^T[a-km-zA-HJ-NP-Z1-9]{33}$/', $addr),
        'ETH', 'USDC' => (bool)preg_match('/^0x[0-9a-fA-F]{40}$/', $addr),
        default      => false,
    };
}
