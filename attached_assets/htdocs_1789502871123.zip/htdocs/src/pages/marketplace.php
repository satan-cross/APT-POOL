<?php
declare(strict_types=1);

/**
 * Task console
 *
 * This screen intentionally only captures a task selection. It does not
 * execute, automate, or provide instructions for any security operation.
 */
function page_marketplace(): string {
    require_login();

    // Security-focused tasks are ranked first. These are task selections only:
    // the console never executes scans, payloads, cracking, or compute jobs.
    $tasks = [
        // Ethical hacker / CTF
        ['id'=>'web_security_challenge','title'=>'Web security challenge','description'=>'Solve a web-application security challenge in an isolated lab.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'simulated_sql_flaw','title'=>'Simulated SQL-injection finding','description'=>'Find and report a simulated injection flaw in a deliberately vulnerable application.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'insecure_auth_review','title'=>'Insecure authentication review','description'=>'Identify weak authentication behavior in a test application and document the fix.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'vulnerable_api_report','title'=>'Vulnerable API analysis','description'=>'Analyze a vulnerable API in a lab and write a remediation report.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'challenge_binary_reverse_engineering','title'=>'Challenge binary reverse engineering','description'=>'Reverse-engineer a provided challenge binary without accessing third-party systems.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'synthetic_secret_recovery','title'=>'Synthetic secret recovery','description'=>'Recover test secrets from intentionally vulnerable sample files.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'simulated_phishing_investigation','title'=>'Simulated phishing investigation','description'=>'Investigate a controlled phishing campaign and identify its indicators.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'suspicious_login_analysis','title'=>'Suspicious login analysis','description'=>'Analyze provided authentication events and identify anomalous access.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'cloud_misconfiguration_lab','title'=>'Cloud misconfiguration lab','description'=>'Identify intentionally misconfigured cloud resources in a training environment.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'sandbox_asset_discovery','title'=>'Sandbox asset discovery','description'=>'Perform approved asset discovery against a private sandbox network.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'simulated_privilege_escalation','title'=>'Simulated privilege escalation','description'=>'Validate a simulated privilege boundary issue in an isolated lab.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'cryptography_challenge','title'=>'Cryptography challenge','description'=>'Solve a cryptography challenge using only the provided test data.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'simulated_data_leak','title'=>'Simulated data-leak investigation','description'=>'Investigate a controlled data-leak scenario and identify the exposure path.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'sandbox_ransomware_analysis','title'=>'Sandbox ransomware analysis','description'=>'Analyze a fake ransomware sample inside an isolated malware-analysis environment.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],
        ['id'=>'capture_the_flag','title'=>'Capture-the-flag challenge','description'=>'Complete an authorized capture-the-flag challenge with isolated targets.','category'=>'Ethical Hacker','tone'=>'purple','icon'=>'⌁'],

        // Red team
        ['id'=>'authorized_external_simulation','title'=>'Authorized external attack simulation','description'=>'Conduct an approved external attack simulation against designated test assets.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'staging_web_defense_test','title'=>'Staging web-defense test','description'=>'Test web-application defenses in a staging environment with written authorization.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'endpoint_detection_validation','title'=>'Endpoint detection validation','description'=>'Validate endpoint detection against benign simulated attacker behavior.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'identity_access_test','title'=>'Identity and access-control test','description'=>'Test access controls using approved accounts and documented permissions.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'phishing_awareness_exercise','title'=>'Phishing-awareness exercise','description'=>'Run an approved employee-awareness exercise with safe, non-credential-collecting simulations.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'network_segmentation_review','title'=>'Network segmentation review','description'=>'Evaluate network segmentation in an authorized lab or staging environment.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'incident_escalation_test','title'=>'Incident-escalation test','description'=>'Test incident-response escalation procedures with a controlled scenario.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'nonproduction_lateral_movement','title'=>'Non-production movement simulation','description'=>'Simulate lateral movement only across approved non-production systems.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'benign_attack_emulation','title'=>'Benign attack emulation','description'=>'Validate security-alert coverage using safe, controlled attack emulation.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'authorized_exposed_services','title'=>'Authorized exposed-services assessment','description'=>'Assess exposed services on a specifically authorized test network.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'simulated_compromise_backup_test','title'=>'Simulated compromise backup test','description'=>'Test backup resilience against a controlled compromise scenario.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'physical_security_tabletop','title'=>'Physical-security tabletop exercise','description'=>'Review physical-security procedures through an approved tabletop exercise.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'purple_team_detection_validation','title'=>'Purple-team detection validation','description'=>'Run a coordinated red/blue exercise to validate detections and response.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'controlled_payload_test','title'=>'Controlled payload defense test','description'=>'Test application defenses with a benign, controlled payload in staging.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],
        ['id'=>'red_team_findings_report','title'=>'Red-team findings report','description'=>'Produce a prioritized red-team findings and remediation report.','category'=>'Red Team','tone'=>'red','icon'=>'⚔'],

        // Blue team
        ['id'=>'endpoint_alert_investigation','title'=>'Simulated endpoint-alert investigation','description'=>'Investigate simulated endpoint alerts and classify the activity.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'auth_access_log_analysis','title'=>'Authentication-log analysis','description'=>'Analyze authentication and access logs for suspicious behavior.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'suspicious_process_detection','title'=>'Suspicious-process detection','description'=>'Detect suspicious process behavior in provided endpoint telemetry.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'malware_alert_triage','title'=>'Simulated malware-alert triage','description'=>'Triage simulated malware alerts and recommend safe containment steps.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'siem_detection_rule','title'=>'SIEM detection rule','description'=>'Create a SIEM detection rule for a provided threat scenario.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'edr_query_authoring','title'=>'EDR query authoring','description'=>'Write endpoint-detection queries against synthetic telemetry.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'simulated_exfiltration_investigation','title'=>'Simulated exfiltration investigation','description'=>'Investigate a simulated data-exfiltration event and identify affected assets.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'ioc_identification','title'=>'Indicator-of-compromise identification','description'=>'Identify indicators of compromise in provided logs and files.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'synthetic_threat_hunt','title'=>'Synthetic-telemetry threat hunt','description'=>'Perform a threat-hunting exercise on synthetic security telemetry.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'firewall_flow_review','title'=>'Firewall and network-flow review','description'=>'Review firewall and network-flow logs for suspicious patterns.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'patch_priority_validation','title'=>'Patch-priority validation','description'=>'Validate vulnerability and patch priorities against a provided asset list.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'monitoring_coverage_review','title'=>'Security-monitoring coverage review','description'=>'Identify gaps in security-monitoring coverage and recommend improvements.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'incident_response_playbook','title'=>'Incident-response playbook','description'=>'Build an incident-response playbook for a simulated breach scenario.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'simulated_breach_recovery','title'=>'Simulated breach containment and recovery','description'=>'Contain and recover from a controlled breach scenario in a lab.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'phishing_indicator_analysis','title'=>'Phishing-indicator analysis','description'=>'Analyze provided messages and URLs for phishing indicators.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'cloud_audit_log_review','title'=>'Cloud-audit log review','description'=>'Review cloud audit logs for suspicious or policy-violating activity.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'backup_restoration_test','title'=>'Backup-restoration test','description'=>'Test backup restoration after a simulated security incident.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'detection_response_metrics','title'=>'Detection and response metrics','description'=>'Measure mean time to detect and respond using a provided incident timeline.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'threat_intelligence_summary','title'=>'Threat-intelligence summary','description'=>'Create a threat-intelligence summary from provided sources and indicators.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],
        ['id'=>'incident_root_cause','title'=>'Incident root-cause analysis','description'=>'Conduct a post-incident root-cause analysis and document prevention steps.','category'=>'Blue Team','tone'=>'teal','icon'=>'✦'],

        // Security and compute work
        ['id'=>'synthetic_hash_strength','title'=>'Synthetic hash-strength audit','description'=>'Test password-hash strength using synthetic or user-owned test credentials.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'hash_algorithm_benchmark','title'=>'Hashing algorithm benchmark','description'=>'Compare hashing algorithm performance using non-sensitive benchmark inputs.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'proof_of_work_benchmark','title'=>'Proof-of-work benchmark','description'=>'Benchmark a user-provided proof-of-work target without connecting to a live mining pool.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'gpu_hash_rate_benchmark','title'=>'GPU hash-rate benchmark','description'=>'Measure GPU hashing performance using synthetic benchmark workloads.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'cpu_performance_benchmark','title'=>'CPU performance benchmark','description'=>'Measure CPU throughput using a reproducible, user-provided workload.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'gpu_kernel_optimization','title'=>'GPU kernel optimization','description'=>'Optimize a user-provided compute kernel and compare reproducible results.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'password_policy_audit','title'=>'Password-policy audit','description'=>'Audit password-policy quality without exposing real credentials.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'tls_configuration_audit','title'=>'TLS configuration audit','description'=>'Review TLS and HTTPS configuration for an authorized service.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'dependency_scan','title'=>'Dependency vulnerability scan','description'=>'Scan an authorized project for vulnerable dependencies and produce a report.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'container_image_scan','title'=>'Container-image security scan','description'=>'Scan a user-provided container image for known security issues.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'static_code_analysis','title'=>'Static code analysis','description'=>'Run static analysis against an authorized codebase and summarize findings.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'sbom_generation','title'=>'SBOM generation','description'=>'Generate a software bill of materials for an authorized project.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'isolated_fuzz_testing','title'=>'Isolated fuzz testing','description'=>'Run authorized fuzz tests against a sandboxed binary or service.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'malware_sample_sandbox','title'=>'Malware-sample sandbox analysis','description'=>'Analyze a provided sample in an isolated, non-networked sandbox.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'cryptographic_library_benchmark','title'=>'Cryptographic-library benchmark','description'=>'Benchmark an authorized cryptographic library with test data.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'entropy_test','title'=>'Randomness and entropy test','description'=>'Evaluate randomness quality using synthetic output or user-owned test data.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'file_integrity_verification','title'=>'File-integrity verification','description'=>'Verify the integrity of a user-provided file set.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'checksum_generation','title'=>'Large-scale checksum generation','description'=>'Generate checksums for an authorized archive or dataset.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'network_protocol_benchmark','title'=>'Isolated network-protocol benchmark','description'=>'Benchmark a protocol implementation in an isolated environment.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'zero_knowledge_benchmark','title'=>'Zero-knowledge proof benchmark','description'=>'Benchmark proof generation using test data and a local verifier.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'homomorphic_encryption_benchmark','title'=>'Homomorphic-encryption benchmark','description'=>'Measure encrypted-computation performance using test data.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],
        ['id'=>'secure_enclave_benchmark','title'=>'Secure-enclave benchmark','description'=>'Benchmark trusted-execution features with non-sensitive test workloads.','category'=>'Security Compute','tone'=>'amber','icon'=>'⌁'],

        // Hacking service and crypto recovery offerings
        ['id'=>'public_key_recovery_feasibility','title'=>'Public-key recovery feasibility review','description'=>'Assess whether a user-owned key can be recovered; secure public-key cryptography does not reveal private keys.','category'=>'Crypto Recovery','tone'=>'purple','icon'=>'↺'],
        ['id'=>'wallet_file_integrity_recovery','title'=>'Wallet-file recovery and integrity check','description'=>'Recover and validate an authorized wallet file without exposing keys or sending funds.','category'=>'Crypto Recovery','tone'=>'purple','icon'=>'↺'],
        ['id'=>'damaged_keystore_assessment','title'=>'Damaged keystore assessment','description'=>'Assess a user-owned keystore for repairability and produce a non-destructive recovery plan.','category'=>'Crypto Recovery','tone'=>'purple','icon'=>'↺'],
        ['id'=>'hd_derivation_path_audit','title'=>'HD wallet derivation-path audit','description'=>'Audit derivation paths and account discovery for an authorized wallet backup.','category'=>'Crypto Recovery','tone'=>'purple','icon'=>'↺'],
        ['id'=>'password_hash_recovery','title'=>'Password hash recovery','description'=>'Assess a synthetic or user-owned password hash and produce a remediation report; no real credentials or cracking jobs are accepted.','category'=>'Security Service','tone'=>'purple','icon'=>'↺'],
        ['id'=>'wallet_address_ownership_review','title'=>'Wallet address ownership review','description'=>'Verify address ownership using user-authorized signatures and public blockchain data.','category'=>'Crypto Recovery','tone'=>'purple','icon'=>'↺'],
        ['id'=>'blockchain_transaction_tracing','title'=>'Blockchain transaction tracing','description'=>'Trace authorized wallet activity and prepare a documented transaction-flow report.','category'=>'Crypto Recovery','tone'=>'purple','icon'=>'↺'],
        ['id'=>'multisig_recovery_plan','title'=>'Multisignature wallet recovery plan','description'=>'Create a recovery plan for an authorized multisignature wallet and its backup participants.','category'=>'Crypto Recovery','tone'=>'purple','icon'=>'↺'],
        ['id'=>'authorized_web_security_assessment','title'=>'Authorized web security assessment','description'=>'Review a user-owned web application for vulnerabilities and provide a prioritized remediation report.','category'=>'Security Service','tone'=>'red','icon'=>'⚔'],
        ['id'=>'authorized_api_security_assessment','title'=>'Authorized API security assessment','description'=>'Assess a user-owned API for authentication, authorization, and input-validation issues.','category'=>'Security Service','tone'=>'red','icon'=>'⚔'],
        ['id'=>'red_team_attack_surface_review','title'=>'Red-team attack-surface review','description'=>'Map and prioritize an authorized organization’s exposed attack surface without accessing out-of-scope systems.','category'=>'Security Service','tone'=>'red','icon'=>'⚔'],
        ['id'=>'incident_compromise_triage','title'=>'Incident and compromise triage','description'=>'Triage a suspected compromise using user-provided logs, alerts, and system evidence.','category'=>'Security Service','tone'=>'teal','icon'=>'✦'],
        ['id'=>'malware_sample_forensics','title'=>'Malware-sample forensics','description'=>'Analyze an authorized sample in an isolated sandbox and document indicators of compromise.','category'=>'Security Service','tone'=>'teal','icon'=>'✦'],
        ['id'=>'cloud_security_review','title'=>'Cloud security review','description'=>'Review user-owned cloud configuration for exposed resources and excessive permissions.','category'=>'Security Service','tone'=>'teal','icon'=>'✦'],
        ['id'=>'threat_hunting_investigation','title'=>'Threat-hunting investigation','description'=>'Investigate suspicious activity in authorized logs and telemetry and produce an evidence-based report.','category'=>'Security Service','tone'=>'teal','icon'=>'✦'],
    ];

    // Keep the Shop focused on 15 high-value hacking-service and crypto-recovery offerings.
    $top_task_ids = [
        'public_key_recovery_feasibility',
        'wallet_file_integrity_recovery',
        'damaged_keystore_assessment',
        'hd_derivation_path_audit',
        'password_hash_recovery',
        'wallet_address_ownership_review',
        'blockchain_transaction_tracing',
        'multisig_recovery_plan',
        'authorized_web_security_assessment',
        'authorized_api_security_assessment',
        'red_team_attack_surface_review',
        'incident_compromise_triage',
        'malware_sample_forensics',
        'cloud_security_review',
        'threat_hunting_investigation',
    ];
    $tasks_by_id = [];
    foreach ($tasks as $task) $tasks_by_id[$task['id']] = $task;
    $tasks = array_values(array_filter(array_map(
        fn(string $id): ?array => $tasks_by_id[$id] ?? null,
        $top_task_ids
    )));

    // These fields describe the minimum safe intake for each service. They are
    // metadata and artifact references only; the console does not execute jobs.
    $task_field_specs = [
        'public_key_recovery_feasibility' => [
            ['name'=>'key_type','label'=>'Key type','type'=>'select','options'=>[
                ['value'=>'secp256k1','label'=>'secp256k1 / Bitcoin or Ethereum'],
                ['value'=>'ed25519','label'=>'Ed25519'],
                ['value'=>'rsa','label'=>'RSA'],
                ['value'=>'other','label'=>'Other or unknown'],
            ]],
            ['name'=>'public_key_reference','label'=>'Public-key or artifact reference','type'=>'textarea','placeholder'=>'Reference the public key or uploaded case artifact. Never provide a private key.'],
            ['name'=>'recovery_question','label'=>'Feasibility question','type'=>'textarea','placeholder'=>'What should be assessed: format, ownership evidence, backup compatibility, or recoverability limits?'],
        ],
        'wallet_file_integrity_recovery' => [
            ['name'=>'wallet_format','label'=>'Wallet or backup format','type'=>'select','options'=>[
                ['value'=>'wallet_dat','label'=>'wallet.dat'],
                ['value'=>'json_keystore','label'=>'JSON keystore'],
                ['value'=>'encrypted_backup','label'=>'Encrypted wallet backup'],
                ['value'=>'hardware_export','label'=>'Hardware-wallet export'],
                ['value'=>'other','label'=>'Other or unknown'],
            ]],
            ['name'=>'wallet_artifact_reference','label'=>'Wallet artifact reference','type'=>'textarea','placeholder'=>'Describe the user-owned backup, filename, checksum, and acquisition source. Do not paste keys.'],
            ['name'=>'integrity_goal','label'=>'Recovery goal','type'=>'select','options'=>[
                ['value'=>'integrity','label'=>'Integrity and corruption assessment'],
                ['value'=>'metadata','label'=>'Metadata and account inventory'],
                ['value'=>'restore_readiness','label'=>'Non-destructive restore-readiness review'],
            ]],
        ],
        'damaged_keystore_assessment' => [
            ['name'=>'keystore_format','label'=>'Keystore format','type'=>'text','placeholder'=>'For example: JSON keystore, wallet.dat, vendor backup'],
            ['name'=>'damage_description','label'=>'Damage description','type'=>'textarea','placeholder'=>'Describe corruption, missing files, failed imports, or read errors.'],
            ['name'=>'available_backups','label'=>'Available backup references','type'=>'textarea','placeholder'=>'List backup dates, checksums, and storage locations without sharing secrets.'],
        ],
        'hd_derivation_path_audit' => [
            ['name'=>'wallet_network','label'=>'Network or chain','type'=>'text','placeholder'=>'For example: Bitcoin mainnet, Ethereum, or another network'],
            ['name'=>'derivation_paths','label'=>'Known derivation paths','type'=>'textarea','placeholder'=>'List known or suspected paths such as BIP44/BIP49/BIP84 paths.'],
            ['name'=>'public_account_references','label'=>'Public account references','type'=>'textarea','placeholder'=>'Provide public addresses or xpub-style references only; never provide xpriv or seed material.'],
        ],
        'password_hash_recovery' => [
            ['name'=>'hash_algorithm','html_id'=>'hash-algorithm','label'=>'Detected hash type','type'=>'select','options'=>[
                ['value'=>'bcrypt','label'=>'bcrypt'],
                ['value'=>'scrypt','label'=>'scrypt'],
                ['value'=>'argon2i','label'=>'Argon2i'],
                ['value'=>'argon2d','label'=>'Argon2d'],
                ['value'=>'argon2id','label'=>'Argon2id'],
                ['value'=>'pbkdf2_sha1','label'=>'PBKDF2-HMAC-SHA1'],
                ['value'=>'pbkdf2_sha256','label'=>'PBKDF2-HMAC-SHA256'],
                ['value'=>'pbkdf2_sha512','label'=>'PBKDF2-HMAC-SHA512'],
                ['value'=>'phpass','label'=>'PHPass'],
                ['value'=>'ssha','label'=>'Salted SHA (SSHA)'],
                ['value'=>'sha','label'=>'Unix SHA'],
                ['value'=>'md5crypt','label'=>'MD5-crypt'],
                ['value'=>'sha256crypt','label'=>'SHA-256 crypt'],
                ['value'=>'sha512crypt','label'=>'SHA-512 crypt'],
                ['value'=>'apr1','label'=>'Apache APR1'],
                ['value'=>'django_pbkdf2_sha256','label'=>'Django PBKDF2-SHA256'],
                ['value'=>'django_argon2','label'=>'Django Argon2'],
                ['value'=>'django_bcrypt_sha256','label'=>'Django bcrypt-SHA256'],
                ['value'=>'mysql41','label'=>'MySQL 4.1+'],
                ['value'=>'postgres_md5','label'=>'PostgreSQL MD5'],
                ['value'=>'ntlm','label'=>'NTLM'],
                ['value'=>'lm','label'=>'LAN Manager (LM)'],
                ['value'=>'mscash','label'=>'MSCASH'],
                ['value'=>'mscash2','label'=>'MSCASH2'],
                ['value'=>'netntlmv1','label'=>'NetNTLMv1'],
                ['value'=>'netntlmv2','label'=>'NetNTLMv2'],
                ['value'=>'kerberos5_tgs','label'=>'Kerberos 5 TGS'],
                ['value'=>'kerberos5_asrep','label'=>'Kerberos 5 AS-REP'],
                ['value'=>'oracle11g','label'=>'Oracle 11g'],
                ['value'=>'cisco_type7','label'=>'Cisco Type 7'],
                ['value'=>'cisco_pix','label'=>'Cisco PIX'],
                ['value'=>'md5','label'=>'MD5'],
                ['value'=>'sha1','label'=>'SHA-1'],
                ['value'=>'sha224','label'=>'SHA-224'],
                ['value'=>'sha256','label'=>'SHA-256'],
                ['value'=>'sha384','label'=>'SHA-384'],
                ['value'=>'sha512','label'=>'SHA-512'],
                ['value'=>'sha3_224','label'=>'SHA3-224'],
                ['value'=>'sha3_256','label'=>'SHA3-256'],
                ['value'=>'sha3_384','label'=>'SHA3-384'],
                ['value'=>'sha3_512','label'=>'SHA3-512'],
                ['value'=>'ripemd160','label'=>'RIPEMD-160'],
                ['value'=>'blake2','label'=>'BLAKE2'],
                ['value'=>'whirlpool','label'=>'Whirlpool'],
                ['value'=>'ambiguous_32hex','label'=>'Ambiguous 32-hex format'],
                ['value'=>'mixed','label'=>'Mixed formats'],
                ['value'=>'unknown','label'=>'Unknown or custom format'],
            ]],
            ['name'=>'hash_list','html_id'=>'hash-list','label'=>'Hash list','type'=>'hashlist','placeholder'=>'Paste one hash per line. The detector reads format only; plaintext passwords are not accepted.'],
            ['name'=>'detected_hash_type','html_id'=>'detected-hash-type','label'=>'Detector result','type'=>'hidden'],
            ['name'=>'detection_summary','html_id'=>'detection-summary','label'=>'Detection summary','type'=>'hidden'],
        ],
        'wallet_address_ownership_review' => [
            ['name'=>'chain_network','label'=>'Chain and network','type'=>'text','placeholder'=>'For example: Bitcoin mainnet or Ethereum mainnet'],
            ['name'=>'public_addresses','label'=>'Public addresses','type'=>'textarea','placeholder'=>'List user-owned public addresses only.'],
            ['name'=>'ownership_proof_method','label'=>'Ownership proof method','type'=>'select','options'=>[
                ['value'=>'signature','label'=>'User-authorized message signature'],
                ['value'=>'wallet_export','label'=>'Wallet export comparison'],
                ['value'=>'transaction_context','label'=>'Transaction-context review'],
            ]],
        ],
        'blockchain_transaction_tracing' => [
            ['name'=>'trace_network','label'=>'Network or chain','type'=>'text','placeholder'=>'For example: Bitcoin, Ethereum, or another public chain'],
            ['name'=>'transaction_references','label'=>'Transaction or address references','type'=>'textarea','placeholder'=>'List public transaction IDs and addresses in scope.'],
            ['name'=>'trace_time_window','label'=>'Time window','type'=>'text','placeholder'=>'For example: 2024-01 through 2024-06'],
            ['name'=>'trace_report_focus','label'=>'Report focus','type'=>'textarea','placeholder'=>'Describe the authorized tracing question and desired evidence trail.'],
        ],
        'multisig_recovery_plan' => [
            ['name'=>'multisig_scheme','label'=>'Multisignature scheme','type'=>'text','placeholder'=>'For example: 2-of-3, Safe, or another wallet type'],
            ['name'=>'participant_count','label'=>'Participant count','type'=>'number','placeholder'=>'3'],
            ['name'=>'available_backup_components','label'=>'Available backup components','type'=>'textarea','placeholder'=>'Describe which public configuration and backup components are available without sharing secrets.'],
            ['name'=>'recovery_objective','label'=>'Recovery objective','type'=>'textarea','placeholder'=>'For example: restore-readiness plan, signer inventory, or non-destructive validation.'],
        ],
        'authorized_web_security_assessment' => [
            ['name'=>'target_reference','label'=>'Target reference','type'=>'text','placeholder'=>'Authorized staging URL or application reference'],
            ['name'=>'in_scope_assets','label'=>'In-scope assets','type'=>'textarea','placeholder'=>'List domains, applications, environments, and test accounts in scope.'],
            ['name'=>'assessment_environment','label'=>'Environment','type'=>'select','options'=>[
                ['value'=>'staging','label'=>'Staging'],
                ['value'=>'test','label'=>'Test lab'],
                ['value'=>'production_authorized','label'=>'Production with written authorization'],
            ]],
            ['name'=>'authorization_artifact','label'=>'Authorization reference','type'=>'text','placeholder'=>'Ticket, contract, or authorization record reference'],
        ],
        'authorized_api_security_assessment' => [
            ['name'=>'api_reference','label'=>'API reference','type'=>'text','placeholder'=>'Authorized base URL or API specification reference'],
            ['name'=>'api_auth_model','label'=>'Authentication model','type'=>'select','options'=>[
                ['value'=>'oauth','label'=>'OAuth or OIDC'],
                ['value'=>'api_key','label'=>'API key or signed request'],
                ['value'=>'session','label'=>'Session or cookie-based'],
                ['value'=>'none','label'=>'No authentication in test lab'],
                ['value'=>'other','label'=>'Other'],
            ]],
            ['name'=>'endpoint_scope','label'=>'Endpoint and role scope','type'=>'textarea','placeholder'=>'List endpoint groups, roles, and test accounts. Do not provide live secrets.'],
            ['name'=>'api_test_data_constraints','label'=>'Test-data constraints','type'=>'textarea','placeholder'=>'Describe allowed records, rate limits, and test-data rules.'],
        ],
        'red_team_attack_surface_review' => [
            ['name'=>'organization_scope','label'=>'Organization scope','type'=>'text','placeholder'=>'Authorized organization or business unit'],
            ['name'=>'asset_inventory_reference','label'=>'Asset inventory reference','type'=>'textarea','placeholder'=>'Reference domains, IP ranges, cloud accounts, and applications in scope.'],
            ['name'=>'out_of_scope_assets','label'=>'Out-of-scope assets','type'=>'textarea','placeholder'=>'List exclusions and systems that must not be accessed.'],
            ['name'=>'review_priorities','label'=>'Review priorities','type'=>'textarea','placeholder'=>'Describe the risks or exposure areas to prioritize.'],
        ],
        'incident_compromise_triage' => [
            ['name'=>'incident_window','label'=>'Incident time window','type'=>'text','placeholder'=>'For example: 2026-09-14 08:00 to 2026-09-15 12:00 UTC'],
            ['name'=>'evidence_inventory','label'=>'Evidence inventory','type'=>'textarea','placeholder'=>'Reference logs, alerts, images, and tickets. Preserve originals and share copies only.'],
            ['name'=>'suspected_impact','label'=>'Suspected impact','type'=>'textarea','placeholder'=>'Describe affected systems, accounts, or data without including secrets.'],
            ['name'=>'containment_status','label'=>'Containment status','type'=>'select','options'=>[
                ['value'=>'not_contained','label'=>'Not yet contained'],
                ['value'=>'partially_contained','label'=>'Partially contained'],
                ['value'=>'contained','label'=>'Contained'],
            ]],
        ],
        'malware_sample_forensics' => [
            ['name'=>'sample_reference','label'=>'Sample reference','type'=>'text','placeholder'=>'Quarantined sample ID or secure artifact reference'],
            ['name'=>'sample_type','label'=>'Sample type','type'=>'text','placeholder'=>'For example: PE, ELF, script, document, or archive'],
            ['name'=>'analysis_environment','label'=>'Analysis environment','type'=>'select','options'=>[
                ['value'=>'offline_sandbox','label'=>'Offline isolated sandbox'],
                ['value'=>'detonation_lab','label'=>'Controlled detonation lab'],
                ['value'=>'static_only','label'=>'Static analysis only'],
            ]],
            ['name'=>'forensics_outputs','label'=>'Desired outputs','type'=>'textarea','placeholder'=>'For example: hashes, metadata, indicators, behavior summary, or detection guidance.'],
        ],
        'cloud_security_review' => [
            ['name'=>'cloud_provider_scope','label'=>'Cloud provider and scope','type'=>'text','placeholder'=>'For example: AWS account, Azure subscription, or GCP project reference'],
            ['name'=>'cloud_asset_inventory','label'=>'Asset inventory reference','type'=>'textarea','placeholder'=>'List accounts, regions, projects, and services in scope.'],
            ['name'=>'cloud_priority','label'=>'Review priority','type'=>'select','options'=>[
                ['value'=>'identity','label'=>'Identity and permissions'],
                ['value'=>'network','label'=>'Network exposure'],
                ['value'=>'data','label'=>'Data exposure and storage'],
                ['value'=>'all','label'=>'Broad configuration review'],
            ]],
            ['name'=>'read_only_confirmation','label'=>'I confirm the review should use read-only access unless separately authorized.','type'=>'checkbox'],
        ],
        'threat_hunting_investigation' => [
            ['name'=>'telemetry_sources','label'=>'Telemetry sources','type'=>'textarea','placeholder'=>'List SIEM, EDR, identity, cloud, DNS, proxy, or network-flow sources.'],
            ['name'=>'hunt_time_window','label'=>'Hunt time window','type'=>'text','placeholder'=>'For example: last 30 days or a defined incident window'],
            ['name'=>'hunt_hypotheses','label'=>'Hunt hypotheses','type'=>'textarea','placeholder'=>'Describe suspicious behaviors, techniques, or questions to investigate.'],
            ['name'=>'indicator_references','label'=>'Indicator references','type'=>'textarea','placeholder'=>'List authorized indicators, case IDs, or threat-intelligence references.'],
        ],
    ];

    $selected_task = $_SESSION['selected_task'] ?? '';
    $selected_task_title = '';
    $selected_task_data = null;
    $show_requirements = get('step') === 'requirements';

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && post('action') === 'select_task') {
        $requested_task = post('task');
        $task_ids = array_column($tasks, 'id');
        $task_index = array_search($requested_task, $task_ids, true);

        if ($task_index === false) {
            flash('Choose one of the available tasks to continue.', 'error');
        } else {
            $selected_task = $tasks[$task_index]['id'];
            $_SESSION['selected_task'] = $selected_task;
            flash('Task selected: ' . $tasks[$task_index]['title'], 'success');
            header('Location: /?p=marketplace&step=requirements');
            exit;
        }

        header('Location: /?p=marketplace');
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && post('action') === 'submit_task_requirements') {
        $task_id = trim((string)post('task_id'));
        $task_ids = array_column($tasks, 'id');
        $task_index = array_search($task_id, $task_ids, true);
        $errors = [];

        if ($task_index === false) $errors[] = 'Choose a valid task before submitting requirements.';

        $task_specific = [];
        foreach ($task_field_specs[$task_id] ?? [] as $field) {
            $field_name = $field['name'];
            $is_required = $field['required'] ?? true;
            $value = $field['type'] === 'checkbox'
                ? (post($field_name) === 'yes' ? 'yes' : '')
                : trim((string)post($field_name));

            if ($is_required && $value === '') {
                $errors[] = 'Complete: ' . $field['label'] . '.';
            }
            if ($field['type'] === 'select' && $value !== '') {
                $allowed_values = array_column($field['options'] ?? [], 'value');
                if (!in_array($value, $allowed_values, true)) {
                    $errors[] = 'Choose a valid value for: ' . $field['label'] . '.';
                }
            }
            // Never retain raw hash-list contents in the session; keep only the
            // detector result and line-level format summary.
            if ($field['type'] !== 'hashlist') {
                $task_specific[$field_name] = $value;
            }
        }

        if ($errors) {
            flash(implode(' ', $errors), 'error');
            header('Location: /?p=marketplace&step=requirements');
            exit;
        }

        $selected_task = $task_id;
        $_SESSION['selected_task'] = $selected_task;
        $_SESSION['task_intake'] = [
            'task_id' => $task_id,
            'task_specific' => $task_specific,
            'submitted_at' => date('c'),
        ];
        flash('Requirements saved for review. No miner or worker job was dispatched.', 'success');
        header('Location: /?p=marketplace&step=requirements');
        exit;
    }

    foreach ($tasks as $task) {
        if ($task['id'] === $selected_task) {
            $selected_task_title = $task['title'];
            $selected_task_data = $task;
            break;
        }
    }

    ob_start(); ?>
<style>
  .task-console {
    max-width: 980px;
    margin: 0 auto;
  }

  .task-intro {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 24px;
    margin-bottom: 28px;
  }

  .task-eyebrow {
    color: var(--red);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: .12em;
    text-transform: uppercase;
    margin-bottom: 8px;
  }

  .task-heading {
    font-size: clamp(24px, 4vw, 36px);
    line-height: 1.05;
    letter-spacing: -.04em;
    font-weight: 800;
    color: var(--text-1);
  }

  .task-subheading {
    max-width: 570px;
    margin-top: 10px;
    color: var(--text-2);
    font-size: 14px;
    line-height: 1.65;
  }

  .task-status {
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    border: 1px solid var(--border-2);
    border-radius: 999px;
    padding: 8px 12px;
    color: var(--text-2);
    font-size: 12px;
    white-space: nowrap;
  }

  .task-status .dot {
    background: var(--green);
    box-shadow: 0 0 0 4px rgba(34,197,94,.1);
  }

  .task-panel {
    background: linear-gradient(145deg, rgba(39,39,42,.9), rgba(24,24,27,.98));
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: clamp(18px, 3vw, 30px);
    box-shadow: 0 20px 60px rgba(0,0,0,.2);
  }

  .task-panel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    padding-bottom: 18px;
    border-bottom: 1px solid var(--border);
    margin-bottom: 18px;
  }

  .task-panel-title {
    font-size: 14px;
    font-weight: 700;
    color: var(--text-1);
  }

  .task-panel-hint {
    color: var(--text-3);
    font-size: 12px;
  }

  .task-search {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: min(320px, 42%);
    color: var(--text-3);
    font-size: 11px;
  }

  .task-search input {
    width: 100%;
    min-width: 0;
    padding: 9px 11px;
    color: var(--text-1);
    background: rgba(9,9,11,.48);
    border: 1px solid var(--border-2);
    border-radius: 8px;
    outline: none;
  }

  .task-search input:focus {
    border-color: var(--red);
    box-shadow: 0 0 0 3px rgba(219,20,60,.12);
  }

  .task-list {
    display: grid;
    grid-template-columns: repeat(6, minmax(0, 1fr));
    gap: 10px;
  }

  .task-option {
    position: relative;
    display: block;
    cursor: pointer;
  }

  .task-option input {
    position: absolute;
    opacity: 0;
    pointer-events: none;
  }

  .task-option-body {
    position: relative;
    display: flex;
    align-items: flex-start;
    flex-direction: column;
    gap: 10px;
    height: 100%;
    min-height: 178px;
    padding: 13px;
    border: 1px solid var(--border-2);
    border-radius: 12px;
    background: rgba(9,9,11,.32);
    transition: border-color .16s, background .16s, transform .16s, box-shadow .16s;
  }

  .task-option:hover .task-option-body {
    border-color: var(--text-3);
    background: rgba(255,255,255,.035);
    transform: translateY(-1px);
  }

  .task-option input:focus-visible + .task-option-body {
    outline: 2px solid var(--indigo);
    outline-offset: 3px;
  }

  .task-option input:checked + .task-option-body {
    border-color: var(--red);
    background: rgba(219,20,60,.09);
    box-shadow: 0 0 0 1px rgba(219,20,60,.2), 0 10px 24px rgba(219,20,60,.08);
  }

  .task-icon {
    display: grid;
    place-items: center;
    width: 36px;
    height: 36px;
    border-radius: 11px;
    font-size: 18px;
    font-weight: 700;
  }

  .task-icon.blue {
    color: #93c5fd;
    background: rgba(59,130,246,.15);
    border: 1px solid rgba(59,130,246,.28);
  }

  .task-icon.amber {
    color: #fcd34d;
    background: rgba(245,158,11,.15);
    border: 1px solid rgba(245,158,11,.28);
  }

  .task-icon.purple {
    color: #d8b4fe;
    background: rgba(168,85,247,.15);
    border: 1px solid rgba(168,85,247,.28);
  }

  .task-title {
    color: var(--text-1);
    display: block;
    padding-right: 18px;
    font-size: 12px;
    line-height: 1.35;
    font-weight: 700;
  }

  .task-category {
    display: inline-flex;
    margin-top: 6px;
    margin-left: 0;
    padding: 2px 6px;
    border-radius: 999px;
    font-size: 9px;
    font-weight: 700;
    letter-spacing: .04em;
    text-transform: uppercase;
    vertical-align: 2px;
  }

  .task-category.purple {
    color: #d8b4fe;
    background: rgba(168,85,247,.14);
  }

  .task-category.red {
    color: #fda4af;
    background: rgba(219,20,60,.14);
  }

  .task-category.teal {
    color: #99f6e4;
    background: rgba(20,184,166,.14);
  }

  .task-category.amber {
    color: #fcd34d;
    background: rgba(245,158,11,.14);
  }

  .task-description {
    color: var(--text-3);
    font-size: 11px;
    line-height: 1.45;
    margin-top: 8px;
  }

  .task-radio {
    width: 18px;
    height: 18px;
    border: 1px solid var(--text-3);
    border-radius: 50%;
    position: relative;
    position: absolute;
    top: 13px;
    right: 13px;
  }

  .task-option input:checked + .task-option-body .task-radio {
    border-color: var(--red);
  }

  .task-option input:checked + .task-option-body .task-radio::after {
    content: '';
    position: absolute;
    inset: 4px;
    border-radius: 50%;
    background: var(--red);
  }

  .task-panel-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    padding-top: 18px;
    margin-top: 18px;
    border-top: 1px solid var(--border);
  }

  .task-note {
    display: flex;
    gap: 8px;
    max-width: 560px;
    color: var(--text-3);
    font-size: 11px;
    line-height: 1.45;
  }

  .task-note strong {
    color: var(--text-2);
  }

  .task-selected {
    margin-top: 14px;
    border: 1px solid rgba(34,197,94,.25);
    border-radius: 10px;
    padding: 11px 13px;
    color: #bbf7d0;
    background: rgba(34,197,94,.08);
    font-size: 12px;
  }

  .task-no-results {
    display: none;
    padding: 28px 16px;
    color: var(--text-3);
    font-size: 13px;
    text-align: center;
    border: 1px dashed var(--border-2);
    border-radius: 10px;
  }

  .task-no-results.visible {
    display: block;
  }

  @media (max-width: 640px) {
    .task-intro,
    .task-panel-header,
    .task-panel-footer {
      align-items: stretch;
      flex-direction: column;
    }

    .task-search {
      min-width: 0;
    }

    .task-list {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .task-status {
      align-self: flex-start;
    }

    .task-panel-footer .btn {
      width: 100%;
    }
  }

  @media (min-width: 641px) and (max-width: 1100px) {
    .task-list {
      grid-template-columns: repeat(4, minmax(0, 1fr));
    }
  }

  @media (max-width: 380px) {
    .task-list {
      grid-template-columns: 1fr;
    }
  }
</style>

<div class="task-console">
  <div class="task-intro">
    <div>
      <div class="task-eyebrow">Task console</div>
      <h1 class="task-heading">Choose a task to begin</h1>
      <p class="task-subheading">
        Select the workflow you want to review. You can change your selection at any time before continuing.
      </p>
    </div>
    <div class="task-status"><span class="dot"></span> Ready for selection</div>
  </div>

  <?php if ($show_requirements && $selected_task_data): ?>
  <div class="task-panel">
    <div class="task-panel-header">
      <div>
        <div class="task-panel-title">Service intake</div>
        <div class="task-panel-hint">Selected: <?= h($selected_task_data['title']) ?></div>
      </div>
      <a class="btn btn-ghost btn-sm" href="/?p=marketplace">Change task</a>
    </div>

    <div class="task-note" style="max-width:none;margin-bottom:18px">
      <span aria-hidden="true">ⓘ</span>
      <span><strong>Authorized review only.</strong> This form records requirements for manual review. It does not distribute work to miners, run password recovery, or collect private keys, seed phrases, plaintext passwords, or credential dumps.</span>
    </div>

    <form method="POST">
      <input type="hidden" name="action" value="submit_task_requirements">
      <input type="hidden" name="task_id" value="<?= h($selected_task_data['id']) ?>">

      <?php $specific_fields = $task_field_specs[$selected_task_data['id']] ?? []; ?>
      <?php if ($specific_fields): ?>
      <div class="card-sm" style="margin-bottom:16px;border-color:rgba(168,85,247,.3)">
        <div class="task-panel-title" style="margin-bottom:12px">Task-specific requirements</div>
        <div class="task-note" style="max-width:none;margin-bottom:14px">
          <span aria-hidden="true">ⓘ</span>
          <span>Provide references and metadata only. Do not submit private keys, seed phrases, plaintext passwords, credential dumps, or live access tokens.</span>
        </div>
        <?php foreach ($specific_fields as $field): ?>
        <?php $field_required = $field['required'] ?? true; ?>
        <?php $field_id = $field['html_id'] ?? str_replace('_', '-', $field['name']); ?>
        <?php if ($field['type'] === 'hidden'): ?>
          <input type="hidden" id="<?= h($field_id) ?>" name="<?= h($field['name']) ?>">
        <?php elseif ($field['type'] === 'checkbox'): ?>
        <div class="form-group">
          <label for="<?= h($field_id) ?>" style="display:flex;align-items:flex-start;gap:9px;color:var(--text-2);font-size:12px;line-height:1.5">
            <input id="<?= h($field_id) ?>" type="checkbox" name="<?= h($field['name']) ?>" value="yes" <?= $field_required ? 'required' : '' ?> style="margin-top:3px;accent-color:var(--red)">
            <span><?= h($field['label']) ?></span>
          </label>
        </div>
        <?php elseif ($field['type'] === 'select'): ?>
        <div class="form-group">
          <label class="form-label"><?= h($field['label']) ?></label>
          <select class="form-input" id="<?= h($field_id) ?>" name="<?= h($field['name']) ?>" <?= $field_required ? 'required' : '' ?>>
            <option value="">Select one</option>
            <?php foreach ($field['options'] as $option): ?>
            <option value="<?= h($option['value']) ?>"><?= h($option['label']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php elseif ($field['type'] === 'hashlist'): ?>
        <div class="form-group">
          <label class="form-label" for="<?= h($field_id) ?>"><?= h($field['label']) ?></label>
          <textarea class="form-input" id="<?= h($field_id) ?>" name="<?= h($field['name']) ?>" rows="7" maxlength="100000" placeholder="<?= h($field['placeholder'] ?? '') ?>" <?= $field_required ? 'required' : '' ?>></textarea>
          <div style="display:flex;align-items:center;gap:10px;margin-top:7px">
            <button class="btn btn-secondary btn-sm" id="detect-hash-type" type="button">Detect hash type</button>
            <span class="form-hint" id="hash-detection-status">Detection runs locally in this browser.</span>
          </div>
          <div id="hash-detection-results" style="display:grid;gap:4px;margin-top:9px"></div>
        </div>
        <?php else: ?>
        <div class="form-group">
          <label class="form-label" for="<?= h($field_id) ?>"><?= h($field['label']) ?></label>
          <?php if ($field['type'] === 'textarea'): ?>
          <textarea class="form-input" id="<?= h($field_id) ?>" name="<?= h($field['name']) ?>" rows="3" maxlength="2000" placeholder="<?= h($field['placeholder'] ?? '') ?>" <?= $field_required ? 'required' : '' ?>></textarea>
          <?php else: ?>
          <input class="form-input" id="<?= h($field_id) ?>" type="<?= h($field['type']) ?>" name="<?= h($field['name']) ?>" <?= $field['type'] === 'number' ? 'min="0" max="1000000"' : 'maxlength="2000"' ?> placeholder="<?= h($field['placeholder'] ?? '') ?>" <?= $field_required ? 'required' : '' ?>>
          <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <div class="task-panel-footer">
        <div class="task-note">
          <span aria-hidden="true">ⓘ</span>
          <span><strong>Review queue only.</strong> Saving this intake records the request for review and does not start a worker, miner, cracking, or security operation.</span>
        </div>
        <button class="btn btn-primary" type="submit">Save requirements</button>
      </div>
    </form>
  </div>
  <?php else: ?>
  <form method="POST" class="task-panel">
    <input type="hidden" name="action" value="select_task">
    <div class="task-panel-header">
      <div>
        <div class="task-panel-title">Available tasks</div>
        <div class="task-panel-hint" id="task-result-count">Showing <?= count($tasks) ?> tasks</div>
      </div>
      <label class="task-search">
        <span>Search</span>
        <input id="task-search" type="search" placeholder="Red team, SIEM, hash..." autocomplete="off">
      </label>
    </div>

    <div class="task-list">
      <?php foreach ($tasks as $task): ?>
      <label
        class="task-option"
        data-task-search="<?= h(strtolower($task['title'] . ' ' . $task['description'] . ' ' . $task['category'])) ?>"
      >
        <input
          type="radio"
          name="task"
          value="<?= h($task['id']) ?>"
          <?= $selected_task === $task['id'] ? 'checked' : '' ?>
          required
        >
        <span class="task-option-body">
          <span class="task-icon <?= h($task['tone']) ?>" aria-hidden="true"><?= h($task['icon']) ?></span>
          <span>
            <span class="task-title"><?= h($task['title']) ?><span class="task-category <?= h($task['tone']) ?>"><?= h($task['category']) ?></span></span>
            <span class="task-description"><?= h($task['description']) ?></span>
          </span>
          <span class="task-radio" aria-hidden="true"></span>
        </span>
      </label>
      <?php endforeach; ?>
    </div>
    <div class="task-no-results" id="task-no-results">No tasks match your search.</div>

    <div class="task-panel-footer">
      <div class="task-note">
        <span aria-hidden="true">ⓘ</span>
        <span><strong>Authorized use only.</strong> This selection records the workflow you want to review; it does not run a security operation.</span>
      </div>
      <button class="btn btn-primary" type="submit">Next</button>
    </div>
  </form>
  <?php endif; ?>

  <?php if ($selected_task_title): ?>
  <div class="task-selected">
    Selected task: <strong><?= h($selected_task_title) ?></strong>
  </div>
  <?php endif; ?>
</div>
<script>
  (() => {
    const input = document.getElementById('task-search');
    const count = document.getElementById('task-result-count');
    const empty = document.getElementById('task-no-results');
    const options = Array.from(document.querySelectorAll('.task-option'));
    if (!input || !count || !empty) return;

    const updateTaskFilter = () => {
      const query = input.value.trim().toLowerCase();
      let visible = 0;
      options.forEach((option) => {
        const matches = !query || (option.dataset.taskSearch || '').includes(query);
        option.style.display = matches ? '' : 'none';
        if (matches) visible += 1;
      });
      count.textContent = query ? `Showing ${visible} of ${options.length} tasks` : `Showing ${options.length} tasks`;
      empty.classList.toggle('visible', visible === 0);
    };

    input.addEventListener('input', updateTaskFilter);
  })();

  (() => {
    const hashList = document.getElementById('hash-list');
    const detectButton = document.getElementById('detect-hash-type');
    const algorithm = document.getElementById('hash-algorithm');
    const detectedType = document.getElementById('detected-hash-type');
    const summary = document.getElementById('detection-summary');
    const status = document.getElementById('hash-detection-status');
    const results = document.getElementById('hash-detection-results');
    if (!hashList || !detectButton || !algorithm || !detectedType || !summary || !status || !results) return;

    const labels = new Map(Array.from(algorithm.options).map((option) => [option.value, option.textContent]));

    const classifyHash = (value) => {
      const hash = value.trim();
      const lower = hash.toLowerCase();
      if (!hash) return 'empty';
      if (/^\$2[aby]\$\d{2}\$/.test(hash)) return 'bcrypt';
      if (/^\$argon2i\$/i.test(hash)) return 'argon2i';
      if (/^\$argon2d\$/i.test(hash)) return 'argon2d';
      if (/^\$argon2id\$/i.test(hash)) return 'argon2id';
      if (/^\$scrypt\$/i.test(hash)) return 'scrypt';
      if (/^pbkdf2_sha256\$\d+\$/i.test(hash)) return 'django_pbkdf2_sha256';
      if (/^argon2\$\d+\$/.test(lower)) return 'django_argon2';
      if (/^bcrypt_sha256\$\d+\$/i.test(hash)) return 'django_bcrypt_sha256';
      if (/^\$pbkdf2-(sha1|sha256|sha512)\$/i.test(hash)) return `pbkdf2_${lower.match(/sha(1|256|512)/)[0]}`;
      if (/^\$P\$|^\$H\$/i.test(hash)) return 'phpass';
      if (/^\{SSHA\}/i.test(hash) || /^ssha\$/i.test(hash)) return 'ssha';
      if (/^\{SHA\}/i.test(hash)) return 'sha';
      if (/^\{MD5\}/i.test(hash)) return 'md5';
      if (/^\$apr1\$/i.test(hash)) return 'apr1';
      if (/^\$1\$/.test(hash)) return 'md5crypt';
      if (/^\$5\$/.test(hash)) return 'sha256crypt';
      if (/^\$6\$/.test(hash)) return 'sha512crypt';
      if (/^\*[A-F0-9]{40}$/i.test(hash)) return 'mysql41';
      if (/^md5[a-f0-9]{32}$/i.test(hash)) return 'postgres_md5';
      if (/^\$krb5tgs\$/i.test(hash)) return 'kerberos5_tgs';
      if (/^\$krb5asrep\$/i.test(hash)) return 'kerberos5_asrep';
      if (/^\$oracle11g\$/i.test(hash) || /^S:[A-F0-9]{60}$/i.test(hash)) return 'oracle11g';
      if (/^[0-9a-f]{16}$/i.test(hash)) return 'cisco_type7';
      if (/^[0-9a-f]{32}$/i.test(hash)) return 'ambiguous_32hex';
      if (/^[0-9a-f]{40}$/i.test(hash)) return 'sha1';
      if (/^[0-9a-f]{56}$/i.test(hash)) return 'sha224';
      if (/^[0-9a-f]{64}$/i.test(hash)) return 'sha256';
      if (/^[0-9a-f]{96}$/i.test(hash)) return 'sha384';
      if (/^[0-9a-f]{128}$/i.test(hash)) return 'sha512';
      if (/^[0-9a-f]{40}$/i.test(hash)) return 'sha1';
      if (/^sha1[:$]/i.test(hash)) return 'sha1';
      if (/^sha256[:$]/i.test(hash)) return 'sha256';
      if (/^sha512[:$]/i.test(hash)) return 'sha512';
      if (/^netntlmv1\$/i.test(hash)) return 'netntlmv1';
      if (/^netntlmv2\$/i.test(hash)) return 'netntlmv2';
      if (/^mscash2\$/i.test(hash)) return 'mscash2';
      if (/^mscash\$/i.test(hash)) return 'mscash';
      if (/^blake2/i.test(hash)) return 'blake2';
      if (/^whirlpool/i.test(hash)) return 'whirlpool';
      return 'unknown';
    };

    const detect = () => {
      const lines = hashList.value.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
      if (!lines.length) {
        algorithm.value = '';
        detectedType.value = '';
        summary.value = '';
        results.replaceChildren();
        status.textContent = 'Paste at least one hash per line.';
        return;
      }

      const types = lines.map(classifyHash);
      const uniqueTypes = [...new Set(types)];
      const overall = uniqueTypes.length === 1 ? uniqueTypes[0] : 'mixed';
      algorithm.value = labels.has(overall) ? overall : 'unknown';
      detectedType.value = algorithm.value;
      summary.value = types.map((type, index) => `${index + 1}: ${labels.get(type) || 'Unknown or custom format'}`).join('\n');
      results.replaceChildren();

      types.forEach((type, index) => {
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;justify-content:space-between;gap:12px;padding:5px 8px;background:rgba(9,9,11,.35);border:1px solid var(--border);border-radius:5px;color:var(--text-3);font-size:10.5px';
        const line = document.createElement('span');
        line.textContent = `Line ${index + 1}`;
        const result = document.createElement('strong');
        result.style.color = type === 'unknown' ? 'var(--amber)' : 'var(--text-2)';
        result.textContent = labels.get(type) || 'Unknown or custom format';
        row.append(line, result);
        results.append(row);
      });

      status.textContent = overall === 'mixed'
        ? `Detected ${uniqueTypes.length} formats across ${lines.length} line(s); review each result.`
        : `Detected ${labels.get(overall) || 'Unknown or custom format'} across ${lines.length} line(s).`;
    };

    detectButton.addEventListener('click', detect);
    hashList.addEventListener('input', () => {
      detectedType.value = '';
      summary.value = '';
      status.textContent = 'Click Detect hash type after editing the list.';
    });
  })();
</script>
<?php
    return ob_get_clean();
}