<?php
declare(strict_types=1);

function page_marketplace(): string {
    require_login();
    $pdo = db();
    $uid = (int)$_SESSION['user_id'];

    // Cart action
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $card_id = (int)post('card_id');
        $act     = post('action');
        if ($act === 'add_cart' && $card_id) {
            if (!shop_is_open()) {
                flash('The shop is currently closed — purchases are disabled.', 'error');
            } elseif (add_to_cart($uid, $card_id)) {
                flash('Card added to cart — reserved for 10 min', 'success');
            } else {
                flash('Could not add card (already reserved or sold)', 'error');
            }
        }
        header('Location: /?p=marketplace&' . http_build_query(array_filter($_GET)));
        exit;
    }

    expire_cart_items();

    // Filters
    $f_brand   = get('brand', '');
    $f_type    = get('card_type', '');
    $f_country = get('country', '');
    $f_bank    = get('bank', '');
    $f_price   = get('max_price', '');
    $page_num  = max(1, (int)get('pg', 1));
    $per_page  = 25;

    $where = ["c.status='available'"];
    $params = [];
    if ($f_brand)   { $where[] = 'c.brand=?';      $params[] = $f_brand; }
    if ($f_type)    { $where[] = 'c.card_type=?';  $params[] = $f_type; }
    if ($f_country) { $where[] = 'c.country=?';    $params[] = $f_country; }
    if ($f_bank)    { $where[] = 'c.bank=?';       $params[] = $f_bank; }
    if ($f_price)   { $where[] = 'c.price<=?';     $params[] = (float)$f_price; }

    $sql_where = 'WHERE ' . implode(' AND ', $where);

    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM cards c $sql_where");
    $count_stmt->execute($params);
    $total = (int)$count_stmt->fetchColumn();
    $pages = max(1, (int)ceil($total / $per_page));
    $offset = ($page_num - 1) * $per_page;

    // Added explicit selection wrapper fields for address layers
    $stmt = $pdo->prepare("SELECT c.*,u.username AS seller_name FROM cards c JOIN users u ON u.id=c.seller_id $sql_where ORDER BY c.created_at DESC LIMIT $per_page OFFSET $offset");
    $stmt->execute($params);
    $cards = $stmt->fetchAll();

    // Filter options
    $brands   = $pdo->query("SELECT DISTINCT brand FROM cards WHERE status='available' ORDER BY brand")->fetchAll(PDO::FETCH_COLUMN);
    $types    = $pdo->query("SELECT DISTINCT card_type FROM cards WHERE status='available' ORDER BY card_type")->fetchAll(PDO::FETCH_COLUMN);
    $countries= $pdo->query("SELECT DISTINCT country FROM cards WHERE status='available' ORDER BY country")->fetchAll(PDO::FETCH_COLUMN);
    $banks    = $pdo->query("SELECT DISTINCT bank FROM cards WHERE status='available' ORDER BY bank")->fetchAll(PDO::FETCH_COLUMN);

    $brand_colors = ['VISA'=>'badge-purple','MASTERCARD'=>'badge-red','AMEX'=>'badge-teal','DISCOVER'=>'badge-amber'];
    $shop_open = shop_is_open();

    function qurl(array $extra = [], array $remove = []): string {
        $q = $_GET;
        foreach ($remove as $k) unset($q[$k]);
        foreach ($extra as $k => $v) $q[$k] = $v;
        unset($q['pg']);
        return '/?' . http_build_query($q);
    }

    ob_start(); ?>
<div class="topbar">
  <h1 class="page-title"><span><?= $total ?></span> Cards Available</h1>
  <a href="/?p=cart" class="btn btn-secondary btn-sm">View Cart</a>
</div>

<form id="filter-form" method="GET">
  <input type="hidden" name="p" value="marketplace">
  <div class="filter-bar">
    <div class="form-group"><label class="form-label">Brand</label>
      <select class="form-input" name="brand">
        <option value="">All Brands</option>
        <?php foreach ($brands as $b): ?><option value="<?= h($b) ?>" <?= $f_brand===$b?'selected':'' ?>><?= h($b) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="form-group"><label class="form-label">Type</label>
      <select class="form-input" name="card_type">
        <option value="">All Types</option>
        <?php foreach ($types as $t): ?><option value="<?= h($t) ?>" <?= $f_type===$t?'selected':'' ?>><?= h($t) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="form-group"><label class="form-label">Country</label>
      <select class="form-input" name="country">
        <option value="">All Countries</option>
        <?php foreach ($countries as $c): ?><option value="<?= h($c) ?>" <?= $f_country===$c?'selected':'' ?>><?= h($c) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="form-group"><label class="form-label">Bank</label>
      <select class="form-input" name="bank">
        <option value="">All Banks</option>
        <?php foreach ($banks as $bk): ?><option value="<?= h($bk) ?>" <?= $f_bank===$bk?'selected':'' ?>><?= h($bk) ?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="form-group"><label class="form-label">Max Price</label>
      <input class="form-input" type="number" name="max_price" step="0.01" min="0" value="<?= h($f_price) ?>" placeholder="$0.00">
    </div>
    <button class="btn btn-secondary btn-sm">Filter</button>
    <?php if ($f_brand||$f_type||$f_country||$f_bank||$f_price): ?>
      <a href="/?p=marketplace" class="btn btn-ghost btn-sm">Clear</a>
    <?php endif; ?>
  </div>
</form>

<div class="mkt-grid">
  <div class="mkt-header">
    <div class="mkt-col-head">BIN / Number</div>
    <div class="mkt-col-head">Brand</div>
    <div class="mkt-col-head">Type</div>
    <div class="mkt-col-head">Bank</div>
    <!-- New Address Headers -->
    <div class="mkt-col-head">Address</div>
    <div class="mkt-col-head">Address 2</div>
    <div class="mkt-col-head">City</div>
    <div class="mkt-col-head">State</div>
    <div class="mkt-col-head">Zipcode</div>
    <div class="mkt-col-head">CC</div>
    <div class="mkt-col-head">Balance</div>
    <div class="mkt-col-head">Exp</div>
    <div class="mkt-col-head">Price</div>
  </div>

  <?php if (empty($cards)): ?>
    <div style="padding:40px;text-align:center;color:var(--text-3)">No cards match your filters.</div>
  <?php endif; ?>

  <?php foreach ($cards as $c): ?>
  <div class="mkt-row">
    <div class="mkt-cell mono">
      <?= h(substr($c['number'],0,6)) ?>••••••<?= h(substr($c['number'],-4)) ?>
    </div>
    <div class="mkt-cell" style="display:flex;align-items:center;gap:6px">
      <span class="badge <?= $brand_colors[$c['brand']] ?? 'badge-gray' ?>"><?= h($c['brand']) ?></span>
      <?php if (!empty($c['pin_hash'])): ?><span title="PIN-protected — buyer enters PIN to unlock" style="font-size:12px;opacity:.8">🔒</span><?php endif; ?>
    </div>
    <div class="mkt-cell text-dim"><?= h($c['card_type']) ?></div>
    <div class="mkt-cell" style="font-size:11px"><?= h($c['bank']) ?></div>

    <!-- New Address Output Layers -->
    <div class="mkt-cell" style="font-size:11px"><?= h($c['address']) ?: '<span class="text-dim">–</span>' ?></div>
    <div class="mkt-cell" style="font-size:11px"><?= h($c['address2']) ?: '<span class="text-dim">–</span>' ?></div>
    <div class="mkt-cell" style="font-size:11px"><?= h($c['city']) ?: '<span class="text-dim">–</span>' ?></div>
    <div class="mkt-cell" style="font-size:11px"><?= h($c['state']) ?: '<span class="text-dim">–</span>' ?></div>
    <div class="mkt-cell mono" style="font-size:11px"><?= h($c['zipcode']) ?: '<span class="text-dim">–</span>' ?></div>

    <div class="mkt-cell"><span class="badge badge-gray"><?= h($c['country']) ?></span></div>
    <div class="mkt-cell" style="color:var(--green);font-weight:600">
      <?= $c['balance'] ? '$'.number_format((float)$c['balance'],2) : '<span class="text-dim">–</span>' ?>
    </div>
    <div class="mkt-cell mono text-dim"><?= h($c['exp']) ?></div>
    <div class="mkt-cell">
      <div class="flex items-center gap-8 justify-between" style="width:100%">
        <span class="td-price">$<?= number_format((float)$c['price'],2) ?></span>
        <?php if ($shop_open): ?>
        <form method="POST">
          <input type="hidden" name="action" value="add_cart">
          <input type="hidden" name="card_id" value="<?= $c['id'] ?>">
          <button class="btn btn-primary btn-xs">Add</button>
        </form>
        <?php else: ?>
          <span class="badge badge-gray" title="Shop closed">—</span>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <?php endforeach; ?>

  <div class="mkt-pagination">
    <span class="page-info">Page <?= $page_num ?> of <?= $pages ?> &nbsp;·&nbsp; <?= $total ?> results</span>
    <div class="page-btns">
      <?php if ($page_num > 1): ?>
        <a href="<?= qurl(['pg'=>$page_num-1]) ?>" class="btn btn-ghost btn-xs">← Prev</a>
      <?php endif; ?>
      <?php for ($p = max(1,$page_num-2); $p <= min($pages,$page_num+2); $p++): ?>
        <a href="<?= qurl(['pg'=>$p]) ?>" class="btn <?= $p===$page_num?'btn-primary':'btn-ghost' ?> btn-xs"><?= $p ?></a>
      <?php endfor; ?>
      <?php if ($page_num < $pages): ?>
        <a href="<?= qurl(['pg'=>$page_num+1]) ?>" class="btn btn-ghost btn-xs">Next →</a>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php
    return ob_get_clean();
}