<?php
declare(strict_types=1);

function page_become_seller(): string {
    require_login();
    $uid  = (int)$_SESSION['user_id'];
    $user = current_user();

    if (in_array($user['role'], ['seller','admin'])) {
        header('Location: /?p=seller');
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && post('action') === 'activate') {
        db()->prepare('UPDATE users SET role="seller" WHERE id=?')->execute([$uid]);
        $_SESSION['user']['role'] = 'seller';
        flash('Seller account activated instantly! No deposit required.', 'success');
        header('Location: /?p=seller');
        exit;
    }

    ob_start(); ?>
<div style="max-width:640px;margin:0 auto">
  <div class="topbar" style="margin-bottom:32px">
    <h1 class="page-title">Become a <span>Seller</span></h1>
  </div>

  <div class="card mb-16" style="border-color:rgba(219,20,60,.25);text-align:center;padding:32px">
    <div style="font-size:48px;margin-bottom:12px">💳</div>
    <h2 style="font-size:22px;font-weight:700;margin-bottom:8px">Instant Seller Activation</h2>
    <p class="text-muted text-sm">No security bond. No waiting period. Start selling cards immediately.</p>
  </div>

  <div class="grid-2 mb-16">
    <div class="stat-card">
      <div class="stat-label">Commission</div>
      <div class="stat-value">10%</div>
      <div class="stat-sub">Per successful sale</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Bond Required</div>
      <div class="stat-value green">$0</div>
      <div class="stat-sub">Instant activation</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Payout Speed</div>
      <div class="stat-value" style="font-size:16px;padding-top:4px">Instant</div>
      <div class="stat-sub">Direct to balance</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Formats Supported</div>
      <div class="stat-value" style="font-size:14px;padding-top:4px">Bulk Upload</div>
      <div class="stat-sub">Paste any format</div>
    </div>
  </div>

  <div class="card mb-16">
    <div class="section-title">Seller Agreement</div>
    <ul style="font-size:12.5px;color:var(--text-2);display:flex;flex-direction:column;gap:8px;margin-bottom:0">
      <li>✓ You may list cards immediately after activation</li>
      <li>✓ 90% of each sale goes directly to your balance</li>
      <li>✓ Buyers have a 60-minute refund window</li>
      <li>✓ Chargebacks result in account review</li>
      <li>✓ Mass upload supported via bulk paste tool</li>
    </ul>
  </div>

  <form method="POST">
    <input type="hidden" name="action" value="activate">
    <button class="btn btn-primary" style="width:100%;justify-content:center;padding:14px;font-size:15px">
      Activate Seller Account — Free & Instant
    </button>
  </form>
</div>
<?php
    return ob_get_clean();
}
