<?php
declare(strict_types=1);
/**
 * sync_action.php — Admin-only DB merge endpoint (JSON).
 *
 * POST /sync_action.php   (must be logged in as admin)
 *
 *   mode=remote  &  url=https://…/market.db
 *     → Downloads the remote .db, merges it into the live DB.
 *
 *   mode=local
 *     → Scans data/*.db for any file that isn't market.db,
 *       merges each one, renames it to *.merged.db.
 *
 * Merge strategy (INSERT OR IGNORE on natural keys):
 *   users            — by username
 *   cards            — by number+exp+cvv
 *   seller_inventory — by raw_data
 *   settings         — INSERT OR IGNORE (local values win)
 */

define('ROOT_DIR', __DIR__);
require_once ROOT_DIR . '/src/bootstrap.php';

header('Content-Type: application/json');

// ── Auth: must be admin ───────────────────────────────────────────────────────
if (!is_logged_in()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Not logged in']);
    exit;
}
$u = current_user();
if ($u['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Admin access required']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'POST required']);
    exit;
}

$pdo  = db();
$mode = trim($_POST['mode'] ?? 'remote');

// ── Shared: merge one SQLite file into the live DB ───────────────────────────
function merge_db_file(string $path, PDO $pdo): array
{
    $result = ['file' => basename($path), 'ok' => false, 'merged' => [], 'errors' => []];

    $sig = @file_get_contents($path, false, null, 0, 16);
    if (!str_starts_with((string)$sig, 'SQLite format 3')) {
        $result['errors'][] = 'Not a valid SQLite3 file — skipped.';
        return $result;
    }

    try {
        $safe = str_replace("'", "''", $path);
        $pdo->exec("ATTACH DATABASE '$safe' AS remote");

        // Tolerate older remote DBs that lack the filename column
        try { $pdo->exec("ALTER TABLE remote.seller_inventory ADD COLUMN filename TEXT"); } catch (\PDOException) {}

        $remote_user_columns = array_column($pdo->query("PRAGMA remote.table_info(users)")->fetchAll(), 'name');
        $remote_telegram = in_array('telegram_username', $remote_user_columns, true)
            ? 'telegram_username'
            : "''";
        $n = $pdo->exec("
            INSERT OR IGNORE INTO main.users
                (id, username, password, telegram_username, role, balance, created_at)
            SELECT id, username, password, $remote_telegram, role, balance, created_at
            FROM remote.users
            WHERE username NOT IN (SELECT username FROM main.users)
        ");
        $result['merged']['users'] = $n;

        $n = $pdo->exec("
            INSERT OR IGNORE INTO main.cards
                (seller_id,number,exp,cvv,card_name,bin,brand,card_type,bank,country,balance,price,status,pin_hash,created_at)
            SELECT seller_id,number,exp,cvv,card_name,bin,brand,card_type,bank,country,balance,price,status,pin_hash,created_at
            FROM remote.cards
            WHERE (number||'|'||exp||'|'||cvv) NOT IN
                  (SELECT number||'|'||exp||'|'||cvv FROM main.cards)
        ");
        $result['merged']['cards'] = $n;

        $n = $pdo->exec("
            INSERT OR IGNORE INTO main.seller_inventory
                (seller_id, filename, raw_data, count, imported, created_at)
            SELECT seller_id, filename, raw_data, count, imported, created_at
            FROM remote.seller_inventory
            WHERE raw_data NOT IN (SELECT raw_data FROM main.seller_inventory)
        ");
        $result['merged']['seller_inventory'] = $n;

        $n = $pdo->exec("INSERT OR IGNORE INTO main.settings SELECT * FROM remote.settings");
        $result['merged']['settings'] = $n;

        $pdo->exec("DETACH DATABASE remote");
        $result['ok'] = true;
    } catch (\Throwable $e) {
        $result['errors'][] = $e->getMessage();
        try { $pdo->exec("DETACH DATABASE remote"); } catch (\Throwable) {}
    }

    return $result;
}

function trim_backups(): void
{
    $files = glob(dirname(DB_PATH) . '/market.backup.*.db') ?: [];
    rsort($files);
    foreach (array_slice($files, 5) as $f) @unlink($f);
}

// ── Mode: remote ─────────────────────────────────────────────────────────────
if ($mode === 'remote') {
    $url = trim($_POST['url'] ?? get_setting('sync_remote_url', ''));

    if (!$url || !preg_match('/^https?:\/\//i', $url)) {
        echo json_encode(['ok' => false, 'error' => 'No valid remote URL provided.']);
        exit;
    }

    // Persist the URL so the form re-populates
    set_setting('sync_remote_url', $url);

    // Download via file_get_contents, fall back to cURL
    $ctx   = stream_context_create(['http' => ['timeout' => 30, 'user_agent' => 'BytePool-Sync/1.0'],
                                    'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false]]);
    $bytes = @file_get_contents($url, false, $ctx);

    if ($bytes === false && function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $bytes  = curl_exec($ch);
        $curlerr = curl_error($ch);
        curl_close($ch);
        if (!$bytes) {
            echo json_encode(['ok' => false, 'error' => 'Download failed: ' . $curlerr]);
            exit;
        }
    }

    if (!$bytes) {
        echo json_encode(['ok' => false, 'error' => 'Could not download remote DB — check the URL and server accessibility.']);
        exit;
    }

    $tmp = tempnam(sys_get_temp_dir(), 'cm_sync_');
    file_put_contents($tmp, $bytes);

    $backup = dirname(DB_PATH) . '/market.backup.' . date('Ymd_His') . '.db';
    if (file_exists(DB_PATH)) copy(DB_PATH, $backup);

    $result = merge_db_file($tmp, $pdo);
    @unlink($tmp);
    trim_backups();

    echo json_encode([
        'ok'     => $result['ok'],
        'source' => 'remote',
        'url'    => $url,
        'size'   => strlen($bytes),
        'result' => $result,
        'backup' => basename($backup),
        'ts'     => date('Y-m-d H:i:s'),
    ], JSON_PRETTY_PRINT);
    exit;
}

// ── Mode: local — scan data/*.db ─────────────────────────────────────────────
$data_dir   = dirname(DB_PATH);
$main_db    = realpath(DB_PATH);
$candidates = glob($data_dir . '/*.db') ?: [];
$to_merge   = [];

foreach ($candidates as $path) {
    $real = realpath($path);
    if ($real === false || $real === $main_db) continue;
    if (str_ends_with($path, '.merged.db')) continue;
    $to_merge[] = $path;
}

if (empty($to_merge)) {
    echo json_encode([
        'ok'      => true,
        'source'  => 'local',
        'message' => 'No new .db files found in data/ to merge.',
        'scanned' => array_map('basename', $candidates),
    ], JSON_PRETTY_PRINT);
    exit;
}

$backup = dirname(DB_PATH) . '/market.backup.' . date('Ymd_His') . '.db';
if (file_exists(DB_PATH)) copy(DB_PATH, $backup);

$results = [];
foreach ($to_merge as $path) {
    $r = merge_db_file($path, $pdo);
    if ($r['ok']) {
        $archived       = $data_dir . '/' . pathinfo($path, PATHINFO_FILENAME) . '.merged.db';
        rename($path, $archived);
        $r['archived_as'] = basename($archived);
    }
    $results[] = $r;
}
trim_backups();

echo json_encode([
    'ok'           => true,
    'source'       => 'local',
    'files_merged' => count(array_filter($results, fn($r) => $r['ok'])),
    'backup'       => basename($backup),
    'results'      => $results,
    'ts'           => date('Y-m-d H:i:s'),
], JSON_PRETTY_PRINT);
