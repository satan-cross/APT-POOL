<?php
declare(strict_types=1);
/**
 * HD_Wallet.php — Pure-PHP BIP32/39/44/49/84 HD Wallet
 *
 * Supports:
 *   • BIP39 mnemonic generation (12 or 24 words, CSPRNG entropy)
 *   • BIP39 → BIP32 seed (PBKDF2-HMAC-SHA512, 2048 rounds)
 *   • BIP32 master key + hardened child derivation (full private key path)
 *   • Account-level xpub export (correct version bytes per coin)
 *   • Address derivation from xpub (no private key needed at runtime)
 *
 * Coin support:
 *   btc        — Bitcoin Legacy    P2PKH     m/44'/0'/0'   xpub
 *   btc_segwit — Bitcoin SegWit    P2WPKH    m/84'/0'/0'   zpub → bc1…
 *   ltc        — Litecoin Legacy   P2PKH     m/44'/2'/0'   Ltub
 *   ltc_segwit — Litecoin SegWit   P2WPKH    m/84'/2'/0'   zpub → ltc1…
 *   usdt_trc20 — USDT TRC-20/Tron            m/44'/195'/0' xpub → T…
 *   xmr        — Monero (static address only)
 *
 * Requirements: PHP 7.4+, GMP extension
 */
class HD_Wallet
{
    // ── secp256k1 parameters ─────────────────────────────────────────────────
    private static function p(): \GMP  { static $v; return $v ??= gmp_init('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F',16); }
    private static function Gx(): \GMP { static $v; return $v ??= gmp_init('79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798',16); }
    private static function Gy(): \GMP { static $v; return $v ??= gmp_init('483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8',16); }
    private static function N(): \GMP  { static $v; return $v ??= gmp_init('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141',16); }

    // ── Field arithmetic ────────────────────────────────────────────────────
    private static function fadd(\GMP $a, \GMP $b): \GMP { return gmp_mod(gmp_add($a,$b),self::p()); }
    private static function fsub(\GMP $a, \GMP $b): \GMP { return gmp_mod(gmp_add(gmp_sub($a,$b),self::p()),self::p()); }
    private static function fmul(\GMP $a, \GMP $b): \GMP { return gmp_mod(gmp_mul($a,$b),self::p()); }
    private static function finv(\GMP $a): \GMP            { return gmp_powm($a,gmp_sub(self::p(),gmp_init(2)),self::p()); }

    // ── EC point operations ──────────────────────────────────────────────────
    private static function ecAdd(?array $P, ?array $Q): ?array {
        if ($P === null) return $Q;
        if ($Q === null) return $P;
        [$x1,$y1] = $P; [$x2,$y2] = $Q;
        if (gmp_cmp($x1,$x2)===0) {
            if (gmp_cmp($y1,$y2)!==0) return null;
            $num = self::fmul(gmp_init(3),self::fmul($x1,$x1));
            $den = self::fmul(gmp_init(2),$y1);
            $lam = self::fmul($num,self::finv($den));
        } else {
            $lam = self::fmul(self::fsub($y2,$y1),self::finv(self::fsub($x2,$x1)));
        }
        $x3 = self::fsub(self::fsub(self::fmul($lam,$lam),$x1),$x2);
        $y3 = self::fsub(self::fmul($lam,self::fsub($x1,$x3)),$y1);
        return [$x3,$y3];
    }

    private static function ecMul(\GMP $k, array $G): ?array {
        $R = null;
        foreach (str_split(gmp_strval($k,2)) as $bit) {
            $R = self::ecAdd($R,$R);
            if ($bit==='1') $R = self::ecAdd($R,$G);
        }
        return $R;
    }

    private static function decompressPubKey(string $compressed): array {
        if (strlen($compressed)!==33) throw new \RuntimeException('Invalid compressed pubkey length');
        $prefix = ord($compressed[0]);
        if ($prefix!==2 && $prefix!==3) throw new \RuntimeException('Invalid pubkey prefix');
        $x  = gmp_import(substr($compressed,1,32), 1, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
        $p  = self::p();
        $y2 = gmp_mod(gmp_add(gmp_powm($x,gmp_init(3),$p),gmp_init(7)),$p);
        $exp = gmp_div_q(gmp_add($p,gmp_init(1)),gmp_init(4));
        $y   = gmp_powm($y2,$exp,$p);
        if (gmp_cmp(gmp_mod($y,gmp_init(2)),gmp_init(0))!==0 xor $prefix===3) {
            $y = gmp_sub($p,$y);
        }
        return [$x,$y];
    }

    private static function compressPubKey(\GMP $x, \GMP $y): string {
        $prefix  = gmp_strval(gmp_mod($y,gmp_init(2)),10)==='0' ? "\x02" : "\x03";
        $xBytes  = str_pad(gmp_export($x, 1, GMP_MSW_FIRST | GMP_BIG_ENDIAN), 32, "\x00", STR_PAD_LEFT);
        return $prefix . $xBytes;
    }

    // ── Private key → compressed public key ─────────────────────────────────
    private static function privToCompressedPub(string $privBytes32): string {
        $k  = gmp_import($privBytes32, 1, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
        $G  = [self::Gx(), self::Gy()];
        $pt = self::ecMul($k, $G);
        if ($pt === null) throw new \RuntimeException('Private key produced infinity point');
        return self::compressPubKey($pt[0], $pt[1]);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // BIP39 — Mnemonic generation & seed derivation
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Generate a cryptographically secure BIP39 mnemonic.
     *
     * @param int $strength  Entropy bits: 128 = 12 words, 256 = 24 words.
     * @return string        Space-separated mnemonic words.
     */
    public static function generateMnemonic(int $strength = 128): string {
        if (!in_array($strength, [128, 160, 192, 224, 256], true)) {
            throw new \InvalidArgumentException('Strength must be 128, 160, 192, 224 or 256');
        }
        $entropy   = random_bytes($strength / 8);
        $hashByte  = ord(hash('sha256', $entropy, true)[0]);
        $bits      = '';
        foreach (str_split($entropy) as $b) {
            $bits .= str_pad(decbin(ord($b)), 8, '0', STR_PAD_LEFT);
        }
        $bits     .= str_pad(decbin($hashByte >> (8 - $strength / 32)), $strength / 32, '0', STR_PAD_LEFT);
        $wordlist  = self::bip39Words();
        $words     = [];
        for ($i = 0; $i < strlen($bits); $i += 11) {
            $words[] = $wordlist[bindec(substr($bits, $i, 11))];
        }
        return implode(' ', $words);
    }

    /**
     * Validate a BIP39 mnemonic checksum.
     */
    public static function validateMnemonic(string $mnemonic): bool {
        $words    = explode(' ', trim($mnemonic));
        $wordlist = self::bip39Words();
        $index    = array_flip($wordlist);
        $bits     = '';
        foreach ($words as $w) {
            if (!isset($index[$w])) return false;
            $bits .= str_pad(decbin($index[$w]), 11, '0', STR_PAD_LEFT);
        }
        $divider   = intdiv(strlen($bits) * 32, 33);
        $entropyBits = substr($bits, 0, $divider);
        $checksumBits = substr($bits, $divider);
        $entropy   = '';
        for ($i = 0; $i < strlen($entropyBits); $i += 8) {
            $entropy .= chr(bindec(substr($entropyBits, $i, 8)));
        }
        $hash      = hash('sha256', $entropy, true);
        $hashBits  = str_pad(decbin(ord($hash[0])), 8, '0', STR_PAD_LEFT);
        $expectedCS = substr($hashBits, 0, strlen($checksumBits));
        return hash_equals($expectedCS, $checksumBits);
    }

    /**
     * Convert a BIP39 mnemonic to a 64-byte binary seed (PBKDF2-HMAC-SHA512).
     * Compatible with all BIP39 hardware wallets (Ledger, Trezor, etc.).
     */
    public static function mnemonicToSeed(string $mnemonic, string $passphrase = ''): string {
        $normalized = mb_strtolower(trim(preg_replace('/\s+/', ' ', $mnemonic)), 'UTF-8');
        return hash_pbkdf2('sha512', $normalized, 'mnemonic' . $passphrase, 2048, 64, true);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // BIP32 — Private key tree
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Derive BIP32 master key from a 64-byte seed.
     * Returns ['key'=>32bytes, 'chain_code'=>32bytes, 'depth'=>0, 'index'=>0, 'fingerprint'=>"\x00\x00\x00\x00"]
     */
    public static function seedToMasterKey(string $seed): array {
        $I  = hash_hmac('sha512', $seed, 'Bitcoin seed', true);
        $IL = substr($I, 0, 32);
        $IR = substr($I, 32, 32);
        $k  = gmp_import($IL, 1, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
        if (gmp_cmp($k, gmp_init(0)) === 0 || gmp_cmp($k, self::N()) >= 0) {
            throw new \RuntimeException('Invalid master key (IL out of range) — use a different seed');
        }
        return [
            'key'         => $IL,
            'chain_code'  => $IR,
            'depth'       => 0,
            'index'       => 0,
            'fingerprint' => "\x00\x00\x00\x00",
        ];
    }

    /**
     * Derive a private-key child node.
     * Index >= 0x80000000 → hardened child.
     */
    private static function derivePrivateChild(array $node, int $index): array {
        $hardened = $index >= 0x80000000;
        if ($hardened) {
            $data = "\x00" . $node['key'] . pack('N', $index);
        } else {
            $pub  = self::privToCompressedPub($node['key']);
            $data = $pub . pack('N', $index);
        }
        $I  = hash_hmac('sha512', $data, $node['chain_code'], true);
        $IL = substr($I, 0, 32);
        $IR = substr($I, 32, 32);
        $ilInt  = gmp_import($IL, 1, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
        if (gmp_cmp($ilInt, self::N()) >= 0) throw new \RuntimeException('Derived IL >= n (astronomically unlikely)');
        $parentK = gmp_import($node['key'], 1, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
        $childK  = gmp_mod(gmp_add($ilInt, $parentK), self::N());
        if (gmp_cmp($childK, gmp_init(0)) === 0) throw new \RuntimeException('Derived child key is zero (astronomically unlikely)');
        $childKeyBytes = str_pad(gmp_export($childK, 1, GMP_MSW_FIRST | GMP_BIG_ENDIAN), 32, "\x00", STR_PAD_LEFT);

        // Parent fingerprint = first 4 bytes of HASH160(parent_pubkey)
        $parentPub = self::privToCompressedPub($node['key']);
        $fingerprint = substr(self::hash160($parentPub), 0, 4);

        return [
            'key'         => $childKeyBytes,
            'chain_code'  => $IR,
            'depth'       => $node['depth'] + 1,
            'index'       => $index,
            'fingerprint' => $fingerprint,
        ];
    }

    /**
     * Derive a private key node at a given BIP32 path.
     * Path format: "m/44'/0'/0'" — apostrophe = hardened.
     */
    public static function derivePrivatePath(array $masterNode, string $path): array {
        $parts = explode('/', trim($path, "m/"));
        $node  = $masterNode;
        foreach ($parts as $part) {
            if ($part === '' || $part === 'm') continue;
            $hardened = str_ends_with($part, "'");
            $index    = (int)rtrim($part, "'");
            if ($hardened) $index += 0x80000000;
            $node = self::derivePrivateChild($node, $index);
        }
        return $node;
    }

    /**
     * Serialize a private-key node as a Base58Check xpub (public half only).
     *
     * @param array  $privNode  Node from derivePrivatePath/derivePrivateChild
     * @param string $version   4-byte raw version string (use XPUB_VERSION_* constants)
     */
    public static function serializeXpub(array $privNode, string $version): string {
        $pub     = self::privToCompressedPub($privNode['key']);
        $payload =
            $version
            . chr($privNode['depth'])
            . $privNode['fingerprint']
            . pack('N', $privNode['index'])
            . $privNode['chain_code']
            . $pub;
        return self::base58CheckEncode($payload);
    }

    // xpub version bytes (mainnet)
    const XPUB_VERSION_BTC_LEGACY  = "\x04\x88\xB2\x1E"; // xpub
    const XPUB_VERSION_BTC_SEGWIT  = "\x04\xB2\x47\x46"; // zpub
    const XPUB_VERSION_LTC_LEGACY  = "\x01\x9D\xA4\x62"; // Ltub
    const XPUB_VERSION_LTC_SEGWIT  = "\x01\xB2\x6E\xF6"; // Mtub
    const XPUB_VERSION_TRON        = "\x04\x88\xB2\x1E"; // same as xpub

    /**
     * Generate account-level xpubs for all supported coins from a mnemonic.
     * Returns array keyed by coin slug with 'xpub', 'path', 'version_name'.
     *
     * These xpubs are fully compatible with Electrum, Ledger, Trezor, etc.
     */
    public static function generateAllXpubs(string $mnemonic, string $passphrase = ''): array {
        $seed   = self::mnemonicToSeed($mnemonic, $passphrase);
        $master = self::seedToMasterKey($seed);

        $coins = [
            'btc' => [
                'path'         => "m/44'/0'/0'",
                'version'      => self::XPUB_VERSION_BTC_LEGACY,
                'version_name' => 'xpub',
            ],
            'btc_segwit' => [
                'path'         => "m/84'/0'/0'",
                'version'      => self::XPUB_VERSION_BTC_SEGWIT,
                'version_name' => 'zpub',
            ],
            'ltc' => [
                'path'         => "m/44'/2'/0'",
                'version'      => self::XPUB_VERSION_LTC_LEGACY,
                'version_name' => 'Ltub',
            ],
            'ltc_segwit' => [
                'path'         => "m/84'/2'/0'",
                'version'      => self::XPUB_VERSION_LTC_SEGWIT,
                'version_name' => 'Mtub',
            ],
            'usdt_trc20' => [
                'path'         => "m/44'/195'/0'",
                'version'      => self::XPUB_VERSION_TRON,
                'version_name' => 'xpub',
            ],
        ];

        $result = [];
        foreach ($coins as $slug => $def) {
            $node            = self::derivePrivatePath($master, $def['path']);
            $result[$slug]   = [
                'xpub'         => self::serializeXpub($node, $def['version']),
                'path'         => $def['path'],
                'version_name' => $def['version_name'],
            ];
        }
        return $result;
    }

    /**
     * Derive a test address at index 0 from a generated xpub.
     * Use this to cross-check with Electrum / hardware wallet.
     */
    public static function testAddress(string $xpub, string $coin): string {
        return self::deriveAddress($xpub, 0, $coin);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Public API: derive deposit address from xpub (no private key needed)
    // ══════════════════════════════════════════════════════════════════════════

    public static function parseXpub(string $xpub): array {
        $raw = self::base58CheckDecode($xpub);
        if ($raw === false || strlen($raw) !== 78) {
            throw new \RuntimeException("Invalid xpub: bad checksum or length ($xpub)");
        }
        return [
            'version'      => substr($raw, 0, 4),
            'depth'        => ord($raw[4]),
            'fingerprint'  => substr($raw, 5, 4),
            'child_number' => substr($raw, 9, 4),
            'chain_code'   => substr($raw, 13, 32),
            'key'          => substr($raw, 45, 33),
        ];
    }

    public static function deriveChild(array $node, int $i): array {
        if ($i >= 0x80000000) throw new \RuntimeException('Cannot harden-derive from xpub');
        $data = $node['key'] . pack('N', $i);
        $I    = hash_hmac('sha512', $data, $node['chain_code'], true);
        $IL   = substr($I, 0, 32);
        $IR   = substr($I, 32, 32);
        $ilInt = gmp_import($IL, 1, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
        if (gmp_cmp($ilInt, self::N()) >= 0) throw new \RuntimeException('Derived key invalid (IL >= n)');
        $G   = [self::Gx(), self::Gy()];
        [$px,$py] = self::decompressPubKey($node['key']);
        $ilP = self::ecMul($ilInt, $G);
        $childPt = self::ecAdd($ilP, [$px,$py]);
        if ($childPt === null) throw new \RuntimeException('Derived child point is infinity');
        $childPub = self::compressPubKey($childPt[0], $childPt[1]);
        return ['chain_code' => $IR, 'key' => $childPub];
    }

    public static function deriveAddress(string $xpub, int $index, string $coin): string {
        $node  = self::parseXpub($xpub);
        $chain = self::deriveChild($node, 0);
        $leaf  = self::deriveChild($chain, $index);
        $pub   = $leaf['key'];

        switch ($coin) {
            case 'btc':        return self::p2pkhAddress($pub, "\x00");
            case 'btc_segwit': return self::p2wpkhBech32Address($pub, 'bc');
            case 'ltc':        return self::p2pkhAddress($pub, "\x30");
            case 'ltc_segwit': return self::p2wpkhBech32Address($pub, 'ltc');
            case 'usdt_trc20': return self::tronAddress($pub);
            default: throw new \RuntimeException("Unsupported coin: $coin");
        }
    }

    public static function validateXpub(string $xpub, string $coin): string {
        return self::deriveAddress($xpub, 0, $coin);
    }

    // ── Address encoders ─────────────────────────────────────────────────────

    private static function p2pkhAddress(string $pub, string $versionByte): string {
        return self::base58CheckEncode($versionByte . self::hash160($pub));
    }

    private static function p2wpkhBech32Address(string $pub, string $hrp): string {
        return self::encodeBech32($hrp, 0, self::hash160($pub));
    }

    private static function tronAddress(string $compressedPub): string {
        [$x,$y] = self::decompressPubKey($compressedPub);
        $xb = str_pad(gmp_export($x,1,GMP_MSW_FIRST|GMP_BIG_ENDIAN),32,"\x00",STR_PAD_LEFT);
        $yb = str_pad(gmp_export($y,1,GMP_MSW_FIRST|GMP_BIG_ENDIAN),32,"\x00",STR_PAD_LEFT);
        $keccak  = self::keccak256($xb . $yb);
        $ethAddr = substr($keccak, 12, 20);
        return self::base58CheckEncode("\x41" . $ethAddr);
    }

    private static function hash160(string $data): string {
        return hash('ripemd160', hash('sha256', $data, true), true);
    }

    // ── Base58Check ──────────────────────────────────────────────────────────
    private const BASE58_ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

    public static function base58CheckEncode(string $payload): string {
        $checksum = substr(hash('sha256', hash('sha256', $payload, true), true), 0, 4);
        $data     = $payload . $checksum;
        $n        = gmp_import($data, 1, GMP_MSW_FIRST | GMP_BIG_ENDIAN);
        $result   = '';
        $base     = gmp_init(58);
        while (gmp_cmp($n, gmp_init(0)) > 0) {
            [$n, $rem] = gmp_div_qr($n, $base);
            $result    = self::BASE58_ALPHABET[gmp_intval($rem)] . $result;
        }
        for ($i = 0; $i < strlen($data) && $data[$i] === "\x00"; $i++) {
            $result = '1' . $result;
        }
        return $result;
    }

    public static function base58CheckDecode(string $encoded): string|false {
        $n    = gmp_init(0);
        $base = gmp_init(58);
        $alpha = self::BASE58_ALPHABET;
        foreach (str_split($encoded) as $char) {
            $pos = strpos($alpha, $char);
            if ($pos === false) return false;
            $n   = gmp_add(gmp_mul($n, $base), gmp_init($pos));
        }
        $hex = gmp_strval($n, 16);
        if (strlen($hex) % 2 !== 0) $hex = '0' . $hex;
        $raw = hex2bin($hex);
        if ($raw === false) return false;
        $leading = '';
        for ($i = 0; $i < strlen($encoded) && $encoded[$i] === '1'; $i++) {
            $leading .= "\x00";
        }
        $full     = $leading . $raw;
        $payload  = substr($full, 0, -4);
        $checksum = substr($full, -4);
        $expected = substr(hash('sha256', hash('sha256', $payload, true), true), 0, 4);
        return hash_equals($expected, $checksum) ? $payload : false;
    }

    // ── Bech32 ───────────────────────────────────────────────────────────────
    private static function encodeBech32(string $hrp, int $witver, string $prog): string {
        $data = self::convertBits(array_values(unpack('C*', $prog)), 8, 5, true);
        array_unshift($data, $witver);
        $checksum = self::bech32Checksum($hrp, $data);
        $charset  = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';
        $result   = $hrp . '1';
        foreach (array_merge($data, $checksum) as $v) $result .= $charset[$v];
        return $result;
    }

    private static function bech32Checksum(string $hrp, array $data): array {
        $values = array_merge(self::bech32HrpExpand($hrp), $data, [0,0,0,0,0,0]);
        $poly   = self::bech32Polymod($values) ^ 1;
        $result = [];
        for ($i = 5; $i >= 0; $i--) $result[] = ($poly >> (5 * $i)) & 31;
        return $result;
    }

    private static function bech32HrpExpand(string $hrp): array {
        $ret = [];
        foreach (str_split($hrp) as $c) $ret[] = ord($c) >> 5;
        $ret[] = 0;
        foreach (str_split($hrp) as $c) $ret[] = ord($c) & 31;
        return $ret;
    }

    private static function bech32Polymod(array $values): int {
        $GEN = [0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3];
        $chk = 1;
        foreach ($values as $v) {
            $b = $chk >> 25;
            $chk = (($chk & 0x1ffffff) << 5) ^ $v;
            for ($i = 0; $i < 5; $i++) {
                if (($b >> $i) & 1) $chk ^= $GEN[$i];
            }
        }
        return $chk;
    }

    private static function convertBits(array $data, int $from, int $to, bool $pad): array {
        $acc  = 0; $bits = 0; $ret = []; $maxv = (1 << $to) - 1;
        foreach ($data as $value) {
            $acc  = ($acc << $from) | $value;
            $bits += $from;
            while ($bits >= $to) { $bits -= $to; $ret[] = ($acc >> $bits) & $maxv; }
        }
        if ($pad && $bits > 0) $ret[] = ($acc << ($to - $bits)) & $maxv;
        return $ret;
    }

    // ── Keccak-256 (original, not NIST SHA-3) ───────────────────────────────
    public static function keccak256(string $data): string {
        $rate   = 136;
        $outLen = 32;
        $msg    = $data;
        $msgLen = strlen($msg);
        $padLen = $rate - ($msgLen % $rate);
        $msg   .= "\x01" . str_repeat("\x00", $padLen - 1);
        $msg[strlen($msg)-1] = chr(ord($msg[strlen($msg)-1]) | 0x80);
        $state  = array_fill(0, 25, [0, 0]);
        $blocks = strlen($msg) / $rate;
        for ($b = 0; $b < $blocks; $b++) {
            $block = substr($msg, $b * $rate, $rate);
            for ($i = 0; $i < $rate / 8; $i++) {
                $lo = unpack('V', substr($block, $i*8,   4))[1];
                $hi = unpack('V', substr($block, $i*8+4, 4))[1];
                $state[$i][0] ^= $lo;
                $state[$i][1] ^= $hi;
            }
            $state = self::keccakF($state);
        }
        $out = '';
        for ($i = 0; $i < $outLen / 8; $i++) {
            $out .= pack('V', $state[$i][0]) . pack('V', $state[$i][1]);
        }
        return $out;
    }

    private static function keccakF(array $A): array {
        static $RC = [
            [0x00000001,0x00000000],[0x00008082,0x00000000],[0x0000808A,0x80000000],
            [0x80008000,0x80000000],[0x0000808B,0x00000000],[0x80000001,0x00000000],
            [0x80008081,0x80000000],[0x00008009,0x80000000],[0x0000008A,0x00000000],
            [0x00000088,0x00000000],[0x80008009,0x00000000],[0x8000000A,0x00000000],
            [0x8000808B,0x00000000],[0x0000008B,0x80000000],[0x00008089,0x80000000],
            [0x00008003,0x80000000],[0x00008002,0x80000000],[0x00000080,0x80000000],
            [0x0000800A,0x00000000],[0x8000000A,0x80000000],[0x80008081,0x80000000],
            [0x00008080,0x80000000],[0x80000001,0x00000000],[0x80008008,0x80000000],
        ];
        static $ROT = [0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14];
        for ($round = 0; $round < 24; $round++) {
            $C = [];
            for ($x=0;$x<5;$x++) $C[$x] = [
                $A[$x][0]^$A[$x+5][0]^$A[$x+10][0]^$A[$x+15][0]^$A[$x+20][0],
                $A[$x][1]^$A[$x+5][1]^$A[$x+10][1]^$A[$x+15][1]^$A[$x+20][1],
            ];
            $D = [];
            for ($x=0;$x<5;$x++) {
                $r1   = self::rot64($C[($x+1)%5], 1);
                $D[$x] = [$C[($x+4)%5][0]^$r1[0], $C[($x+4)%5][1]^$r1[1]];
            }
            for ($i=0;$i<25;$i++) { $A[$i][0]^=$D[$i%5][0]; $A[$i][1]^=$D[$i%5][1]; }
            $B = array_fill(0, 25, [0,0]);
            for ($x=0;$x<5;$x++) for ($y=0;$y<5;$y++) {
                $B[$y + 5*(((2*$x + 3*$y)%5))] = self::rot64($A[$x+5*$y], $ROT[$x+5*$y]);
            }
            for ($x=0;$x<5;$x++) for ($y=0;$y<5;$y++) {
                $i = $x+5*$y;
                $A[$i][0] = ($B[$i][0] ^ ((~$B[(($x+1)%5)+5*$y][0]) & $B[(($x+2)%5)+5*$y][0])) & 0xFFFFFFFF;
                $A[$i][1] = ($B[$i][1] ^ ((~$B[(($x+1)%5)+5*$y][1]) & $B[(($x+2)%5)+5*$y][1])) & 0xFFFFFFFF;
            }
            $A[0][0] = ($A[0][0] ^ $RC[$round][0]) & 0xFFFFFFFF;
            $A[0][1] = ($A[0][1] ^ $RC[$round][1]) & 0xFFFFFFFF;
        }
        return $A;
    }

    private static function rot64(array $v, int $n): array {
        [$lo,$hi] = $v; $n &= 63;
        if ($n === 0)  return $v;
        if ($n === 32) return [$hi, $lo];
        if ($n < 32) {
            $newLo = (($lo << $n) | ($hi >> (32 - $n))) & 0xFFFFFFFF;
            $newHi = (($hi << $n) | ($lo >> (32 - $n))) & 0xFFFFFFFF;
        } else {
            $n -= 32;
            $newLo = (($hi << $n) | ($lo >> (32 - $n))) & 0xFFFFFFFF;
            $newHi = (($lo << $n) | ($hi >> (32 - $n))) & 0xFFFFFFFF;
        }
        return [$newLo, $newHi];
    }

    // ── BIP39 English wordlist (2048 words, BIP39 standard) ──────────────────
    private static function bip39Words(): array {
        static $w;
        if ($w !== null) return $w;
        $raw = 'abandon ability able about above absent absorb abstract absurd abuse access accident account accuse achieve acid acoustic acquire across act action actor actress actual adapt add addict address adjust admit adult advance advice aerobic afford afraid again age agent agree ahead aim air airport aisle alarm album alcohol alert alien all alley allow almost alone alpha already also alter always amateur amazing among amount amused analyst anchor ancient anger angle angry animal ankle announce annual another answer antenna antique anxiety any apart apology appear apple approve april arch arctic area arena argue arm armed armor army around arrange arrest arrive arrow art artefact artist artwork ask aspect assault asset assist assume asthma athlete atom attack attend attitude attract auction audit august aunt author auto autumn average avocado avoid awake aware away awesome awful awkward axis baby bachelor bacon badge bag balance balcony ball bamboo banana banner bar barely bargain barrel base basic basket battle beach bean beauty because become beef before begin behave behind believe below belt bench benefit best betray better between beyond bicycle bid bike bind biology bird birth bitter black blade blame blanket blast bleak bless blind blood blossom blouse blue blur blush board boat body boil bomb bone book boost border boring borrow boss bottom bounce box boy bracket brain brand brave breeze brick bridge brief bright bring brisk broccoli broken bronze broom brother brown brush bubble buddy budget buffalo build bulb bulk bullet bundle bunker burden burger burst bus business busy butter buyer buzz cabbage cabin cable cactus cage cake call calm camera camp can canal cancel candy cannon canvas canyon capable capital captain car carbon card cargo carpet carry cart case cash casino castle casual cat catalog catch category cattle caught cause caution cave ceiling celery cement census chair chaos chapter charge chase chat cheap check cheese chef cherry chest chicken chief child chimney choice choose chronic clap clarify claw clay clean clerk clever click client cliff climb clinic clip clock clog close cloth cloud clown club clump cluster clutch coach coast coconut code coffee coil coin collect color column combine come comfort comic common company concert conduct confirm congress connect consider control convince cook cool copper copy coral core corn correct cost cotton couch country couple course cousin cover coyote crack cradle craft cram crane crash crater crawl crazy cream credit creek crew cricket crime crisp critic cross crouch crowd crucial cruel cruise crumble crunch crush cry crystal cube culture cup cupboard curious current curtain curve cushion custom cute cycle dad damage damp dance danger daring dash daughter dawn day deal debate debris decade december decide decline decorate decrease deer defense define defy degree delay deliver demand demise denial dentist deny depart depend deposit depth deputy derive describe desert design desk despair destroy detail detect develop device devote diagram dial diamond diary dice diesel diet differ digital dignity dilemma dinner dinosaur direct dirt disagree discover disease dish dismiss disorder display distance divert divide divorce dizzy doctor document dog doll dolphin domain donate donkey donor door dose double dove draft dragon drama drastic draw dream dress drift drill drink drip drive drop drum dry duck dumb dune during dust dutch duty dwarf dynamic eager eagle early earn earth easily east easy echo ecology edge edit educate effort egg eight either elbow elder electric elegant element elephant elevator elite else embark embody embrace emerge emotion employ empower empty enable enact endless endorse enemy engage engine enhance enjoy enlist enough enrich enroll ensure enter entire entry envelope episode equal equip erase erase erosion error erupt escape essay essence estate eternal ethics evidence evil evoke evolve exact example excess exchange excite exclude exercise exhaust exhibit exile exist exit exotic expand expire explain expose express extend extra eye fable face faculty fade faint faith fall false fame family famous fan fancy fantasy far fashion fat fatal father fatigue fault favorite feature february federal fee feed feel feet fellow felt fence festival fetch fever few fiber fiction field figure file film filter final find fine finger finish fire firm first fiscal fish fit fitness fix flag flame flash flat flavor flee flight flip float flock floor flower fluid flush fly foam focus fog foil follow food foot force forest forget fork fortune forum forward fossil foster found fox fragile frame frequent fresh friend fringe frog front frost frown frozen fruit fuel fun funny furnace fury future gadget gain galaxy gallery game gap garbage garden garlic garment gas gasp gate gather gauge gaze general genius genre gentle genuine gesture ghost ginger giraffe girl give glad glance glare glass glide glimpse globe gloom glory glove glow glue goat goddess gold good goose gorilla gospel gossip govern gown grab grace grain grant grape grasp grass gravity great green grid grief grit grocery group grow grunt guard guide guilt guitar gun gym habit hair half hamster hand happy harsh harvest hat have hawk hazard head health heart heavy hedgehog height hello helmet help hen hero hidden high hill hint hip hire history hobby hockey hold hole holiday hollow home honey hood hope horn hospital host hour hover hub huge human humble humor hundred hungry hunt hurdle hurry hurt husband hybrid ice icon ignore ill illegal image imitate immense immune impact impose improve impulse inbox include income increase index indicate indoor industry infant inflict inform inhale inject injury inmate inner innocent input inquiry insane insect inside inspire install intact interest into invest invite involve iron island isolate issue item ivory jacket jaguar jar jazz jealous jeans jelly jewel job join joke journey joy judge juice jump jungle junior junk just kangaroo keen keep ketchup key kick kid kingdom kiss kit kitchen kite kitten kiwi knee knife knock know lab ladder lady lake lamp language laptop large later laugh laundry lava law lawn lawsuit layer lazy leader learn leave lecture left leg legal legend leisure lemon lend length lens leopard lesson letter level liar liberty library license life lift light like limb limit link lion liquid list little live lizard load loan lobster local lock logic lonely long loop lottery loud lounge love loyal lucky luggage lunar lunch luxury lyrics magic magnet maid main major make mammal mango mansion manual maple marble march margin marine market marriage mask master match material math matrix matter maximum maze meadow mean medal media melody melt member memory mention mentor menu mercy merge merit merry mesh message metal method middle midnight milk million mimic mind minimum minor minute miracle miss mitten mobile model modify mom monitor monkey monster month moon moral more morning mosquito mother motion motor mountain mouse move movie much muffin mule multiply muscle museum mushroom music must mutual myself mystery naive name napkin narrow nasty natural nature near neck need negative neglect neither nephew nerve nest network neutral never news next nice night noble noise nominee noodle normal north notable note nothing notice novel now nuclear number nurse nut oak obey object oblige obscure observe obtain obvious occur ocean october odor off offer office often oil okay old olive olympic omit once onion open oppose option orange orbit orchard order ordinary organ orient original orphan ostrich other outdoor outside oval over own oyster ozone pact paddle page pair palace palm panda panic panther paper parade parent park parrot party pass patch path patrol pause pave payment peace peanut peasant pelican pen penalty pencil people pepper perfect permit person pet phone photo phrase physical piano picnic picture piece pig pigeon pill pilot pink pioneer pipe pistol pitch pizza place planet plastic plate play please pledge pluck plug plunge poem poet point polar pole police pond pony popular portion position possible post potato pottery poverty powder power practice praise predict prefer prepare present pretty prevent price pride primary print priority prison private prize problem process produce profit program project promote proof property prosper protect proud provide public pudding pull pulp pulse pumpkin punish pupil purchase purity purpose push put puzzle pyramid quality quantum quarter question quick quit quiz quote rabbit raccoon race rack radar radio rage rail rain raise rally ramp ranch random range rapid rare rate rather raven reach ready real reason rebel rebuild recall receive recipe record recycle reduce reflect reform refuse region regret regular reject relax release relief rely remain remember remind remove render renew rent reopen repair repeat replace report require rescue resemble resist resource response result retire retreat return reunion reveal review reward rhythm ribbon rice rich ride rifle right rigid ring riot ripple risk ritual rival river road roast robot robust rocket romance roof rookie rotate rough round route royal rubber rude rug rule run runway rural sad saddle sadness safe sail salad salmon salon salt salute same sample sand satisfy satoshi sauce sausage save say scale scan scare scatter scene scheme school science scissors scorpion scout scrap screen script scrub search season seat second secret section security seed seek segment select sell seminar senior sense sentence series service session settle setup seven shadow shaft shallow share shed shell sheriff shield shift shine ship shiver shock shoe shoot shop short shoulder shove shrimp shrug shuffle shy sibling siege sight sign silent silk silly silver similar simple since sing siren sister situate six size sketch skill skin skirt skull slab slam sleep slender slice slide slight slim slogan slot slow slush small smart smile smoke smooth snack snake snap sniff snow soap soccer social sock solar soldier solid solution solve someone song soon sorry soul sound soup source south space spare spatial spawn speak special speed sphere spice spider spike spin spirit split spoil sponsor spoon spray spread spring spy square squeeze squirrel stable stadium staff stage stairs stamp stand start state stay steak steel stem step stereo stick still sting stock stomach stone stop store storm story stove strategy street strike strong struggle student stuff stumble style subject submit subway success such sudden suffer sugar suggest suit summer sun sunny sunset super supply supreme sure surface surge surprise suspect sustain swallow swamp swap swear sweet swift swim swing switch sword symbol symptom syrup table tackle tag tail talent tamper tank tape target task tattoo taxi teach team tell ten tenant tennis tent term test text thank that theme then theory there they thing this thought three thrive throw thumb thunder ticket tilt timber time tiny tip tired title toast tobacco today together toilet token tomato tomorrow tone tongue tonight tool tooth top topic topple torch tornado tortoise toss total tourist toward tower town toy track trade traffic tragic train transfer trap trash travel tray treat tree trend trial tribe trick trigger trim trip trophy trouble truck truly trumpet trust truth tube tuition tumble tuna tunnel turkey turn turtle twelve twenty twice twin twist two type typical ugly umbrella unable unaware uncle uncover under undo unfair unfold unhappy uniform unique universe unknown unlock until unusual unveil update upgrade uphold upon upper upset urban used useful useless usual utility vacant vacuum vague valid valley valve van vanish vapor various vast vault vehicle velvet vendor venture venue verb verify version very veteran viable vibrant vicious victory video view village vintage violin virtual virus visa visit visual vital vivid vocal voice void volcano volume vote voyage wage wagon wait walk wall walnut want warfare warm warrior waste water wave way wealth weapon wear weasel wedding weekend weird welcome well west wet whale wheat wheel when where whip whisper wide width wife wild will win window wine wing wink winner winter wire wisdom wise wish witness wolf woman wonder wood wool word world worry worth wrap wreck wrestle wrist write wrong yard year yellow you young youth zebra zero zone zoo';
        $w = explode(' ', $raw);
        return $w;
    }
}
