<?php
declare(strict_types=1);
/**
 * PayGate.php — PayGate.to Crypto Payment Processor API client
 *
 * API base: https://api.paygate.to
 * Auth:     None required — no API key, no KYC, no sign-up.
 *
 * How it works:
 *   1. Admin sets a merchant wallet address per blockchain network in Admin → PayGate.
 *   2. When a user creates a deposit, call createWallet() to obtain a unique receiving address.
 *   3. Show the user the receiving address + crypto amount (from convertToCrypto()).
 *   4. PayGate monitors the address. When funds arrive, it auto-forwards them to the
 *      merchant wallet and sends a GET callback to pg_callback.php, which credits the user.
 *
 * Public surface:
 *   PayGate::getCoins()                    → keyed list of supported coins
 *   PayGate::getCoin(symbol)               → single coin definition or null
 *   PayGate::createWallet(symbol, cb_url)  → unique receiving address for the user
 *   PayGate::convertToCrypto(symbol, usd)  → crypto amount for a USD value
 */
class PayGate
{
    const API_BASE = 'https://api.paygate.to';

    /**
     * Supported coins.
     *
     * Each entry:
     *   symbol        Display/DB key used throughout the app
     *   name          Human-readable name
     *   path          PayGate API path for wallet creation (relative to API_BASE)
     *   convert_path  PayGate API path for fiat→crypto conversion
     *   wallet_key    DB settings key for the merchant's destination wallet address
     *   network_label Human-readable network label shown in UI
     */
    const COINS = [
        'BTC'        => [
            'name'          => 'Bitcoin',
            'path'          => '/crypto/btc/wallet.php',
            'convert_path'  => '/crypto/btc/convert.php',
            'wallet_key'    => 'pg_wallet_btc',
            'network_label' => 'Bitcoin',
        ],
        'ETH'        => [
            'name'          => 'Ethereum',
            'path'          => '/crypto/erc20/eth/wallet.php',
            'convert_path'  => '/crypto/erc20/eth/convert.php',
            'wallet_key'    => 'pg_wallet_eth',
            'network_label' => 'ERC20',
        ],
        'USDT-ERC20' => [
            'name'          => 'USDT (ERC20)',
            'path'          => '/crypto/erc20/usdt/wallet.php',
            'convert_path'  => '/crypto/erc20/usdt/convert.php',
            'wallet_key'    => 'pg_wallet_eth',
            'network_label' => 'ERC20',
        ],
        'USDT-TRC20' => [
            'name'          => 'USDT (TRC20)',
            'path'          => '/crypto/trc20/usdt/wallet.php',
            'convert_path'  => '/crypto/trc20/usdt/convert.php',
            'wallet_key'    => 'pg_wallet_trc20',
            'network_label' => 'TRC20',
        ],
        'USDC'       => [
            'name'          => 'USD Coin (ERC20)',
            'path'          => '/crypto/erc20/usdc/wallet.php',
            'convert_path'  => '/crypto/erc20/usdc/convert.php',
            'wallet_key'    => 'pg_wallet_eth',
            'network_label' => 'ERC20',
        ],
        'LTC'        => [
            'name'          => 'Litecoin',
            'path'          => '/crypto/ltc/wallet.php',
            'convert_path'  => '/crypto/ltc/convert.php',
            'wallet_key'    => 'pg_wallet_ltc',
            'network_label' => 'Litecoin',
        ],
        'DOGE'       => [
            'name'          => 'Dogecoin',
            'path'          => '/crypto/doge/wallet.php',
            'convert_path'  => '/crypto/doge/convert.php',
            'wallet_key'    => 'pg_wallet_doge',
            'network_label' => 'Dogecoin',
        ],
        'XRP'        => [
            'name'          => 'XRP',
            'path'          => '/crypto/xrp/wallet.php',
            'convert_path'  => '/crypto/xrp/convert.php',
            'wallet_key'    => 'pg_wallet_xrp',
            'network_label' => 'XRP Ledger',
        ],
        'SOL'        => [
            'name'          => 'Solana',
            'path'          => '/crypto/solana/sol/wallet.php',
            'convert_path'  => '/crypto/solana/sol/convert.php',
            'wallet_key'    => 'pg_wallet_sol',
            'network_label' => 'Solana',
        ],
        'BNB'        => [
            'name'          => 'BNB (BSC)',
            'path'          => '/crypto/bsc/bnb/wallet.php',
            'convert_path'  => '/crypto/bsc/bnb/convert.php',
            'wallet_key'    => 'pg_wallet_eth',
            'network_label' => 'BSC',
        ],
    ];

    // ── Coin helpers ──────────────────────────────────────────────────────────

    /** Return all supported coins. */
    public static function getCoins(): array
    {
        return self::COINS;
    }

    /** Return a single coin definition or null if not found. */
    public static function getCoin(string $symbol): ?array
    {
        return self::COINS[$symbol] ?? null;
    }

    /**
     * Return only coins that have a merchant wallet address configured in settings.
     * Used to show/hide coins in the deposit UI.
     */
    public static function getEnabledCoins(): array
    {
        $enabled = [];
        foreach (self::COINS as $symbol => $coin) {
            $addr = get_setting($coin['wallet_key'], '');
            if ($addr !== '') {
                $enabled[$symbol] = $coin;
            }
        }
        return $enabled;
    }

    // ── Wallet creation ───────────────────────────────────────────────────────

    /**
     * Create a unique receiving wallet address for a deposit.
     *
     * PayGate generates a unique address for each (merchant_address, callback_url) pair.
     * Any amount above the coin minimum sent to this address is instantly forwarded to
     * the merchant wallet. PayGate then GET-requests the callback URL with payment details.
     *
     * @param string $symbol        Coin symbol key (e.g. 'BTC', 'USDT-TRC20')
     * @param string $callback_url  Fully-qualified URL PayGate will call on payment receipt.
     *                              Must include at least one unique GET parameter per deposit.
     *
     * @return array {
     *   ok:          bool,
     *   address_in:  string,       // Unique deposit address to show the user
     *   ipn_token:   string,       // PayGate IPN token (for support/tracking)
     *   error:       string        // present only on failure
     * }
     */
    public static function createWallet(string $symbol, string $callback_url): array
    {
        $coin = self::getCoin($symbol);
        if ($coin === null) {
            return ['ok' => false, 'error' => 'Unsupported coin: ' . $symbol];
        }

        $merchant_address = get_setting($coin['wallet_key'], '');
        if ($merchant_address === '') {
            return [
                'ok'    => false,
                'error' => 'No merchant wallet configured for ' . $symbol
                         . ' (' . $coin['network_label'] . '). '
                         . 'Admin must add a ' . $coin['network_label'] . ' wallet address in Admin → PayGate.',
            ];
        }

        $url = self::API_BASE . $coin['path'] . '?' . http_build_query([
            'address'  => $merchant_address,
            'callback' => $callback_url,
        ]);

        $result = self::httpGet($url);
        if (!$result['ok']) {
            return $result;
        }

        $data       = $result['data'];
        $address_in = (string)($data['address_in'] ?? '');

        if ($address_in === '') {
            error_log('[PayGate::createWallet] No address_in for ' . $symbol . ': ' . json_encode(array_slice($data, 0, 5)));
            return ['ok' => false, 'error' => 'PayGate did not return a deposit address. Response: ' . json_encode(array_slice($data, 0, 3))];
        }

        return [
            'ok'         => true,
            'address_in' => $address_in,
            'ipn_token'  => (string)($data['ipn_token'] ?? ''),
        ];
    }

    // ── Fiat → Crypto conversion ──────────────────────────────────────────────

    /**
     * Convert a USD amount to the equivalent crypto amount.
     * Non-fatal: if the API fails, returns null for amount_crypto.
     *
     * @param string $symbol   Coin symbol key (e.g. 'BTC')
     * @param float  $usd      USD amount to convert
     *
     * @return array { ok: true, amount_crypto: string|null }
     */
    public static function convertToCrypto(string $symbol, float $usd): array
    {
        $coin = self::getCoin($symbol);
        if ($coin === null) {
            return ['ok' => true, 'amount_crypto' => null];
        }

        $url = self::API_BASE . $coin['convert_path'] . '?' . http_build_query([
            'from'  => 'USD',
            'value' => number_format($usd, 2, '.', ''),
        ]);

        $result = self::httpGet($url);
        if (!$result['ok']) {
            error_log('[PayGate::convertToCrypto] Conversion failed for ' . $symbol . ': ' . ($result['error'] ?? ''));
            return ['ok' => true, 'amount_crypto' => null];
        }

        $data = $result['data'];
        // PayGate returns value_coin (or sometimes coin_value / amount)
        $amount = $data['value_coin'] ?? ($data['coin_value'] ?? ($data['amount'] ?? null));
        return ['ok' => true, 'amount_crypto' => $amount !== null ? (string)$amount : null];
    }

    // ── Internal HTTP helper ──────────────────────────────────────────────────

    /**
     * Make a GET request and return decoded JSON.
     *
     * @return array { ok: bool, data: array, error: string }
     */
    private static function httpGet(string $url): array
    {
        if (!function_exists('curl_init')) {
            return ['ok' => false, 'error' => 'cURL is not available on this server'];
        }

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_USERAGENT      => 'BytePool-PayGate/1.0',
            CURLOPT_FOLLOWLOCATION => true,
        ]);

        $raw      = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_err  = curl_error($ch);
        curl_close($ch);

        if ($raw === false) {
            error_log('[PayGate] cURL error for ' . $url . ': ' . $curl_err);
            return ['ok' => false, 'error' => 'Network error: ' . $curl_err];
        }

        $decoded = json_decode((string)$raw, true);
        if (!is_array($decoded)) {
            error_log('[PayGate] Non-JSON response (HTTP ' . $http_code . ') for ' . $url . ': ' . substr($raw, 0, 300));
            return ['ok' => false, 'error' => 'Non-JSON response from PayGate (HTTP ' . $http_code . ')'];
        }

        if ($http_code < 200 || $http_code >= 300) {
            $err = $decoded['error'] ?? ($decoded['message'] ?? ('HTTP ' . $http_code));
            error_log('[PayGate] API error ' . $http_code . ' for ' . $url . ': ' . json_encode($decoded));
            return ['ok' => false, 'error' => $err, 'data' => $decoded];
        }

        return ['ok' => true, 'data' => $decoded];
    }
}
