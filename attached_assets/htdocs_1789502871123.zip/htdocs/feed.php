<?php
declare(strict_types=1);

// Lightweight JSON activity feed endpoint
// Called by admin live-feed tab every 3 seconds via fetch()

define('ROOT_DIR', __DIR__);
require_once ROOT_DIR . '/src/bootstrap.php';

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');

// Must be admin
if (!is_logged_in() || current_user()['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

$pdo = db();
$since = max(0, (int)($_GET['since'] ?? 0));
$now   = time();

$events = [];

// ── New orders ───────────────────────────────────────────────
$stmt = $pdo->prepare("
    SELECT o.id, o.price, o.purchased_at,
           u.username AS buyer, s.username AS seller,
           c.brand, c.number
    FROM orders o
    JOIN users u ON u.id=o.user_id
    JOIN users s ON s.id=o.seller_id
    JOIN cards c  ON c.id=o.card_id
    WHERE o.purchased_at > ?
    ORDER BY o.purchased_at DESC
    LIMIT 30
");
$stmt->execute([$since]);
foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $events[] = [
        'type'  => 'order',
        'ts'    => (int)$r['purchased_at'],
        'id'    => (int)$r['id'],
        'label' => sprintf('%s bought %s••••%s (%s) for $%.2f from %s',
            $r['buyer'],
            substr($r['number'], 0, 6),
            substr($r['number'], -4),
            $r['brand'],
            (float)$r['price'],
            $r['seller']
        ),
    ];
}

// ── New deposits ─────────────────────────────────────────────
$stmt = $pdo->prepare("
    SELECT d.id, d.amount, d.method, d.status, d.created_at, u.username
    FROM deposits d JOIN users u ON u.id=d.user_id
    WHERE d.created_at > ?
    ORDER BY d.created_at DESC LIMIT 20
");
$stmt->execute([$since]);
foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $events[] = [
        'type'  => 'deposit',
        'ts'    => (int)$r['created_at'],
        'id'    => (int)$r['id'],
        'label' => sprintf('%s submitted %s deposit of $%.2f [%s]',
            $r['username'], $r['method'], (float)$r['amount'], $r['status']
        ),
    ];
}

// ── New registrations ────────────────────────────────────────
$stmt = $pdo->prepare("
    SELECT id, username, role, created_at
    FROM users WHERE created_at > ?
    ORDER BY created_at DESC LIMIT 20
");
$stmt->execute([$since]);
foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $events[] = [
        'type'  => 'register',
        'ts'    => (int)$r['created_at'],
        'id'    => (int)$r['id'],
        'label' => sprintf('New %s registered: %s', $r['role'], $r['username']),
    ];
}

// ── Refunds ──────────────────────────────────────────────────
$stmt = $pdo->prepare("
    SELECT o.id, o.price, o.purchased_at, u.username AS buyer, c.brand
    FROM orders o JOIN users u ON u.id=o.user_id JOIN cards c ON c.id=o.card_id
    WHERE o.status='refunded' AND o.purchased_at > ?
    ORDER BY o.purchased_at DESC LIMIT 10
");
$stmt->execute([$since]);
foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $events[] = [
        'type'  => 'refund',
        'ts'    => (int)$r['purchased_at'],
        'id'    => (int)$r['id'],
        'label' => sprintf('%s requested refund on order #%d (%s) — $%.2f',
            $r['buyer'], $r['id'], $r['brand'], (float)$r['price']
        ),
    ];
}

// ── Aggregate stats snapshot ─────────────────────────────────
$stats = [
    'users'         => (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(),
    'avail_cards'   => (int)$pdo->query("SELECT COUNT(*) FROM cards WHERE status='available'")->fetchColumn(),
    'orders_today'  => (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE purchased_at>" . (strtotime('today')))->fetchColumn(),
    'revenue_today' => (float)$pdo->query("SELECT COALESCE(SUM(price),0) FROM orders WHERE purchased_at>" . (strtotime('today')))->fetchColumn(),
    'pending_deps'  => (int)$pdo->query("SELECT COUNT(*) FROM deposits WHERE status='pending'")->fetchColumn(),
    'open_tickets'  => (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status='open'")->fetchColumn(),
    'cart_reserved' => (int)$pdo->query("SELECT COUNT(*) FROM cart_items WHERE reserved_until>" . time())->fetchColumn(),
];

// Sort events newest first
usort($events, fn($a, $b) => $b['ts'] - $a['ts']);

echo json_encode([
    'ok'     => true,
    'now'    => $now,
    'events' => $events,
    'stats'  => $stats,
], JSON_UNESCAPED_UNICODE);
