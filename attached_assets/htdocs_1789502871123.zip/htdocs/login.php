<?php
declare(strict_types=1);

function page_login(): string {
    // Handle logout
    if (get('action') === 'logout') {
        do_logout();
        header('Location: /?p=login');
        exit;
    }

    // If already logged in, go home
    if (is_logged_in()) {
        header('Location: /?p=marketplace');
        exit;
    }

    $error = '';
    $tab   = 'login';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = post('action', 'login');

        if ($action === 'login') {
            $username = post('username');
            $password = post('password');
            if (do_login($username, $password)) {
                header('Location: /?p=marketplace');
                exit;
            }
            $error = 'Invalid username or password.';
        } elseif ($action === 'register') {
            $tab = 'register';
            $username = post('username');
            $password = post('password');
            $telegram_username = post('telegram_username');
            $result   = do_register($username, $password, $telegram_username);
            if ($result['ok']) {
                do_login($username, $password);
                header('Location: /?p=marketplace');
                exit;
            }
            $error = $result['msg'];
        }
    }

    ob_start(); ?>
<div class="login-shell">
  <div class="login-box">
    <div class="login-logo">
      <div class="hero">BYTEPOOL</div>
      <div class="sub">Crypto Mining Pool</div>
    </div>

    <?php if ($error): ?>
      <div class="alert alert-error"><?= h($error) ?></div>
    <?php endif; ?>

    <div class="login-tabs">
      <button class="login-tab <?= $tab==='login'?'active':'' ?>" data-tab="login">Sign In</button>
      <button class="login-tab <?= $tab==='register'?'active':'' ?>" data-tab="register">Register</button>
    </div>

    <!-- LOGIN FORM -->
    <div class="login-form-wrap">
      <form class="login-form" data-form="login" method="POST" style="<?= $tab!=='login'?'display:none':'' ?>">
        <input type="hidden" name="action" value="login">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input class="form-input" name="username" placeholder="username" autocomplete="username" required>
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input class="form-input" type="password" name="password" placeholder="••••••••" autocomplete="current-password" required>
        </div>
        <button class="btn btn-primary w-full mt-8" style="width:100%;justify-content:center">Sign In</button>
      </form>

      <!-- REGISTER FORM -->
      <form class="login-form" data-form="register" method="POST" style="<?= $tab!=='register'?'display:none':'' ?>">
        <input type="hidden" name="action" value="register">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input class="form-input" name="username" placeholder="choose a username" required>
        </div>
        <div class="form-group">
          <label class="form-label">Telegram username (optional)</label>
          <input class="form-input" type="text" name="telegram_username" placeholder="@user" autocomplete="off">
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <input class="form-input" type="password" name="password" placeholder="min 6 characters" required>
        </div>
        <button class="btn btn-primary w-full mt-8" style="width:100%;justify-content:center">Create Account</button>
        <p class="text-xs text-dim mt-8" style="text-align:center">No bond required. Instant activation.</p>
      </form>
    </div>
  </div>
</div>
<?php
    return ob_get_clean();
}
