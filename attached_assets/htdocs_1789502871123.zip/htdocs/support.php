<?php
declare(strict_types=1);

function page_support(): string {
    require_login();
    $uid = (int)$_SESSION['user_id'];
    $pdo = db();

    $selected_ticket_id = (int)get('ticket', 0);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $act = post('action');

        if ($act === 'new_ticket') {
            $subject = trim(post('subject'));
            $body    = trim(post('body'));
            if ($subject && $body) {
                $pdo->prepare('INSERT INTO tickets (user_id,subject) VALUES (?,?)')->execute([$uid, $subject]);
                $tid = (int)$pdo->lastInsertId();
                $pdo->prepare('INSERT INTO ticket_messages (ticket_id,sender_id,body) VALUES (?,?,?)')->execute([$tid, $uid, $body]);
                // Auto-reply
                $pdo->prepare('INSERT INTO ticket_messages (ticket_id,sender_id,body) VALUES (?,?,?)')->execute([$tid, 3, 'Thanks for contacting support. A team member will review your request shortly. Typical response time is 1–4 hours.']);
                flash('Support ticket created!', 'success');
                header('Location: /?p=support&ticket=' . $tid);
                exit;
            }
            flash('Please fill in all fields', 'error');
        }

        if ($act === 'reply' && $selected_ticket_id) {
            $body = trim(post('body'));
            if ($body) {
                $pdo->prepare('INSERT INTO ticket_messages (ticket_id,sender_id,body) VALUES (?,?,?)')->execute([$selected_ticket_id, $uid, $body]);
                // Auto-reply every other message
                if (rand(0,1)) {
                    $pdo->prepare('INSERT INTO ticket_messages (ticket_id,sender_id,body) VALUES (?,?,?)')->execute([$selected_ticket_id, 3, 'Thanks for the update. We are looking into this now.']);
                }
            }
            header('Location: /?p=support&ticket=' . $selected_ticket_id);
            exit;
        }

        if ($act === 'close' && $selected_ticket_id) {
            $pdo->prepare('UPDATE tickets SET status="closed" WHERE id=? AND user_id=?')->execute([$selected_ticket_id, $uid]);
            flash('Ticket closed', 'info');
            header('Location: /?p=support');
            exit;
        }
    }

    $tickets = $pdo->prepare('SELECT * FROM tickets WHERE user_id=? ORDER BY created_at DESC');
    $tickets->execute([$uid]);
    $tickets = $tickets->fetchAll();

    $selected_ticket  = null;
    $selected_msgs    = [];
    if ($selected_ticket_id) {
        $st = $pdo->prepare('SELECT * FROM tickets WHERE id=? AND user_id=?');
        $st->execute([$selected_ticket_id, $uid]);
        $selected_ticket = $st->fetch();
        if ($selected_ticket) {
            $sm = $pdo->prepare('SELECT tm.*,u.username FROM ticket_messages tm JOIN users u ON u.id=tm.sender_id WHERE tm.ticket_id=? ORDER BY tm.created_at');
            $sm->execute([$selected_ticket_id]);
            $selected_msgs = $sm->fetchAll();
        }
    }

    ob_start(); ?>
<div class="topbar">
  <h1 class="page-title">Support <span>Tickets</span></h1>
</div>

<div class="grid-2" style="align-items:start">
  <!-- Ticket list + new -->
  <div>
    <div class="card mb-16">
      <div class="section-title">New Ticket</div>
      <form method="POST">
        <input type="hidden" name="action" value="new_ticket">
        <div class="form-group">
          <label class="form-label">Subject</label>
          <select class="form-input" name="subject">
            <option>Card not working</option>
            <option>Refund request</option>
            <option>Payment issue</option>
            <option>Account problem</option>
            <option>General inquiry</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Message</label>
          <textarea class="form-input" name="body" rows="3" placeholder="Describe your issue..." required></textarea>
        </div>
        <button class="btn btn-primary" style="width:100%;justify-content:center">Submit Ticket</button>
      </form>
    </div>

    <?php if (empty($tickets)): ?>
      <div class="text-dim text-sm">No tickets yet.</div>
    <?php else: ?>
      <?php foreach ($tickets as $t): ?>
      <a href="/?p=support&ticket=<?= $t['id'] ?>" style="display:block">
        <div class="ticket-item <?= $selected_ticket_id===$t['id']?'border-color:var(--red)':'' ?>">
          <div style="flex:1;min-width:0">
            <div class="ticket-subject"><?= h($t['subject']) ?></div>
            <div class="ticket-info">#<?= $t['id'] ?> &middot; <?= date('M j, H:i', (int)$t['created_at']) ?></div>
          </div>
          <span class="badge <?= $t['status']==='open'?'badge-green':'badge-gray' ?>"><?= h($t['status']) ?></span>
        </div>
      </a>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- Chat view -->
  <div>
    <?php if ($selected_ticket): ?>
    <div class="card" style="padding:0;overflow:hidden">
      <div style="padding:14px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px">
        <div style="flex:1">
          <div class="fw-6"><?= h($selected_ticket['subject']) ?></div>
          <div class="text-dim text-xs">Ticket #<?= $selected_ticket['id'] ?></div>
        </div>
        <?php if ($selected_ticket['status'] === 'open'): ?>
        <form method="POST">
          <input type="hidden" name="action" value="close">
          <button class="btn btn-ghost btn-xs">Close Ticket</button>
        </form>
        <?php else: ?>
          <span class="badge badge-gray">Closed</span>
        <?php endif; ?>
      </div>

      <div class="chat-msgs" id="chat-msgs">
        <?php foreach ($selected_msgs as $msg):
          $is_me = (int)$msg['sender_id'] === $uid;
        ?>
        <div class="chat-bubble <?= $is_me?'me':'other' ?>">
          <?= h($msg['body']) ?>
          <div class="bubble-meta"><?= $is_me ? 'You' : h($msg['username']) ?> &middot; <?= date('M j H:i', (int)$msg['created_at']) ?></div>
        </div>
        <?php endforeach; ?>
      </div>

      <?php if ($selected_ticket['status'] === 'open'): ?>
      <form method="POST" class="chat-input-row">
        <input type="hidden" name="action" value="reply">
        <textarea class="form-input" name="body" rows="1" style="flex:1;resize:none" placeholder="Type a message..." required></textarea>
        <button class="btn btn-primary btn-sm">Send</button>
      </form>
      <?php endif; ?>
    </div>
    <?php else: ?>
    <div class="card empty-state">
      <h3>Select a ticket</h3>
      <p class="text-muted">Click a ticket to view the conversation, or create a new one.</p>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php
    return ob_get_clean();
}
