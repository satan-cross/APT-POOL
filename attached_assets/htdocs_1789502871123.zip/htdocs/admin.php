<?php
declare(strict_types=1);

function page_admin(): string {
    require_login();
    $user = current_user();
    if ($user['role'] !== 'admin') {
        header('Location: /?p=dashboard');
        exit;
    }

    $pdo = db();

    // ── GET: file downloads (must emit before any output) ────────────
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && get('action') === 'download_base') {
        $bid = (int)get('id');
        $row = $pdo->prepare('SELECT si.*, u.username FROM seller_inventory si JOIN users u ON u.id=si.seller_id WHERE si.id=?');
        $row->execute([$bid]);
        $row = $row->fetch();
        if ($row) {
            $fname = $row['filename'] ?: ('base_' . $bid . '_' . $row['username'] . '_' . date('Ymd', (int)$row['created_at']) . '.txt');
            header('Content-Type: text/plain; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . addslashes($fname) . '"');
            header('Content-Length: ' . strlen($row['raw_data']));
            echo $row['raw_data'];
            exit;
        }
        header('Location: /?p=admin&tab=bases');
        exit;
    }

    // ── POST actions ────────────────────────────────────────────────
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $act = post('action');

        // Confirm / reject deposit
        if ($act === 'confirm_deposit') {
            $did  = (int)post('deposit_id');
            $txid = trim(post('txid', ''));
            $dep  = $pdo->prepare('SELECT * FROM deposits WHERE id=?');
            $dep->execute([$did]);
            $dep = $dep->fetch();
            if ($dep && $dep['status'] === 'pending') {
                $now = time();
                $pdo->prepare(
                    "UPDATE deposits SET status='confirmed', txid=COALESCE(NULLIF(?,NULL), txid), confirmed_at=? WHERE id=?"
                )->execute([$txid !== '' ? $txid : null, $now, $did]);
                $pdo->prepare('UPDATE users SET balance=balance+? WHERE id=?')
                    ->execute([$dep['amount'], $dep['user_id']]);
                flash('Deposit #' . $did . ' confirmed — $' . number_format($dep['amount'], 2) . ' added to user balance.', 'success');
            }
        }

        if ($act === 'reject_deposit') {
            $did = (int)post('deposit_id');
            $pdo->prepare('UPDATE deposits SET status="rejected" WHERE id=?')->execute([$did]);
            flash('Deposit #' . $did . ' rejected.', 'info');
        }

        if ($act === 'withdraw_deposit') {
            $did = (int)post('deposit_id');
            $dep = $pdo->prepare('SELECT * FROM deposits WHERE id=?');
            $dep->execute([$did]);
            $dep = $dep->fetch();
            if ($dep && $dep['status'] === 'pending') {
                $method       = strtoupper((string)$dep['method']);
                $withdraw_addr = get_setting('withdraw_address_' . $method, '');
                $pdo->prepare("UPDATE deposits SET status='withdrawn', confirmed_at=?, admin_note=? WHERE id=?")
                    ->execute([time(), $withdraw_addr ?: null, $did]);
                $addr_msg = $withdraw_addr
                    ? ' Withdraw ' . $method . ' to: ' . $withdraw_addr
                    : ' (No withdraw address configured for ' . $method . ' — set one in Deposits → Withdraw Addresses.)';
                flash('Deposit #' . $did . ' marked as withdrawn.' . $addr_msg, 'info');
            }
        }

        if ($act === 'save_withdraw_addresses') {
            $methods = ['BTC','ETH','LTC','USDT','USDC','BNB','DOGE','SOL','TRX','DASH','BCH','XRP','MATIC','ADA'];
            foreach ($methods as $m) {
                $addr = trim(post('withdraw_addr_' . $m, ''));
                set_setting('withdraw_address_' . $m, $addr);
            }
            flash('Withdraw addresses saved.', 'success');
        }

        // Force-refresh the CoinPayments currency list from live API
        if ($act === 'refresh_currencies') {
            $result = CoinPayments::refreshCurrencies();
            if ($result !== false) {
                flash('Currency list refreshed — ' . count($result) . ' coins cached.', 'success');
            } else {
                flash('Currency refresh failed. Check error log.', 'error');
            }
        }

        // Seed testnet deposits for all supported crypto methods
        if ($act === 'seed_test_deposits') {
            $uid = (int)($pdo->query("SELECT id FROM users WHERE role='buyer' ORDER BY id ASC LIMIT 1")->fetchColumn() ?: 1);
            $tests = [
                ['BTC',   50.00,  'tb1qw508d6qejxtdg4y5r3zarvary0c5xw7kxpjzsx'],
                ['ETH',   75.00,  '0xde0B295669a9FD93d5F28D9Ec85E40f4cb697BAe'],
                ['LTC',   30.00,  'mwCwTceJvYV27KXBc3NJZys6CjsgsoeHmf'],
                ['USDT',  100.00, '0x71C7656EC7ab88b098defB751B7401B5f6d8976F'],
                ['DOGE',  40.00,  'D7Y55MBqFnz9pWXMhbh4fEzAHDyiGGjxsU'],
            ];
            $stmt = $pdo->prepare("INSERT INTO deposits (user_id,method,amount,deposit_address,status) VALUES (?,?,?,?,'pending')");
            foreach ($tests as [$method, $amount, $addr]) {
                $stmt->execute([$uid, $method, $amount, $addr]);
            }
            flash('5 testnet deposits seeded. Use manual confirm below.', 'info');
        }

        // User role management
        if ($act === 'set_role') {
            $uid  = (int)post('target_uid');
            $role = post('role');
            if (in_array($role, ['buyer','seller','admin']) && $uid !== (int)$user['id']) {
                $pdo->prepare('UPDATE users SET role=? WHERE id=?')->execute([$role, $uid]);
                flash('User role updated.', 'success');
            }
        }

        // Ban / unban user
        if ($act === 'ban_user') {
            $uid = (int)post('target_uid');
            if ($uid !== (int)$user['id']) {
                $pdo->prepare('UPDATE users SET role="banned" WHERE id=?')->execute([$uid]);
                flash('User banned.', 'info');
            }
        }

        if ($act === 'unban_user') {
            $uid = (int)post('target_uid');
            $pdo->prepare('UPDATE users SET role="buyer" WHERE id=?')->execute([$uid]);
            flash('User unbanned (restored to buyer).', 'success');
        }

        // Delete card
        if ($act === 'delete_card') {
            $cid = (int)post('card_id');
            $pdo->prepare('UPDATE cards SET status="deleted" WHERE id=?')->execute([$cid]);
            flash('Card removed from marketplace.', 'info');
        }

        // Close ticket
        if ($act === 'close_ticket') {
            $tid = (int)post('ticket_id');
            $pdo->prepare('UPDATE tickets SET status="closed" WHERE id=?')->execute([$tid]);
            flash('Ticket closed.', 'info');
        }

        // Admin ticket reply
        if ($act === 'admin_reply') {
            $tid  = (int)post('ticket_id');
            $body = trim(post('body'));
            if ($body) {
                $pdo->prepare('INSERT INTO ticket_messages (ticket_id,sender_id,body) VALUES (?,?,?)')->execute([$tid, $user['id'], $body]);
            }
        }

        // Approve withdrawal — mark as processing/completed
        if ($act === 'approve_withdrawal') {
            $wid  = (int)post('withdrawal_id');
            $txid = trim(post('txid', ''));
            $mark = $txid ? 'completed' : 'processing';
            $wd   = $pdo->prepare('SELECT * FROM withdrawals WHERE id=? AND status IN ("pending","processing")');
            $wd->execute([$wid]);
            $wd   = $wd->fetch();
            if ($wd) {
                $pdo->prepare("UPDATE withdrawals SET status=?, txid=?, processed_at=? WHERE id=?")
                    ->execute([$mark, $txid ?: null, time(), $wid]);
                flash("Withdrawal #{$wid} marked as {$mark}" . ($txid ? " (TXID saved)" : " — add TXID when sent") . ".", 'success');
            }
        }

        // Reject withdrawal — restore balance
        if ($act === 'reject_withdrawal') {
            $wid  = (int)post('withdrawal_id');
            $note = trim(post('admin_note', ''));
            $wd   = $pdo->prepare("SELECT * FROM withdrawals WHERE id=? AND status IN ('pending','processing')");
            $wd->execute([$wid]);
            $wd   = $wd->fetch();
            if ($wd) {
                $pdo->beginTransaction();
                $pdo->prepare("UPDATE withdrawals SET status='rejected', admin_note=?, processed_at=? WHERE id=?")
                    ->execute([$note ?: null, time(), $wid]);
                $pdo->prepare('UPDATE users SET balance = balance + ? WHERE id = ?')
                    ->execute([$wd['amount'], $wd['user_id']]);
                $pdo->commit();
                flash("Withdrawal #{$wid} rejected — \${$wd['amount']} returned to user balance.", 'info');
            }
        }

        // Update withdrawal TXID
        if ($act === 'update_withdrawal_txid') {
            $wid  = (int)post('withdrawal_id');
            $txid = trim(post('txid', ''));
            if ($txid) {
                $pdo->prepare("UPDATE withdrawals SET txid=?, status='completed', processed_at=? WHERE id=?")
                    ->execute([$txid, time(), $wid]);
                flash("TXID saved — withdrawal #{$wid} marked completed.", 'success');
            }
        }

        // Update withdrawal fee / min settings
        if ($act === 'save_withdrawal_settings') {
            $fee = max(0, min(20, (float)post('fee_pct', 0)));
            $min = max(1, (float)post('min_amount', 10));
            set_setting('withdrawal_fee_pct', (string)$fee);
            set_setting('withdrawal_min',     (string)$min);
            flash('Withdrawal settings saved.', 'success');
        }

        // Reset HD derivation index
        if ($act === 'reset_derive_index') {
            $idx = max(0, (int)post('derive_index', 0));
            set_setting('next_derive_index', (string)$idx);
            flash('Derivation index set to ' . $idx . '.', 'success');
        }

        // (xpub wallet settings removed — deposits now use CoinPayments API)

        // Regenerate cron secret
        if ($act === 'regen_cron_secret') {
            set_setting('cron_secret', bin2hex(random_bytes(24)));
            flash('Cron token regenerated. Update your cron job URL.', 'success');
        }

        // Regenerate sync secret
        if ($act === 'regen_sync_secret') {
            set_setting('sync_secret', bin2hex(random_bytes(24)));
            flash('Sync token regenerated. Update any scripts using the old URL.', 'success');
        }

        // Delete a base record (cards already imported are kept)
        if ($act === 'delete_base') {
            $bid = (int)post('base_id');
            $pdo->prepare('DELETE FROM seller_inventory WHERE id=?')->execute([$bid]);
            flash('Base record #' . $bid . ' deleted. Imported cards remain.', 'info');
        }

        // Shop open/closed toggle
        if ($act === 'toggle_shop') {
            $new = shop_is_open() ? '0' : '1';
            set_setting('shop_open', $new);
            $reason = trim(post('reason', ''));
            if ($reason) set_setting('shop_closed_reason', $reason);
            flash('Shop is now ' . ($new === '1' ? 'OPEN' : 'CLOSED') . '.', $new === '1' ? 'success' : 'info');
        }

        // Manual balance adjustment
        if ($act === 'adjust_balance') {
            $uid    = (int)post('target_uid');
            $amount = (float)post('amount');
            if ($amount != 0) {
                $pdo->prepare('UPDATE users SET balance=balance+? WHERE id=?')->execute([$amount, $uid]);
                $label = $amount > 0 ? '+$' . number_format($amount, 2) : '-$' . number_format(abs($amount), 2);
                flash('Balance adjusted by ' . $label . ' for user #' . $uid, 'success');
            }
        }

        // (HD wallet generation removed — deposits now use CoinPayments API)

        header('Location: /?p=admin&tab=' . h(get('tab', 'overview')));
        exit;
    }

    $tab = get('tab', 'overview');

    // ── Analytics ───────────────────────────────────────────────────
    $total_users    = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    $total_sellers  = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='seller'")->fetchColumn();
    $total_cards    = (int)$pdo->query("SELECT COUNT(*) FROM cards WHERE status != 'deleted'")->fetchColumn();
    $avail_cards    = (int)$pdo->query("SELECT COUNT(*) FROM cards WHERE status='available'")->fetchColumn();
    $sold_cards     = (int)$pdo->query("SELECT COUNT(*) FROM cards WHERE status='sold'")->fetchColumn();
    $total_orders   = (int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn();
    $total_revenue  = (float)$pdo->query('SELECT COALESCE(SUM(price),0) FROM orders')->fetchColumn();
    $platform_cut   = $total_revenue * 0.10;
    $pending_deps   = (int)$pdo->query("SELECT COUNT(*) FROM deposits WHERE status='pending'")->fetchColumn();
    $open_tickets   = (int)$pdo->query("SELECT COUNT(*) FROM tickets WHERE status='open'")->fetchColumn();
    $pending_wds    = (int)$pdo->query("SELECT COUNT(*) FROM withdrawals WHERE status IN ('pending','processing')")->fetchColumn();
    $total_bases    = (int)$pdo->query("SELECT COUNT(*) FROM seller_inventory")->fetchColumn();

    // All bases (seller inventory uploads)
    $all_bases = $pdo->query("
        SELECT si.*, u.username
        FROM seller_inventory si
        JOIN users u ON u.id = si.seller_id
        ORDER BY si.created_at DESC
        LIMIT 200
    ")->fetchAll();

    // Sales last 7 days
    $sales_7d = $pdo->query("
        SELECT date(purchased_at,'unixepoch') AS day, COUNT(*) AS cnt, SUM(price) AS revenue
        FROM orders WHERE purchased_at > " . (time() - 7 * 86400) . "
        GROUP BY day ORDER BY day ASC
    ")->fetchAll();

    // Top sellers
    $top_sellers = $pdo->query("
        SELECT u.username, COUNT(o.id) AS sold, SUM(o.price) AS revenue
        FROM orders o JOIN users u ON u.id=o.seller_id
        GROUP BY o.seller_id ORDER BY sold DESC LIMIT 5
    ")->fetchAll();

    // Recent orders
    $recent_orders = $pdo->query("
        SELECT o.*,u.username AS buyer,s.username AS seller,c.brand,c.number
        FROM orders o
        JOIN users u ON u.id=o.user_id
        JOIN users s ON s.id=o.seller_id
        JOIN cards c ON c.id=o.card_id
        ORDER BY o.purchased_at DESC LIMIT 20
    ")->fetchAll();

    // Pending deposits
    $pending_deposits = $pdo->query("
        SELECT d.*,u.username FROM deposits d JOIN users u ON u.id=d.user_id
        WHERE d.status='pending' ORDER BY d.created_at DESC
    ")->fetchAll();

    // All deposits
    $all_deposits = $pdo->query("
        SELECT d.*,u.username FROM deposits d JOIN users u ON u.id=d.user_id
        ORDER BY d.created_at DESC LIMIT 50
    ")->fetchAll();

    // All users
    $all_users = $pdo->query("
        SELECT u.*,
            (SELECT COUNT(*) FROM orders WHERE user_id=u.id) AS order_count,
            (SELECT COUNT(*) FROM cards WHERE seller_id=u.id AND status != 'deleted') AS card_count
        FROM users u ORDER BY u.created_at DESC
    ")->fetchAll();

    // Open tickets
    $tickets = $pdo->query("
        SELECT t.*,u.username FROM tickets t JOIN users u ON u.id=t.user_id
        ORDER BY t.created_at DESC LIMIT 50
    ")->fetchAll();

    // Card inventory
    $cards_all = $pdo->query("
        SELECT c.*,u.username AS seller_name FROM cards c JOIN users u ON u.id=c.seller_id
        WHERE c.status != 'deleted' ORDER BY c.created_at DESC LIMIT 100
    ")->fetchAll();

    // All withdrawals
    $all_withdrawals = $pdo->query("
        SELECT w.*, u.username, u.balance AS user_balance
        FROM withdrawals w JOIN users u ON u.id=w.user_id
        ORDER BY CASE w.status WHEN 'pending' THEN 0 WHEN 'processing' THEN 1 ELSE 2 END, w.created_at DESC
        LIMIT 100
    ")->fetchAll();

    $selected_ticket_id = (int)get('ticket', 0);
    $selected_ticket = null;
    $ticket_msgs = [];
    if ($selected_ticket_id) {
        $st = $pdo->prepare('SELECT t.*,u.username FROM tickets t JOIN users u ON u.id=t.user_id WHERE t.id=?');
        $st->execute([$selected_ticket_id]);
        $selected_ticket = $st->fetch();
        if ($selected_ticket) {
            $sm = $pdo->prepare('SELECT tm.*,u.username FROM ticket_messages tm JOIN users u ON u.id=tm.sender_id WHERE tm.ticket_id=? ORDER BY tm.created_at');
            $sm->execute([$selected_ticket_id]);
            $ticket_msgs = $sm->fetchAll();
        }
    }

    ob_start(); ?>
<div class="topbar">
  <h1 class="page-title">Admin <span>Panel</span></h1>
  <span class="badge badge-red"><span class="dot dot-red"></span> Admin Access</span>
</div>

<!-- Tab Nav -->
<div style="display:flex;gap:4px;margin-bottom:24px;background:var(--bg-surface);border:1px solid var(--border);border-radius:var(--r-md);padding:4px;flex-wrap:wrap">
  <?php
  $tabs = [
    'overview'  => 'Overview',
    'feed'      => '⚡ Live Feed',
    'deposits'  => 'Deposits' . ($pending_deps ? ' (' . $pending_deps . ')' : ''),
    'bases'     => 'Bases' . ($total_bases ? ' (' . $total_bases . ')' : ''),
    'users'     => 'Users',
    'cards'     => 'Cards',
    'orders'    => 'Orders',
    'tickets'     => 'Support' . ($open_tickets ? ' (' . $open_tickets . ')' : ''),
    'withdrawals' => 'Withdrawals' . ($pending_wds ? ' (' . $pending_wds . ')' : ''),
    'coinpayments' => '⚡ CoinPayments',
  ];
  foreach ($tabs as $key => $label):
    $active = $tab === $key;
  ?>
  <a href="/?p=admin&tab=<?= $key ?>" class="btn <?= $active ? 'btn-primary' : 'btn-ghost' ?> btn-sm" style="border-radius:6px"><?= h($label) ?></a>
  <?php endforeach; ?>
</div>

<!-- ═══════════════ OVERVIEW ═══════════════ -->
<?php if ($tab === 'overview'):
  $shop_open   = shop_is_open();
  $shop_reason = get_setting('shop_closed_reason', '');
?>

<!-- Shop Status Banner -->
<div style="display:flex;align-items:center;gap:16px;padding:14px 18px;border-radius:var(--r-md);border:1px solid <?= $shop_open ? 'rgba(34,197,94,.3)' : 'rgba(219,20,60,.4)' ?>;background:<?= $shop_open ? 'rgba(34,197,94,.06)' : 'rgba(219,20,60,.08)' ?>;margin-bottom:20px;flex-wrap:wrap;gap:12px">
  <div class="flex items-center gap-8 flex-1">
    <span class="dot <?= $shop_open ? 'dot-green' : 'dot-red' ?>" style="<?= $shop_open ? '' : 'animation:pulse 1s infinite' ?>"></span>
    <span class="fw-7" style="font-size:14px;color:<?= $shop_open ? 'var(--green)' : 'var(--red)' ?>">Shop is <?= $shop_open ? 'OPEN' : 'CLOSED' ?></span>
    <?php if (!$shop_open && $shop_reason): ?>
      <span class="text-dim text-xs">— <?= h($shop_reason) ?></span>
    <?php endif; ?>
  </div>
  <form method="POST" class="flex items-center gap-8">
    <input type="hidden" name="action" value="toggle_shop">
    <input type="hidden" name="tab" value="overview">
    <?php if ($shop_open): ?>
      <input class="form-input" name="reason" placeholder="Reason for closing (optional)" style="width:240px;padding:6px 10px;font-size:12px">
      <button class="btn btn-danger btn-sm" onclick="return confirm('Close the shop? Buyers cannot purchase or deposit until you reopen.')">
        🔒 Close Shop
      </button>
    <?php else: ?>
      <button class="btn btn-primary btn-sm">
        🔓 Reopen Shop
      </button>
    <?php endif; ?>
  </form>
</div>

<div class="stat-grid" style="grid-template-columns:repeat(auto-fill,minmax(140px,1fr))">
  <div class="stat-card"><div class="stat-label">Users</div><div class="stat-value"><?= $total_users ?></div><div class="stat-sub"><?= $total_sellers ?> sellers</div></div>
  <div class="stat-card"><div class="stat-label">Cards Listed</div><div class="stat-value"><?= $avail_cards ?></div><div class="stat-sub"><?= $sold_cards ?> sold</div></div>
  <div class="stat-card"><div class="stat-label">Total Orders</div><div class="stat-value"><?= $total_orders ?></div></div>
  <div class="stat-card"><div class="stat-label">GMV</div><div class="stat-value red">$<?= number_format($total_revenue, 2) ?></div><div class="stat-sub">Gross</div></div>
  <div class="stat-card"><div class="stat-label">Platform Rev</div><div class="stat-value green">$<?= number_format($platform_cut, 2) ?></div><div class="stat-sub">10% cut</div></div>
  <div class="stat-card"><div class="stat-label">Pending Deps</div><div class="stat-value <?= $pending_deps > 0 ? 'red' : '' ?>"><?= $pending_deps ?></div><div class="stat-sub"><a href="/?p=admin&tab=deposits" class="text-red">Review</a></div></div>
  <div class="stat-card"><div class="stat-label">Open Tickets</div><div class="stat-value <?= $open_tickets > 0 ? 'amber' : '' ?>"><?= $open_tickets ?></div><div class="stat-sub"><a href="/?p=admin&tab=tickets" class="text-red">View</a></div></div>
</div>

<!-- 7-day chart -->
<div class="card mt-16">
  <div class="section-title">Sales — Last 7 Days</div>
  <?php if (empty($sales_7d)): ?>
    <div class="text-dim text-sm">No sales in the last 7 days.</div>
  <?php else: ?>
  <?php
    $max_rev = max(array_column($sales_7d, 'revenue') ?: [1]);
    $chart_h = 80;
  ?>
  <div style="display:flex;align-items:flex-end;gap:6px;height:<?= $chart_h + 24 ?>px;padding-bottom:24px;position:relative">
    <?php foreach ($sales_7d as $s): ?>
    <?php $bar_h = max(4, (int)round($chart_h * $s['revenue'] / $max_rev)); ?>
    <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;justify-content:flex-end">
      <div style="font-size:9px;color:var(--text-3)"><?= h(date('M j', strtotime($s['day']))) ?></div>
      <div style="width:100%;height:<?= $bar_h ?>px;background:var(--red);border-radius:4px 4px 0 0;min-height:4px;box-shadow:0 0 8px rgba(219,20,60,.4)" title="$<?= number_format($s['revenue'],2) ?> / <?= $s['cnt'] ?> orders"></div>
      <div style="position:absolute;bottom:0;font-size:9px;color:var(--text-3)">&nbsp;</div>
    </div>
    <?php endforeach; ?>
  </div>
  <div class="flex gap-16 text-xs text-dim mt-4">
    <?php foreach ($sales_7d as $s): ?>
    <div><?= h(date('M j', strtotime($s['day']))) ?> — <?= $s['cnt'] ?> orders · $<?= number_format($s['revenue'],2) ?></div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<div class="grid-2 mt-16">
  <div class="card">
    <div class="section-title">Top Sellers</div>
    <?php if (empty($top_sellers)): ?>
      <div class="text-dim text-sm">No sales yet.</div>
    <?php else: ?>
    <table style="width:100%">
      <thead><tr><th style="text-align:left;font-size:9.5px;color:var(--text-3);padding-bottom:8px">Seller</th><th style="text-align:right;font-size:9.5px;color:var(--text-3)">Sold</th><th style="text-align:right;font-size:9.5px;color:var(--text-3)">Revenue</th></tr></thead>
      <tbody>
      <?php foreach ($top_sellers as $i => $s): ?>
      <tr>
        <td style="padding:5px 0"><span style="color:var(--text-3);font-size:10px"><?= $i+1 ?>.</span> <?= h($s['username']) ?></td>
        <td style="text-align:right;font-weight:700"><?= $s['sold'] ?></td>
        <td style="text-align:right;color:var(--green);font-weight:700">$<?= number_format($s['revenue'],2) ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="section-title">Recent Orders</div>
    <div style="display:flex;flex-direction:column;gap:6px">
    <?php foreach (array_slice($recent_orders, 0, 6) as $o): ?>
    <div class="flex justify-between items-center" style="font-size:11.5px;padding:5px 0;border-bottom:1px solid var(--border)">
      <div>
        <span class="text-dim">#<?= $o['id'] ?></span>
        <span style="margin-left:6px"><?= h($o['buyer']) ?></span>
        <span class="badge badge-gray" style="margin-left:4px"><?= h($o['brand']) ?></span>
      </div>
      <span class="td-price">$<?= number_format($o['price'],2) ?></span>
    </div>
    <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- ═══════════════ LIVE FEED ═══════════════ -->
<?php elseif ($tab === 'feed'): ?>

<!-- Live stat ticker -->
<div class="stat-grid" style="grid-template-columns:repeat(auto-fill,minmax(140px,1fr));margin-bottom:20px" id="live-stats">
  <div class="stat-card"><div class="stat-label">Total Users</div><div class="stat-value" id="ls-users">—</div></div>
  <div class="stat-card"><div class="stat-label">Cards Available</div><div class="stat-value" id="ls-cards">—</div></div>
  <div class="stat-card"><div class="stat-label">Orders Today</div><div class="stat-value green" id="ls-orders-today">—</div></div>
  <div class="stat-card"><div class="stat-label">Revenue Today</div><div class="stat-value red" id="ls-revenue-today">—</div></div>
  <div class="stat-card"><div class="stat-label">In Cart Now</div><div class="stat-value" id="ls-cart">—</div></div>
  <div class="stat-card"><div class="stat-label">Pending Deps</div><div class="stat-value" id="ls-deps">—</div></div>
</div>

<div class="card" style="padding:0;overflow:hidden">
  <!-- Feed header -->
  <div style="display:flex;align-items:center;gap:12px;padding:14px 18px;border-bottom:1px solid var(--border);background:var(--bg-surface)">
    <div class="flex items-center gap-8 flex-1">
      <span class="dot dot-red" id="feed-dot" style="animation:pulse 1s infinite"></span>
      <span class="fw-6" style="font-size:13px">Live Activity Feed</span>
      <span class="badge badge-gray" id="feed-count">0 events</span>
    </div>
    <div class="flex items-center gap-8 text-xs text-dim">
      <span id="feed-status">Connecting...</span>
      <label class="flex items-center gap-4">
        <input type="checkbox" id="feed-pause" style="accent-color:var(--red)"> Pause
      </label>
      <button class="btn btn-ghost btn-xs" id="feed-clear">Clear</button>
    </div>
  </div>

  <!-- Filter bar -->
  <div style="display:flex;gap:6px;padding:10px 18px;border-bottom:1px solid var(--border);background:var(--bg-surface-2);flex-wrap:wrap">
    <span class="text-dim text-xs" style="line-height:24px">Filter:</span>
    <?php foreach (['all'=>'All','order'=>'Orders','deposit'=>'Deposits','register'=>'Registrations','refund'=>'Refunds'] as $fk=>$fl): ?>
    <button class="btn btn-ghost btn-xs feed-filter <?= $fk==='all'?'btn-primary':'' ?>" data-filter="<?= $fk ?>"><?= $fl ?></button>
    <?php endforeach; ?>
  </div>

  <!-- Event stream -->
  <div id="feed-stream" style="height:420px;overflow-y:auto;padding:0;background:var(--bg-root);font-family:monospace;font-size:12px">
    <div id="feed-empty" style="padding:48px;text-align:center;color:var(--text-3)">
      Waiting for activity... Make a purchase, deposit, or register a new account to see events here.
    </div>
  </div>
</div>

<style>
.feed-event{display:flex;align-items:flex-start;gap:12px;padding:9px 18px;border-bottom:1px solid var(--border);animation:fadeIn .25s ease;transition:background .1s}
.feed-event:hover{background:var(--bg-surface)}
.feed-event.hidden{display:none}
.feed-ts{color:var(--text-3);font-size:10.5px;white-space:nowrap;padding-top:1px;min-width:60px}
.feed-type{padding:1px 6px;border-radius:var(--r-pill);font-size:9px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;white-space:nowrap}
.feed-type-order{background:rgba(168,85,247,.15);color:var(--purple)}
.feed-type-deposit{background:rgba(34,197,94,.12);color:var(--green)}
.feed-type-register{background:rgba(74,222,205,.12);color:var(--teal)}
.feed-type-refund{background:rgba(219,20,60,.12);color:var(--red)}
.feed-msg{color:var(--text-2);flex:1;line-height:1.5}
@keyframes fadeIn{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}
</style>

<script>
(function() {
  const stream   = document.getElementById('feed-stream');
  const empty    = document.getElementById('feed-empty');
  const counter  = document.getElementById('feed-count');
  const status   = document.getElementById('feed-status');
  const dot      = document.getElementById('feed-dot');
  const pauseBox = document.getElementById('feed-pause');
  const clearBtn = document.getElementById('feed-clear');

  let since   = Math.floor(Date.now() / 1000) - 300; // last 5 min on load
  let seen    = new Set();
  let total   = 0;
  let filter  = 'all';
  let paused  = false;
  let errorStreak = 0;

  const typeLabels = { order:'order', deposit:'deposit', register:'register', refund:'refund' };
  const typeCss    = { order:'feed-type-order', deposit:'feed-type-deposit', register:'feed-type-register', refund:'feed-type-refund' };

  function fmtTime(ts) {
    const d = new Date(ts * 1000);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
  }

  function addEvent(ev) {
    const key = ev.type + ':' + ev.ts + ':' + ev.label;
    if (seen.has(key)) return;
    seen.add(key);
    total++;

    if (empty) empty.style.display = 'none';
    counter.textContent = total + ' event' + (total === 1 ? '' : 's');

    const row = document.createElement('div');
    row.className = 'feed-event';
    row.dataset.etype = ev.type;
    if (filter !== 'all' && filter !== ev.type) row.classList.add('hidden');

    row.innerHTML =
      '<span class="feed-ts">' + fmtTime(ev.ts) + '</span>' +
      '<span class="feed-type ' + (typeCss[ev.type] || '') + '">' + (typeLabels[ev.type] || ev.type) + '</span>' +
      '<span class="feed-msg">' + ev.label.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') + '</span>';

    stream.insertBefore(row, stream.firstChild);
    // Keep max 200 events
    while (stream.children.length > 201) stream.removeChild(stream.lastChild);
  }

  function updateStats(s) {
    document.getElementById('ls-users').textContent        = s.users ?? '—';
    document.getElementById('ls-cards').textContent        = s.avail_cards ?? '—';
    document.getElementById('ls-orders-today').textContent = s.orders_today ?? '—';
    document.getElementById('ls-revenue-today').textContent = '$' + (parseFloat(s.revenue_today || 0)).toFixed(2);
    document.getElementById('ls-cart').textContent         = s.cart_reserved ?? '—';
    const dEl = document.getElementById('ls-deps');
    dEl.textContent = s.pending_deps ?? '—';
    dEl.style.color = s.pending_deps > 0 ? 'var(--amber)' : '';
  }

  async function poll() {
    if (paused) return;
    try {
      const res = await fetch('/feed.php?since=' + since, { credentials: 'same-origin' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      if (!data.ok) throw new Error(data.error || 'feed error');

      errorStreak = 0;
      status.textContent = 'Live · ' + new Date().toLocaleTimeString([], { hour12: false });
      dot.style.background = 'var(--red)';

      if (data.stats) updateStats(data.stats);
      if (data.events) {
        // Sort ascending so newest end up on top after insertBefore
        const evs = [...data.events].sort((a, b) => a.ts - b.ts);
        evs.forEach(addEvent);
      }
      since = data.now;
    } catch (err) {
      errorStreak++;
      dot.style.background = 'var(--amber)';
      status.textContent = 'Reconnecting... (' + err.message + ')';
    }
  }

  // Filter buttons
  document.querySelectorAll('.feed-filter').forEach(btn => {
    btn.addEventListener('click', () => {
      filter = btn.dataset.filter;
      document.querySelectorAll('.feed-filter').forEach(b => {
        b.classList.toggle('btn-primary', b.dataset.filter === filter);
        b.classList.toggle('btn-ghost', b.dataset.filter !== filter);
      });
      document.querySelectorAll('.feed-event').forEach(row => {
        row.classList.toggle('hidden', filter !== 'all' && row.dataset.etype !== filter);
      });
    });
  });

  pauseBox.addEventListener('change', () => {
    paused = pauseBox.checked;
    status.textContent = paused ? 'Paused' : 'Resuming...';
    dot.style.animationPlayState = paused ? 'paused' : 'running';
  });

  clearBtn.addEventListener('click', () => {
    seen.clear(); total = 0;
    counter.textContent = '0 events';
    document.querySelectorAll('.feed-event').forEach(e => e.remove());
    if (empty) empty.style.display = '';
  });

  // Initial load then every 3s
  poll();
  setInterval(poll, 3000);
})();
</script>

<!-- ═══════════════ DEPOSITS ═══════════════ -->
<?php elseif ($tab === 'deposits'):
  $poller_last   = (int)get_setting('poller_last_run', '0');
  $poller_count  = (int)get_setting('poller_pending_count', '0');
  $poller_ago    = $poller_last > 0 ? (time() - $poller_last) : null;
  $poller_active = $poller_ago !== null && $poller_ago < 120;
  $cron_secret   = get_setting('cron_secret', '');
  // Build the cron URL from the current request host
  $proto    = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $host     = $_SERVER['HTTP_HOST'] ?? 'your-app.replit.app';
  $cron_url = $proto . '://' . $host . '/cron.php?token=' . urlencode($cron_secret);
?>

<!-- ── Poller status + cron setup ─────────────────────────────────── -->
<div class="card mb-16" style="border-color:rgba(99,102,241,.25);padding:0;overflow:hidden">

  <!-- Status bar -->
  <div style="display:flex;align-items:center;gap:10px;padding:12px 16px;
       background:<?= $poller_active ? 'rgba(34,197,94,.06)' : 'rgba(99,102,241,.06)' ?>;
       border-bottom:1px solid var(--border)">
    <span class="dot <?= $poller_active ? 'dot-green' : 'dot-red' ?>"
          style="<?= $poller_active ? 'animation:pulse 2s infinite' : '' ?>"></span>
    <span class="fw-6" style="font-size:12.5px;color:<?= $poller_active ? 'var(--green)' : 'var(--text-2)' ?>">
      Deposit Poller — <?= $poller_active ? 'Active' : 'Idle' ?>
    </span>
    <?php if ($poller_active): ?>
    <span class="text-dim" style="font-size:11px">
      last sweep <?= $poller_ago < 60 ? $poller_ago . 's' : round($poller_ago/60,1) . 'm' ?> ago
      &nbsp;·&nbsp; <?= $poller_count ?> pending
      &nbsp;·&nbsp; 1-confirm threshold
    </span>
    <?php else: ?>
    <span class="text-dim" style="font-size:11px">No sweep in the last 2 minutes.</span>
    <?php endif; ?>
    <span class="badge badge-gray text-xs" style="margin-left:auto">CoinPayments API</span>
  </div>

  <!-- Cron setup -->
  <div style="padding:16px">
    <div class="section-title" style="margin-bottom:10px">
      External Cron — Required for 24/7 Auto-Confirmation on Autoscale
    </div>
    <p class="text-dim text-xs" style="margin-bottom:12px;line-height:1.7">
      Autoscale instances sleep when idle, stopping the background poller.
      Point a free external cron job at the URL below every <strong style="color:var(--text-1)">5 minutes</strong>
      to keep deposits confirming around the clock.
      Recommended service: <strong style="color:var(--text-1)">cron-job.org</strong> (free, no credit card).
    </p>

    <!-- Cron URL box -->
    <div style="display:flex;align-items:stretch;gap:0;margin-bottom:14px;border:1px solid var(--border-subtle);border-radius:var(--r-sm);overflow:hidden">
      <div id="cron-url-box" style="flex:1;padding:9px 12px;font-family:monospace;font-size:11.5px;
           color:var(--teal);background:var(--bg-input);word-break:break-all;line-height:1.5">
        <?= h($cron_url) ?>
      </div>
      <button onclick="navigator.clipboard.writeText(<?= json_encode($cron_url) ?>);this.textContent='Copied!';setTimeout(()=>this.textContent='Copy',1500)"
              class="btn btn-secondary btn-sm" style="border-radius:0;border:none;border-left:1px solid var(--border-subtle);white-space:nowrap">
        Copy
      </button>
    </div>

    <!-- Steps -->
    <ol style="font-size:11.5px;color:var(--text-2);line-height:1.9;padding-left:18px;margin-bottom:12px">
      <li>Go to <strong style="color:var(--text-1)">cron-job.org</strong> → Sign up free → <em>Create cronjob</em></li>
      <li>Paste the URL above into the <em>URL</em> field</li>
      <li>Set schedule to <strong style="color:var(--text-1)">every 5 minutes</strong> (or faster)</li>
      <li>Enable <em>Save responses</em> to monitor results — each call returns JSON with the sweep log</li>
      <li>Save → Done. Deposits will now confirm even while no users are online.</li>
    </ol>

    <!-- Token regen -->
    <div style="display:flex;align-items:center;gap:8px;padding:8px 10px;background:var(--bg-surface-2);border-radius:var(--r-sm);border:1px solid var(--border)">
      <span class="text-dim" style="font-size:11px;flex:1">
        Token: <code style="color:var(--amber);font-size:10.5px"><?= h(substr($cron_secret,0,8)) ?>…<?= h(substr($cron_secret,-6)) ?></code>
        &nbsp;·&nbsp; Keep this private — anyone with this URL can trigger a sweep.
      </span>
      <form method="POST" style="margin:0">
        <input type="hidden" name="action" value="regen_cron_secret">
        <input type="hidden" name="tab"    value="deposits">
        <button class="btn btn-ghost btn-xs" onclick="return confirm('Regenerate cron token? Update your cron job URL afterwards.')">Regenerate Token</button>
      </form>
    </div>
  </div>
</div>

<!-- Withdraw Addresses Settings -->
<?php
$withdraw_methods = ['BTC','ETH','LTC','USDT','USDC','BNB','DOGE','SOL','TRX','DASH','BCH','XRP','MATIC','ADA'];
?>
<div class="card mb-16">
  <div class="section-title" style="margin-bottom:12px">Withdraw Addresses</div>
  <p class="text-dim text-xs" style="margin-bottom:12px;line-height:1.6">
    Configure your wallet addresses per coin. When you click <strong>Withdraw</strong> on a pending deposit,
    the deposit is marked as withdrawn and you manually send the crypto to the matching address below.
  </p>
  <form method="POST" style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
    <input type="hidden" name="action" value="save_withdraw_addresses">
    <input type="hidden" name="tab"    value="deposits">
    <?php foreach ($withdraw_methods as $m): ?>
    <?php $wa = get_setting('withdraw_address_' . $m, ''); ?>
    <div style="display:flex;align-items:center;gap:6px">
      <span class="badge badge-gray" style="min-width:52px;text-align:center;flex-shrink:0"><?= $m ?></span>
      <input type="text" name="withdraw_addr_<?= $m ?>" value="<?= h($wa) ?>"
             placeholder="<?= $m ?> wallet address"
             style="flex:1;font-size:10.5px;font-family:monospace;padding:4px 7px;border-radius:var(--r-sm);
                    border:1px solid var(--border-subtle);background:var(--bg-input);color:var(--text-1)">
    </div>
    <?php endforeach; ?>
    <div style="grid-column:1/-1;display:flex;justify-content:flex-end;margin-top:4px">
      <button class="btn btn-primary btn-sm">Save Addresses</button>
    </div>
  </form>
</div>

<!-- Seed test deposits + pending count header -->
<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
  <span class="fw-6" style="font-size:13px">
    Pending Deposits
    <?php if (!empty($pending_deposits)): ?>
      <span class="badge badge-amber" style="margin-left:4px"><?= count($pending_deposits) ?></span>
    <?php endif; ?>
  </span>
  <form method="POST" style="margin-left:auto">
    <input type="hidden" name="action" value="seed_test_deposits">
    <input type="hidden" name="tab"    value="deposits">
    <button class="btn btn-ghost btn-xs"
            onclick="return confirm('Insert one pending testnet deposit for each crypto (BTC, ETH, LTC, USDT, DOGE)?')">
      + Seed Test Deposits
    </button>
  </form>
</div>

<?php if (!empty($pending_deposits)): ?>
<div class="card mb-16" style="border-color:rgba(245,158,11,.3)">
  <div class="table-wrap" style="border:none">
    <table>
      <thead><tr><th>#</th><th>User</th><th>Method</th><th>Amount</th><th>Deposit Address</th><th>Withdraw To</th><th>Date</th><th style="min-width:220px">Action</th></tr></thead>
      <tbody>
      <?php foreach ($pending_deposits as $d): ?>
      <?php $w_addr = get_setting('withdraw_address_' . strtoupper($d['method']), ''); ?>
      <tr>
        <td class="td-mono"><?= $d['id'] ?></td>
        <td><?= h($d['username']) ?></td>
        <td>
          <span class="badge badge-amber"><?= h($d['method']) ?></span>
        </td>
        <td class="td-price">$<?= number_format($d['amount'],2) ?></td>
        <td class="td-mono" style="font-size:10px;max-width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
          <?= $d['deposit_address'] ? h($d['deposit_address']) : ($d['txid'] ? h($d['txid']) : '<span class="text-dim">—</span>') ?>
        </td>
        <td class="td-mono" style="font-size:10px;max-width:140px;word-break:break-all">
          <?php if ($w_addr): ?>
            <span style="color:var(--teal)"><?= h($w_addr) ?></span>
          <?php else: ?>
            <span class="text-dim" style="font-style:italic">not configured</span>
          <?php endif; ?>
        </td>
        <td class="text-dim" style="font-size:11px"><?= date('M j H:i', $d['created_at']) ?></td>
        <td>
          <form method="POST" style="display:flex;flex-direction:column;gap:4px">
            <input type="hidden" name="action"     value="confirm_deposit">
            <input type="hidden" name="deposit_id" value="<?= $d['id'] ?>">
            <input type="hidden" name="tab"        value="deposits">
            <input type="text" name="txid" placeholder="TXID (optional)"
                   value="<?= h($d['txid'] ?? '') ?>"
                   style="font-size:10.5px;font-family:monospace;padding:3px 6px;border-radius:var(--r-sm);
                          border:1px solid var(--border-subtle);background:var(--bg-input);color:var(--text-1);
                          width:100%;box-sizing:border-box">
            <div class="flex gap-4">
              <button class="btn btn-primary btn-xs" style="flex:1">✓ Confirm</button>
              <button type="button" class="btn btn-secondary btn-xs"
                      onclick="if(!confirm('Withdraw deposit #<?= $d['id'] ?> (<?= h($d['method']) ?>) to:\n<?= h($w_addr ?: 'WARNING: no address configured') ?>'))return;
                               this.closest('form').querySelector('[name=action]').value='withdraw_deposit';
                               this.closest('form').submit()">↓ Withdraw</button>
              <button type="button" class="btn btn-danger btn-xs"
                      onclick="if(!confirm('Reject deposit #<?= $d['id'] ?>?'))return;
                               this.closest('form').querySelector('[name=action]').value='reject_deposit';
                               this.closest('form').removeAttribute('onsubmit');
                               this.closest('form').submit()">✕</button>
            </div>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php else: ?>
<div class="alert alert-success mb-16">No pending deposits. All caught up!</div>
<?php endif; ?>

<div class="card">
  <div class="section-title">All Deposits</div>
  <div class="table-wrap" style="border:none">
    <table>
      <thead><tr><th>#</th><th>User</th><th>Method</th><th>Amount</th><th>TXID</th><th>Withdraw To</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($all_deposits as $d): ?>
      <?php $w_addr = get_setting('withdraw_address_' . strtoupper($d['method']), ''); ?>
      <tr>
        <td class="td-mono"><?= $d['id'] ?></td>
        <td><?= h($d['username']) ?></td>
        <td><span class="badge badge-gray"><?= h($d['method']) ?></span></td>
        <td style="font-weight:700">$<?= number_format($d['amount'],2) ?></td>
        <td class="td-mono" style="font-size:10px;max-width:110px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= $d['txid'] ? h($d['txid']) : '—' ?></td>
        <td class="td-mono" style="font-size:10px;max-width:130px;word-break:break-all">
          <?php if ($w_addr): ?>
            <span style="color:var(--teal)"><?= h($w_addr) ?></span>
          <?php else: ?>
            <span class="text-dim">—</span>
          <?php endif; ?>
        </td>
        <td><?php
          $s = $d['status'];
          $cls = match($s) { 'confirmed'=>'badge-green','pending'=>'badge-amber','rejected'=>'badge-red','withdrawn'=>'badge-gray', default=>'badge-gray' };
          echo "<span class='badge $cls'>$s</span>";
        ?></td>
        <td class="text-dim" style="font-size:11px"><?= date('M j H:i', $d['created_at']) ?></td>
        <td>
          <?php if ($d['status'] === 'pending'): ?>
          <form method="POST" style="display:flex;flex-direction:column;gap:3px;min-width:180px">
            <input type="hidden" name="action"     value="confirm_deposit">
            <input type="hidden" name="deposit_id" value="<?= $d['id'] ?>">
            <input type="hidden" name="tab"        value="deposits">
            <input type="text" name="txid"
                   placeholder="TXID (optional)"
                   value="<?= h($d['txid'] ?? '') ?>"
                   style="font-size:10px;font-family:monospace;padding:2px 5px;border-radius:var(--r-sm);
                          border:1px solid var(--border-subtle);background:var(--bg-input);color:var(--text-1);width:100%;box-sizing:border-box">
            <div class="flex gap-4">
              <button class="btn btn-primary btn-xs" style="flex:1">✓</button>
              <button type="button" class="btn btn-secondary btn-xs"
                      onclick="if(!confirm('Withdraw deposit #<?= $d['id'] ?> (<?= h($d['method']) ?>) to:\n<?= h($w_addr ?: 'WARNING: no address configured') ?>'))return;
                               this.closest('form').querySelector('[name=action]').value='withdraw_deposit';
                               this.closest('form').submit()">↓</button>
              <button type="button" class="btn btn-danger btn-xs"
                      onclick="if(!confirm('Reject?'))return;
                               this.closest('form').querySelector('[name=action]').value='reject_deposit';
                               this.closest('form').submit()">✕</button>
            </div>
          </form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ═══════════════ BASES ═══════════════ -->
<?php elseif ($tab === 'bases'):
  $remote_url = get_setting('sync_remote_url', 'https://shadow-cvv.ct.ws/market.db');
?>

<!-- DB Sync card -->
<div class="card mb-16" style="border-color:rgba(99,102,241,.25);padding:0;overflow:hidden">
  <div style="display:flex;align-items:center;gap:10px;padding:11px 16px;background:rgba(99,102,241,.06);border-bottom:1px solid var(--border)">
    <span class="fw-6" style="font-size:12.5px">🔄 Database Sync</span>
    <span class="badge badge-gray text-xs" style="margin-left:auto">admin only</span>
  </div>
  <div style="padding:14px 16px;display:flex;flex-direction:column;gap:10px">

    <!-- Remote sync row -->
    <div style="padding:12px;border:1px solid var(--border);border-radius:var(--r-sm);background:var(--bg-surface-2)">
      <div class="fw-6 text-sm mb-6">⬇ Fetch &amp; Merge Remote DB</div>
      <div class="text-dim text-xs mb-8" style="line-height:1.6">
        Downloads the remote <code>market.db</code> and merges its users, cards, seller inventory, and settings into the live database.
        New rows are added; existing local rows are never overwritten.
      </div>
      <div style="display:flex;gap:6px;align-items:center">
        <input type="url" id="remote-url-input" value="<?= h($remote_url) ?>"
               class="form-input" style="flex:1;font-size:12px;font-family:monospace"
               placeholder="https://example.com/market.db">
        <button id="remote-btn" onclick="runSync('remote')" class="btn btn-primary btn-sm" style="white-space:nowrap">
          ▶ Fetch &amp; Merge
        </button>
      </div>
    </div>

    <!-- Local scan row -->
    <div style="padding:12px;border:1px solid var(--border);border-radius:var(--r-sm);background:var(--bg-surface-2)">
      <div class="fw-6 text-sm mb-6">📂 Merge Local <code>data/*.db</code></div>
      <div class="text-dim text-xs mb-8" style="line-height:1.6">
        Scans the <code>data/</code> directory for any <code>.db</code> file that isn't <code>market.db</code> and merges it in.
        Each processed file is renamed to <code>*.merged.db</code> so it won't run again.
        Drop a DB file into <code>data/</code> via FTP/Replit Files, then click Run.
      </div>
      <button id="local-btn" onclick="runSync('local')" class="btn btn-secondary btn-sm">
        ▶ Run Local Merge
      </button>
    </div>

    <!-- Result output -->
    <pre id="sync-result" style="display:none;background:var(--bg-root);border:1px solid var(--border);border-radius:var(--r-sm);padding:10px 12px;font-size:10.5px;color:var(--teal);overflow:auto;max-height:260px;margin:0"></pre>

  </div>
</div>
<script>
async function runSync(mode) {
  const remoteBtn = document.getElementById('remote-btn');
  const localBtn  = document.getElementById('local-btn');
  const out       = document.getElementById('sync-result');
  const activeBtn = mode === 'remote' ? remoteBtn : localBtn;

  remoteBtn.disabled = true;
  localBtn.disabled  = true;
  activeBtn.textContent = '⏳ Working…';
  out.style.display = 'none';

  const body = new FormData();
  body.append('mode', mode);
  if (mode === 'remote') {
    body.append('url', document.getElementById('remote-url-input').value.trim());
  }

  try {
    const r   = await fetch('/sync_action.php', { method: 'POST', body });
    const txt = await r.text();
    out.style.display = 'block';

    // Pretty-format if JSON
    try {
      const j = JSON.parse(txt);
      out.style.color = j.ok ? 'var(--green)' : 'var(--red)';

      // Build a human-readable summary
      let lines = [];
      if (j.message) lines.push(j.message);
      if (j.result) {
        const m = j.result.merged || {};
        lines.push('Merged — users: ' + (m.users||0) + '  cards: ' + (m.cards||0) +
                   '  inventory: ' + (m.seller_inventory||0) + '  settings: ' + (m.settings||0));
        if ((j.result.errors||[]).length) lines.push('Errors: ' + j.result.errors.join('; '));
      }
      if (j.results) {
        j.results.forEach(f => {
          const m = f.merged || {};
          lines.push('[' + f.file + '] users:' + (m.users||0) + ' cards:' + (m.cards||0) +
                     ' inventory:' + (m.seller_inventory||0) + (f.archived_as ? ' → ' + f.archived_as : ''));
          if ((f.errors||[]).length) lines.push('  ⚠ ' + f.errors.join('; '));
        });
      }
      if (j.backup) lines.push('Backup: ' + j.backup);
      if (j.ts)     lines.push('Completed: ' + j.ts);
      lines.push('', '── Full JSON ──', txt);
      out.textContent = lines.join('\n');
    } catch(_) {
      out.style.color = 'var(--red)';
      out.textContent = txt;
    }

    // Refresh bases table after success
    if (out.style.color === 'var(--green)') setTimeout(() => location.reload(), 3000);
  } catch(e) {
    out.style.display = 'block';
    out.style.color   = 'var(--red)';
    out.textContent   = 'Network error: ' + e.message;
  } finally {
    remoteBtn.disabled  = false;
    localBtn.disabled   = false;
    remoteBtn.textContent = '▶ Fetch & Merge';
    localBtn.textContent  = '▶ Run Local Merge';
  }
}
</script>

<!-- Uploaded bases table -->
<div class="card">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px">
    <span class="section-title" style="margin-bottom:0">Uploaded Bases (<?= count($all_bases) ?>)</span>
  </div>

  <?php if (empty($all_bases)): ?>
    <div class="text-dim text-sm">No bases uploaded yet. Sellers upload via the Seller Dashboard.</div>
  <?php else: ?>
  <div class="table-wrap" style="border:none">
    <table>
      <thead><tr><th>#</th><th>Seller</th><th>Filename</th><th>Lines</th><th>Imported</th><th>Date</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($all_bases as $b): ?>
      <tr>
        <td class="td-mono"><?= $b['id'] ?></td>
        <td class="fw-6"><?= h($b['username']) ?></td>
        <td style="font-size:11px;font-family:monospace;color:var(--teal)">
          <?= $b['filename'] ? h($b['filename']) : '<span class="text-dim">paste</span>' ?>
        </td>
        <td class="td-mono"><?= number_format((int)$b['count']) ?></td>
        <td>
          <span class="badge <?= (int)$b['imported'] > 0 ? 'badge-green' : 'badge-gray' ?>">
            <?= number_format((int)$b['imported']) ?> cards
          </span>
        </td>
        <td class="text-dim" style="font-size:11px"><?= date('M j Y H:i', (int)$b['created_at']) ?></td>
        <td>
          <div class="flex gap-4">
            <button class="btn btn-ghost btn-xs"
                    onclick="showBaseModal(<?= $b['id'] ?>,<?= json_encode($b['filename'] ?: 'paste #'.$b['id']) ?>,<?= json_encode(substr($b['raw_data'],0,8000)) ?>)">
              View
            </button>
            <a href="/?p=admin&action=download_base&id=<?= $b['id'] ?>" class="btn btn-secondary btn-xs">
              ⬇ Download
            </a>
            <form method="POST" style="margin:0" onsubmit="return confirm('Delete this base record? Cards already imported are NOT removed.')">
              <input type="hidden" name="action" value="delete_base">
              <input type="hidden" name="base_id" value="<?= $b['id'] ?>">
              <input type="hidden" name="tab"     value="bases">
              <button class="btn btn-danger btn-xs">Delete</button>
            </form>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<!-- Base content viewer modal -->
<div id="base-modal" style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.7);align-items:center;justify-content:center;padding:20px">
  <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:var(--r-lg);width:100%;max-width:720px;max-height:90vh;display:flex;flex-direction:column;overflow:hidden">
    <div style="display:flex;align-items:center;padding:14px 18px;border-bottom:1px solid var(--border)">
      <span id="modal-title" class="fw-6" style="flex:1;font-size:13px"></span>
      <button onclick="document.getElementById('base-modal').style.display='none'" class="btn btn-ghost btn-xs">✕ Close</button>
    </div>
    <pre id="modal-content" style="flex:1;overflow:auto;padding:16px;font-size:11px;font-family:monospace;color:var(--teal);margin:0;white-space:pre-wrap;word-break:break-all;background:var(--bg-root)"></pre>
    <div style="padding:10px 16px;border-top:1px solid var(--border);font-size:10.5px;color:var(--text-3)" id="modal-footer"></div>
  </div>
</div>
<script>
function showBaseModal(id, name, content) {
  document.getElementById('modal-title').textContent = name;
  document.getElementById('modal-content').textContent = content;
  const lines = content.split('\n').length;
  document.getElementById('modal-footer').textContent =
    lines + ' lines shown (first 8 000 chars)';
  const m = document.getElementById('base-modal');
  m.style.display = 'flex';
  m.onclick = function(e){ if(e.target===m) m.style.display='none'; };
}
</script>

<!-- ═══════════════ USERS ═══════════════ -->
<?php elseif ($tab === 'users'): ?>
<div class="card">
  <div class="section-title">All Users (<?= count($all_users) ?>)</div>
  <div class="table-wrap" style="border:none">
    <table>
      <thead><tr><th>#</th><th>Username</th><th>Email</th><th>Role</th><th>Balance</th><th>Orders</th><th>Cards</th><th>Joined</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($all_users as $u): ?>
      <tr>
        <td class="td-mono"><?= $u['id'] ?></td>
        <td class="fw-6"><?= h($u['username']) ?></td>
        <td class="text-dim" style="font-size:11px"><?= $u['telegram_username'] ? h($u['telegram_username']) : '—' ?></td>
        <td><?php
          $r = $u['role'];
          $cls = match($r) { 'admin'=>'badge-red','seller'=>'badge-purple','buyer'=>'badge-green','banned'=>'badge-gray', default=>'badge-gray' };
          echo "<span class='badge $cls'>$r</span>";
        ?></td>
        <td style="color:var(--green);font-weight:600">$<?= number_format($u['balance'],2) ?></td>
        <td><?= $u['order_count'] ?></td>
        <td><?= $u['card_count'] ?></td>
        <td class="text-dim" style="font-size:11px"><?= date('M j, Y', $u['created_at']) ?></td>
        <td>
          <?php if ((int)$u['id'] !== (int)$user['id']): ?>
          <div class="flex gap-4" style="flex-wrap:wrap">
            <!-- Role change -->
            <form method="POST" class="flex gap-4">
              <input type="hidden" name="action" value="set_role">
              <input type="hidden" name="target_uid" value="<?= $u['id'] ?>">
              <input type="hidden" name="tab" value="users">
              <select name="role" class="form-input" style="padding:3px 6px;font-size:10.5px;width:auto">
                <?php foreach (['buyer','seller','admin'] as $role_opt): ?>
                  <option value="<?= $role_opt ?>" <?= $u['role']===$role_opt?'selected':'' ?>><?= $role_opt ?></option>
                <?php endforeach; ?>
              </select>
              <button class="btn btn-ghost btn-xs">Set</button>
            </form>
            <!-- Balance adj -->
            <form method="POST" class="flex gap-4">
              <input type="hidden" name="action" value="adjust_balance">
              <input type="hidden" name="target_uid" value="<?= $u['id'] ?>">
              <input type="hidden" name="tab" value="users">
              <input type="number" name="amount" step="0.01" class="form-input" style="width:60px;padding:3px 6px;font-size:10.5px" placeholder="±$">
              <button class="btn btn-ghost btn-xs">Adj</button>
            </form>
            <!-- Ban -->
            <?php if ($u['role'] === 'banned'): ?>
            <form method="POST"><input type="hidden" name="action" value="unban_user"><input type="hidden" name="target_uid" value="<?= $u['id'] ?>"><input type="hidden" name="tab" value="users"><button class="btn btn-secondary btn-xs">Unban</button></form>
            <?php else: ?>
            <form method="POST" onsubmit="return confirm('Ban this user?')"><input type="hidden" name="action" value="ban_user"><input type="hidden" name="target_uid" value="<?= $u['id'] ?>"><input type="hidden" name="tab" value="users"><button class="btn btn-danger btn-xs">Ban</button></form>
            <?php endif; ?>
          </div>
          <?php else: ?>
          <span class="text-dim text-xs">You</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ═══════════════ CARDS ═══════════════ -->
<?php elseif ($tab === 'cards'): ?>
<div class="card">
  <div class="section-title">Card Inventory (<?= count($cards_all) ?>)</div>
  <div class="table-wrap" style="border:none">
    <table>
      <thead><tr><th>#</th><th>Number</th><th>Brand</th><th>Bank</th><th>CC</th><th>Seller</th><th>Status</th><th>Price</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($cards_all as $c): ?>
      <tr>
        <td class="td-mono"><?= $c['id'] ?></td>
        <td class="td-mono"><?= h(substr($c['number'],0,6)) ?>••••<?= h(substr($c['number'],-4)) ?></td>
        <td><span class="badge badge-gray"><?= h($c['brand']) ?></span></td>
        <td style="font-size:11px"><?= h($c['bank']) ?></td>
        <td><?= h($c['country']) ?></td>
        <td class="text-dim"><?= h($c['seller_name']) ?></td>
        <td><?php
          $s = $c['status'];
          $cls = match($s){ 'available'=>'badge-green','reserved'=>'badge-amber','sold'=>'badge-purple', default=>'badge-gray' };
          echo "<span class='badge $cls'>$s</span>";
        ?></td>
        <td class="td-price">$<?= number_format($c['price'],2) ?></td>
        <td>
          <?php if ($c['status'] !== 'sold'): ?>
          <form method="POST" onsubmit="return confirm('Remove card #<?= $c['id'] ?>?')">
            <input type="hidden" name="action" value="delete_card">
            <input type="hidden" name="card_id" value="<?= $c['id'] ?>">
            <input type="hidden" name="tab" value="cards">
            <button class="btn btn-danger btn-xs">Remove</button>
          </form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ═══════════════ ORDERS ═══════════════ -->
<?php elseif ($tab === 'orders'): ?>
<div class="card">
  <div class="section-title">All Orders (<?= count($recent_orders) ?> recent)</div>
  <div class="table-wrap" style="border:none">
    <table>
      <thead><tr><th>#</th><th>Buyer</th><th>Seller</th><th>Card</th><th>Brand</th><th>Price</th><th>Status</th><th>Date</th></tr></thead>
      <tbody>
      <?php foreach ($recent_orders as $o): ?>
      <tr>
        <td class="td-mono"><?= $o['id'] ?></td>
        <td><?= h($o['buyer']) ?></td>
        <td class="text-dim"><?= h($o['seller']) ?></td>
        <td class="td-mono"><?= h(substr($o['number'],0,6)) ?>••••<?= h(substr($o['number'],-4)) ?></td>
        <td><span class="badge badge-gray"><?= h($o['brand']) ?></span></td>
        <td class="td-price">$<?= number_format($o['price'],2) ?></td>
        <td><?php
          $s = $o['status'];
          $cls = match($s){ 'delivered'=>'badge-green','refunded'=>'badge-red', default=>'badge-gray' };
          echo "<span class='badge $cls'>$s</span>";
        ?></td>
        <td class="text-dim" style="font-size:11px"><?= date('M j H:i', $o['purchased_at']) ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- ═══════════════ SUPPORT ═══════════════ -->
<?php elseif ($tab === 'tickets'): ?>
<div class="grid-2" style="align-items:start">
  <div>
    <div class="card">
      <div class="section-title">All Tickets</div>
      <?php foreach ($tickets as $t): ?>
      <a href="/?p=admin&tab=tickets&ticket=<?= $t['id'] ?>" style="display:block">
        <div class="ticket-item" style="<?= $selected_ticket_id===$t['id'] ? 'border-color:var(--red);background:var(--red-deep)' : '' ?>">
          <div style="flex:1;min-width:0">
            <div class="ticket-subject"><?= h($t['subject']) ?></div>
            <div class="ticket-info">#<?= $t['id'] ?> · <?= h($t['username']) ?> · <?= date('M j H:i', $t['created_at']) ?></div>
          </div>
          <span class="badge <?= $t['status']==='open'?'badge-green':'badge-gray' ?>"><?= h($t['status']) ?></span>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>

  <div>
  <?php if ($selected_ticket): ?>
    <div class="card" style="padding:0;overflow:hidden">
      <div style="padding:14px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px">
        <div style="flex:1">
          <div class="fw-6"><?= h($selected_ticket['subject']) ?></div>
          <div class="text-dim text-xs">Ticket #<?= $selected_ticket['id'] ?> · <?= h($selected_ticket['username']) ?></div>
        </div>
        <?php if ($selected_ticket['status']==='open'): ?>
        <form method="POST"><input type="hidden" name="action" value="close_ticket"><input type="hidden" name="ticket_id" value="<?= $selected_ticket_id ?>"><input type="hidden" name="tab" value="tickets"><button class="btn btn-ghost btn-xs">Close</button></form>
        <?php else: ?>
          <span class="badge badge-gray">Closed</span>
        <?php endif; ?>
      </div>
      <div class="chat-msgs" id="chat-msgs">
        <?php foreach ($ticket_msgs as $msg):
          $is_admin = (int)$msg['sender_id'] === (int)$user['id'];
          $is_admin_role = $msg['username'] === 'admin' || $is_admin;
        ?>
        <div class="chat-bubble <?= $is_admin ? 'me' : 'other' ?>">
          <?= h($msg['body']) ?>
          <div class="bubble-meta"><?= h($msg['username']) ?> <?= $is_admin_role ? '<span class="badge badge-red" style="font-size:8px">admin</span>' : '' ?> · <?= date('M j H:i', $msg['created_at']) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php if ($selected_ticket['status']==='open'): ?>
      <form method="POST" action="/?p=admin&tab=tickets&ticket=<?= $selected_ticket_id ?>" class="chat-input-row">
        <input type="hidden" name="action" value="admin_reply">
        <input type="hidden" name="ticket_id" value="<?= $selected_ticket_id ?>">
        <textarea class="form-input" name="body" rows="1" style="flex:1;resize:none" placeholder="Reply as admin..." required></textarea>
        <button class="btn btn-primary btn-sm">Send</button>
      </form>
      <?php endif; ?>
    </div>
  <?php else: ?>
    <div class="card empty-state"><h3>Select a ticket</h3><p class="text-muted">Click a ticket to view the conversation and reply.</p></div>
  <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<!-- ═══════════════ WITHDRAWALS ═══════════════ -->
<?php if ($tab === 'withdrawals'):
  $fee_pct = (float)get_setting('withdrawal_fee_pct', '0');
  $wd_min  = (float)get_setting('withdrawal_min', '10');
  $wd_total_pending = array_sum(array_map(fn($w) => in_array($w['status'],['pending','processing']) ? $w['amount'] : 0, $all_withdrawals));
  $wd_total_out     = array_sum(array_map(fn($w) => $w['status']==='completed' ? $w['net_amount'] : 0, $all_withdrawals));
?>

<!-- Settings + stats row -->
<div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-bottom:20px">
  <div class="card">
    <div class="text-dim text-xs fw-6">PENDING VALUE</div>
    <div class="fw-7" style="font-size:22px;margin-top:4px;color:#fbbf24">$<?= number_format($wd_total_pending, 2) ?></div>
    <div class="text-dim text-xs mt-4"><?= $pending_wds ?> request<?= $pending_wds !== 1 ? 's' : '' ?> awaiting action</div>
  </div>
  <div class="card">
    <div class="text-dim text-xs fw-6">TOTAL PAID OUT</div>
    <div class="fw-7" style="font-size:22px;margin-top:4px;color:var(--green)">$<?= number_format($wd_total_out, 2) ?></div>
    <div class="text-dim text-xs mt-4">All-time completed</div>
  </div>
  <div class="card">
    <div class="text-dim text-xs fw-6 mb-8">WITHDRAWAL SETTINGS</div>
    <form method="POST" style="display:flex;flex-direction:column;gap:8px">
      <input type="hidden" name="action" value="save_withdrawal_settings">
      <input type="hidden" name="tab" value="withdrawals">
      <div style="display:flex;gap:8px;align-items:center">
        <label class="text-dim text-xs" style="width:60px;flex-shrink:0">Fee %</label>
        <input class="form-input" type="number" name="fee_pct" value="<?= $fee_pct ?>" step="0.1" min="0" max="20" style="flex:1;height:30px;padding:4px 8px;font-size:12px">
      </div>
      <div style="display:flex;gap:8px;align-items:center">
        <label class="text-dim text-xs" style="width:60px;flex-shrink:0">Min ($)</label>
        <input class="form-input" type="number" name="min_amount" value="<?= $wd_min ?>" step="1" min="1" style="flex:1;height:30px;padding:4px 8px;font-size:12px">
      </div>
      <button class="btn btn-primary btn-sm" style="align-self:flex-end">Save</button>
    </form>
  </div>
</div>

<?php if (empty($all_withdrawals)): ?>
<div class="card empty-state"><h3>No withdrawals yet</h3><p class="text-muted">Withdrawal requests from sellers will appear here.</p></div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:12px">
<?php foreach ($all_withdrawals as $w):
  $is_active = in_array($w['status'], ['pending', 'processing']);
  $sc = match($w['status']) {
    'completed'  => ['badge-green', '✓ Completed'],
    'processing' => ['badge-amber', '⟳ Processing'],
    'pending'    => ['badge-amber', '⏳ Pending'],
    'rejected'   => ['badge-red',   '✕ Rejected'],
    'cancelled'  => ['badge-gray',  '— Cancelled'],
    default      => ['badge-gray',   h($w['status'])],
  };
?>
<div class="card" style="border-left:3px solid <?= $is_active ? 'var(--red)' : 'var(--border)' ?>">
  <div style="display:flex;gap:16px;flex-wrap:wrap;align-items:flex-start">

    <!-- Left: request details -->
    <div style="flex:1;min-width:220px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;flex-wrap:wrap">
        <span class="fw-7" style="font-size:15px">$<?= number_format((float)$w['amount'], 2) ?></span>
        <span class="text-dim">→</span>
        <span class="fw-6 text-sm"><?= h($w['method']) ?></span>
        <span class="badge <?= $sc[0] ?>"><?= $sc[1] ?></span>
        <?php if ($w['fee'] > 0): ?>
        <span class="badge badge-gray" style="font-size:9px">Fee: $<?= number_format((float)$w['fee'], 2) ?></span>
        <?php endif; ?>
      </div>
      <div style="font-size:11px;color:var(--teal);font-family:monospace;margin-bottom:6px;word-break:break-all">
        <?= h($w['wallet_address']) ?>
      </div>
      <div style="display:flex;gap:12px;font-size:11px;color:var(--text-dim);flex-wrap:wrap">
        <span>User: <strong style="color:var(--fg)"><?= h($w['username']) ?></strong></span>
        <span>Their balance: <strong style="color:var(--fg)">$<?= number_format((float)$w['user_balance'], 2) ?></strong></span>
        <span>Net send: <strong style="color:var(--green)">$<?= number_format((float)$w['net_amount'], 2) ?></strong></span>
        <span><?= date('M j, Y H:i', (int)$w['created_at']) ?></span>
      </div>
      <?php if ($w['txid']): ?>
      <div class="text-dim text-xs mt-6">TXID: <span style="font-family:monospace;color:var(--teal)"><?= h($w['txid']) ?></span></div>
      <?php endif; ?>
      <?php if ($w['admin_note']): ?>
      <div class="text-dim text-xs mt-4" style="color:var(--red)">Admin note: <?= h($w['admin_note']) ?></div>
      <?php endif; ?>
    </div>

    <!-- Right: actions -->
    <?php if ($is_active): ?>
    <div style="display:flex;flex-direction:column;gap:8px;min-width:240px">

      <!-- Approve + TXID -->
      <form method="POST" style="display:flex;gap:6px;align-items:center">
        <input type="hidden" name="action" value="approve_withdrawal">
        <input type="hidden" name="tab" value="withdrawals">
        <input type="hidden" name="withdrawal_id" value="<?= $w['id'] ?>">
        <input class="form-input" type="text" name="txid" placeholder="TXID (optional)" style="flex:1;height:32px;padding:4px 8px;font-size:11px;font-family:monospace" value="<?= h($w['txid'] ?? '') ?>">
        <button class="btn btn-primary btn-sm" style="white-space:nowrap">
          <?= $w['txid'] ? 'Update' : '✓ Approve' ?>
        </button>
      </form>
      <div class="text-dim" style="font-size:10px">Leave TXID blank to mark as "processing" first, then add it when sent.</div>

      <!-- Reject -->
      <details style="font-size:12px">
        <summary class="text-dim" style="cursor:pointer;user-select:none;color:var(--red)">✕ Reject &amp; restore balance</summary>
        <form method="POST" style="display:flex;flex-direction:column;gap:6px;margin-top:8px" onsubmit="return confirm('Reject this withdrawal and return $<?= number_format((float)$w['amount'],2) ?> to the user?')">
          <input type="hidden" name="action" value="reject_withdrawal">
          <input type="hidden" name="tab" value="withdrawals">
          <input type="hidden" name="withdrawal_id" value="<?= $w['id'] ?>">
          <input class="form-input" type="text" name="admin_note" placeholder="Reason (shown to user)" style="height:32px;padding:4px 8px;font-size:11px">
          <button class="btn btn-danger btn-sm" style="align-self:flex-end">Reject &amp; Refund</button>
        </form>
      </details>
    </div>
    <?php elseif ($w['status'] === 'processing' && !$w['txid']): ?>
    <!-- Add TXID to mark complete -->
    <form method="POST" style="display:flex;gap:6px;align-items:center">
      <input type="hidden" name="action" value="update_withdrawal_txid">
      <input type="hidden" name="tab" value="withdrawals">
      <input type="hidden" name="withdrawal_id" value="<?= $w['id'] ?>">
      <input class="form-input" type="text" name="txid" placeholder="Enter TXID to complete" style="flex:1;height:32px;padding:4px 8px;font-size:11px;font-family:monospace" required>
      <button class="btn btn-primary btn-sm">Complete</button>
    </form>
    <?php endif; ?>

  </div>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>
<?php endif; ?>

<!-- ═══════════════ COINPAYMENTS ═══════════════ -->
<?php if ($tab === 'coinpayments'):
  // Recent deposits via CoinPayments
  $cp_recent = $pdo->query("
      SELECT d.*, u.username FROM deposits d
      JOIN users u ON u.id = d.user_id
      WHERE d.cp_invoice_id IS NOT NULL AND d.cp_invoice_id != ''
      ORDER BY d.created_at DESC LIMIT 50
  ")->fetchAll();
  $cp_pending_count = (int)$pdo->query("SELECT COUNT(*) FROM deposits WHERE status='pending' AND cp_invoice_id IS NOT NULL AND cp_invoice_id != ''")->fetchColumn();
  $cp_confirmed_today = (int)$pdo->query("SELECT COUNT(*) FROM deposits WHERE status='confirmed' AND confirmed_at >= " . strtotime('today'))->fetchColumn();
  $cp_revenue_today = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM deposits WHERE status='confirmed' AND confirmed_at >= " . strtotime('today'))->fetchColumn();
?>
<div class="card" style="margin-bottom:20px">
  <div class="section-title" style="margin-bottom:16px">⚡ CoinPayments Integration</div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;margin-bottom:20px">
    <div class="stat-card">
      <div class="stat-label">Client ID</div>
      <div style="font-family:monospace;font-size:11px;color:var(--text-2);word-break:break-all;margin-top:4px">07d7915d34b84f3cb7923e8687959c2f</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">API Endpoint</div>
      <div style="font-family:monospace;font-size:11px;color:var(--teal);margin-top:4px">c-api.coinpayments.net</div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Pending Invoices</div>
      <div class="stat-value <?= $cp_pending_count > 0 ? 'amber' : '' ?>"><?= $cp_pending_count ?></div>
    </div>
    <div class="stat-card">
      <div class="stat-label">Confirmed Today</div>
      <div class="stat-value green"><?= $cp_confirmed_today ?></div>
      <div class="stat-sub">$<?= number_format($cp_revenue_today, 2) ?></div>
    </div>
  </div>

  <div style="background:rgba(99,102,241,.08);border:1px solid rgba(99,102,241,.25);border-radius:8px;padding:14px 16px;font-size:12px;line-height:1.7">
    <div class="fw-7" style="margin-bottom:6px;color:var(--indigo)">✓ CoinPayments Commerce API Active</div>
    Deposits are processed via the CoinPayments hosted checkout. When a customer creates a deposit,
    an invoice is created with CoinPayments and the customer is given a payment address and checkout link.
    Balances are credited automatically once CoinPayments confirms the transaction.
    <br><br>
    <strong>Supported coins:</strong>
    <?php
      // Read from DB cache only — no live API call during page render.
      // Use the Refresh button below to explicitly pull a fresh list.
      $cp_currencies = [];
      try {
          $row_cp = $pdo->prepare("SELECT value FROM settings WHERE key='cp_currencies_json'");
          $row_cp->execute();
          $cp_json = $row_cp->fetchColumn() ?: '';
          if ($cp_json) {
              $cp_decoded = json_decode($cp_json, true);
              if (is_array($cp_decoded) && count($cp_decoded) > 0) {
                  $cp_currencies = $cp_decoded;
              }
          }
      } catch (\Throwable $e) {}
      // If no DB cache exists yet, show the static popular list as a placeholder
      if (empty($cp_currencies)) {
          foreach (CoinPayments::POPULAR_SYMBOLS as $sym) {
              $cp_currencies[$sym] = ['symbol' => $sym, 'name' => $sym, 'type' => 'crypto', 'id' => ''];
          }
      }
      $cp_popular = array_intersect_key($cp_currencies, array_flip(CoinPayments::POPULAR_SYMBOLS));
    ?>
    <?php foreach ($cp_popular as $sym => $c): ?>
      <span class="badge badge-gray" style="margin-right:3px"><?= h($sym) ?></span>
    <?php endforeach; ?>
    <?php if (count($cp_currencies) > count($cp_popular)): ?>
      <span class="text-dim" style="font-size:11px">+ <?= count($cp_currencies) - count($cp_popular) ?> more</span>
    <?php endif; ?>
    <div style="margin-top:10px">
      <form method="POST" style="display:inline">
        <input type="hidden" name="action" value="refresh_currencies">
        <input type="hidden" name="tab" value="coinpayments">
        <button class="btn btn-secondary btn-sm" onclick="return confirm('Force-refresh the coin list from CoinPayments API?')">
          🔄 Refresh Currency List (<?= count($cp_currencies) ?> cached)
        </button>
      </form>
    </div>
  </div>
</div>

<!-- CoinPayments Deposit History -->
<div class="card">
  <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
    <span class="section-title" style="margin-bottom:0">CoinPayments Deposit History</span>
    <span class="badge badge-gray"><?= count($cp_recent) ?></span>
  </div>
  <?php if (empty($cp_recent)): ?>
    <div class="empty-state text-dim text-sm">No CoinPayments deposits yet.</div>
  <?php else: ?>
  <div class="table-wrap" style="border:none">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>User</th>
          <th>Coin</th>
          <th>USD</th>
          <th>Crypto</th>
          <th>Invoice ID</th>
          <th>Status</th>
          <th>Date</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($cp_recent as $dep): ?>
      <?php
        $sc = match($dep['status']) {
            'confirmed'  => 'badge-green',
            'rejected'   => 'badge-red',
            'cancelled'  => 'badge-red',
            default      => 'badge-amber',
        };
        $coin_sym = strtoupper($dep['method'] ?? '?');
      ?>
      <tr>
        <td class="td-mono"><?= $dep['id'] ?></td>
        <td class="fw-6"><?= h($dep['username']) ?></td>
        <td><span class="badge badge-gray"><?= h($coin_sym) ?></span></td>
        <td class="td-price">$<?= number_format((float)$dep['amount'], 2) ?></td>
        <td class="text-dim" style="font-size:11px;font-family:monospace">
          <?= $dep['cp_amount_crypto'] ? h(substr($dep['cp_amount_crypto'], 0, 12)) : '—' ?>
        </td>
        <td class="text-dim" style="font-size:11px;font-family:monospace">
          <?= h(substr($dep['cp_invoice_id'] ?? '—', 0, 20)) ?>…
        </td>
        <td><span class="badge <?= $sc ?>"><?= h($dep['status']) ?></span></td>
        <td class="text-dim" style="font-size:11px"><?= date('M j Y H:i', (int)$dep['created_at']) ?></td>
        <td>
          <?php if ($dep['status'] === 'pending'): ?>
          <form method="POST" style="margin:0;display:inline">
            <input type="hidden" name="action"     value="confirm_deposit">
            <input type="hidden" name="deposit_id" value="<?= $dep['id'] ?>">
            <button type="submit" class="btn btn-ghost btn-xs" style="color:var(--green)" onclick="return confirm('Manually confirm this deposit?')">✓ Confirm</button>
          </form>
          <form method="POST" style="margin:0;display:inline">
            <input type="hidden" name="action"     value="reject_deposit">
            <input type="hidden" name="deposit_id" value="<?= $dep['id'] ?>">
            <button type="submit" class="btn btn-ghost btn-xs" style="color:var(--red)" onclick="return confirm('Reject this deposit?')">✗ Reject</button>
          </form>
          <?php endif; ?>
          <?php if (!empty($dep['cp_checkout_url'])): ?>
          <a href="<?= h($dep['cp_checkout_url']) ?>" target="_blank" rel="noopener" class="btn btn-ghost btn-xs">🔗</a>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php endif; ?>

<?php
    return ob_get_clean();
}
