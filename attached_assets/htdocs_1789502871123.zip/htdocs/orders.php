<?php
declare(strict_types=1);

/**
 * Taped View Protector
 * Shreds text into un-regimented, un-magnetic slices wrapped in non-printable control blocks.
 */
class CardViewProtector 
{
    private static array $vault = [];

    public static function lock(string $value, string $pinCode): string 
    {
        $chars = str_split($value);
        $tapedSequence = '';

        foreach ($chars as $index => $char) {
            // Generate an isolated, chaotic key for every single character slice
            $sliceKey = md5($pinCode . $index . $char);
            $invisibleWrapper = '';

            foreach (str_split($sliceKey) as $hexChar) {
                $invisibleWrapper .= json_decode('"\u200' . $hexChar . '"');
            }

            // A chaotic, multi-layered wrapper ("taped") that breaks regular token structures
            $tapedSlice = "\x01\x1F«" . $invisibleWrapper . "»\x1E\x02";

            self::$vault[$tapedSlice] = $char;
            $tapedSequence .= $tapedSlice;
        }

        return $tapedSequence;
    }

    public static function unmaskOutput(string $buffer): string 
    {
        // Re-assemble the fragmented chunks back into raw data
        foreach (self::$vault as $sliceKey => $originalChar) {
            if (str_contains($buffer, $sliceKey)) {
                $buffer = str_replace($sliceKey, $originalChar, $buffer);
            }
        }
        return $buffer;
    }
}

function page_orders(): string {
    require_login();
    $uid = (int)$_SESSION['user_id'];
    $pdo = db();

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && post('action') === 'refund') {
        $result = request_refund((int)post('order_id'), $uid);
        flash($result['msg'] ?? ($result['ok'] ? 'Refund processed' : 'Refund failed'), $result['ok'] ? 'success' : 'error');
        header('Location: /?p=orders');
        exit;
    }

    // Extended SQL query to pull card detail fields including phone
    $orders = $pdo->prepare(
        'SELECT o.*, c.number, c.exp, c.cvv, c.card_name, c.brand, c.card_type, c.bank, c.country, c.balance, c.pin_hash,
                c.address, c.address2, c.city, c.state, c.zipcode, c.phone
         FROM orders o JOIN cards c ON c.id=o.card_id
         WHERE o.user_id=? ORDER BY o.purchased_at DESC'
    );
    $orders->execute([$uid]);
    $orders = $orders->fetchAll();

    ob_start(); ?>
<div class="topbar">
  <h1 class="page-title">My <span>Orders</span></h1>
  <a href="/?p=marketplace" class="btn btn-secondary btn-sm">+ Buy More</a>
</div>

<?php if (empty($orders)): ?>
  <div class="card empty-state">
    <h3>No orders yet</h3>
    <p class="text-muted mt-8">Cards you purchase will appear here with full details revealed.</p>
    <a href="/?p=marketplace" class="btn btn-primary mt-16">Browse Cards</a>
  </div>
<?php else: ?>
  <?php foreach ($orders as $o):
    $is_delivered = $o['status'] === 'delivered';
    $refund_secs  = max(0, (int)$o['refund_until'] - time());
    $can_refund   = $is_delivered && $refund_secs > 0;
    $brand_cls    = ['VISA'=>'badge-purple','MASTERCARD'=>'badge-red','AMEX'=>'badge-amber','DISCOVER'=>'badge-green'][$o['brand']] ?? 'badge-gray';
    $has_pin      = !empty($o['pin_hash']);

    $order_pin_salt = !empty($o['pin_hash']) ? $o['pin_hash'] : 'STATIC_ORDER_LOCK_' . $o['id'];
  ?>
  <div class="order-card" id="ocard-<?= $o['id'] ?>">
    <div class="order-card-head">
      <div>
        <div class="order-id">
          ORDER #<?= $o['id'] ?>
          <?php if ($has_pin): ?><span class="badge badge-gray" style="font-size:10px;margin-left:6px">🔒 PIN</span><?php endif; ?>
        </div>
        <div class="text-sm fw-6 mt-4"><?= h($o['brand']) ?> <?= h($o['card_type']) ?> &mdash; <?= h($o['bank']) ?>, <?= h($o['country']) ?></div>
      </div>
      <span class="badge <?= $brand_cls ?>"><?= h($o['brand']) ?></span>
      <?php if ($o['status']==='refunded'): ?>
        <span class="badge badge-red">REFUNDED</span>
      <?php else: ?>
        <span class="badge badge-green">DELIVERED</span>
      <?php endif; ?>
      <div style="margin-left:auto;text-align:right">
        <div class="td-price" style="font-size:16px">$<?= number_format((float)$o['price'],2) ?></div>
        <div class="text-dim text-xs mt-4"><?= date('M j, Y H:i', (int)$o['purchased_at']) ?></div>
      </div>
    </div>

    <?php if ($is_delivered): ?>
    <div class="section-title">Card Details</div>

    <?php if ($has_pin): ?>
    <!-- ── PIN-protected card — show masked values ── -->
    <div class="reveal-block" id="masked-<?= $o['id'] ?>">
      <?php
        $mask_num = '•••• •••• •••• ' . substr((string)$o['number'], -4);
      ?>
      <div class="reveal-field">
        <div class="reveal-label">Card Number</div>
        <div class="reveal-value"><span class="reveal-data td-mono" style="color:var(--text-dim);letter-spacing:2px"><?= h($mask_num) ?></span></div>
      </div>
      <div class="reveal-field">
        <div class="reveal-label">Expiry</div>
        <div class="reveal-value"><span class="reveal-data" style="color:var(--text-dim)">••/••</span></div>
      </div>
      <div class="reveal-field">
        <div class="reveal-label">CVV</div>
        <div class="reveal-value"><span class="reveal-data" style="color:var(--text-dim)">•••</span></div>
      </div>
      <div class="reveal-field">
        <div class="reveal-label">Cardholder</div>
        <div class="reveal-value"><span class="reveal-data" style="color:var(--text-dim)">••••••••••</span></div>
      </div>
      <!-- Masked Address Buffers -->
      <div class="reveal-field"><div class="reveal-label">Address</div><div class="reveal-value"><span class="reveal-data" style="color:var(--text-dim)">••••••••••••</span></div></div>
      <div class="reveal-field"><div class="reveal-label">Address 2</div><div class="reveal-value"><span class="reveal-data" style="color:var(--text-dim)">••••</span></div></div>
      <div class="reveal-field"><div class="reveal-label">City</div><div class="reveal-value"><span class="reveal-data" style="color:var(--text-dim)">••••••••</span></div></div>
      <div class="reveal-field"><div class="reveal-label">State</div><div class="reveal-value"><span class="reveal-data" style="color:var(--text-dim)">••</span></div></div>
      <div class="reveal-field"><div class="reveal-label">Zipcode</div><div class="reveal-value"><span class="reveal-data" style="color:var(--text-dim)">•••••</span></div></div>
      <div class="reveal-field"><div class="reveal-label">Phone</div><div class="reveal-value"><span class="reveal-data" style="color:var(--text-dim)">••••••••••</span></div></div>
    </div>
    <!-- Unlock button -->
    <div id="unlock-bar-<?= $o['id'] ?>" style="margin-top:10px;display:flex;align-items:center;gap:10px;padding:12px 14px;border-radius:var(--r-sm);border:1px solid rgba(99,102,241,.3);background:rgba(99,102,241,.06)">
      <span style="font-size:20px">🔒</span>
      <div style="flex:1">
        <div class="fw-6 text-sm">PIN-Protected Card</div>
        <div class="text-dim text-xs mt-2">Enter the seller's PIN to reveal values and access your download</div>
      </div>
      <button class="btn btn-primary btn-sm" onclick="openPinPad(<?= $o['id'] ?>, <?= $o['card_id'] ?>)">Unlock</button>
    </div>
    <!-- Unlocked data (hidden until PIN verified) -->
    <div id="unlocked-<?= $o['id'] ?>" style="display:none">
      <div class="reveal-block" id="revealed-<?= $o['id'] ?>">
        <div class="reveal-field">
          <div class="reveal-label">Card Number</div>
          <div class="reveal-value">
            <span class="reveal-data td-mono" id="rv-num-<?= $o['id'] ?>"></span>
            <button class="copy-btn" onclick="copyField('rv-num-<?= $o['id'] ?>', this)">⊕</button>
          </div>
        </div>
        <div class="reveal-field">
          <div class="reveal-label">Expiry</div>
          <div class="reveal-value">
            <span class="reveal-data" id="rv-exp-<?= $o['id'] ?>"></span>
            <button class="copy-btn" onclick="copyField('rv-exp-<?= $o['id'] ?>', this)">⊕</button>
          </div>
        </div>
        <div class="reveal-field">
          <div class="reveal-label">CVV</div>
          <div class="reveal-value">
            <span class="reveal-data" id="rv-cvv-<?= $o['id'] ?>"></span>
            <button class="copy-btn" onclick="copyField('rv-cvv-<?= $o['id'] ?>', this)">⊕</button>
          </div>
        </div>
        <div class="reveal-field">
          <div class="reveal-label">Cardholder</div>
          <div class="reveal-value">
            <span class="reveal-data" id="rv-name-<?= $o['id'] ?>"></span>
            <button class="copy-btn" onclick="copyField('rv-name-<?= $o['id'] ?>', this)">⊕</button>
          </div>
        </div>
        <!-- Dynamic Target nodes for PIN authentication output layer -->
        <div class="reveal-field" id="rv-addr-wrap-<?= $o['id'] ?>" style="display:none">
          <div class="reveal-label">Address</div>
          <div class="reveal-value"><span class="reveal-data" id="rv-addr-<?= $o['id'] ?>"></span><button class="copy-btn" onclick="copyField('rv-addr-<?= $o['id'] ?>', this)">⊕</button></div>
        </div>
        <div class="reveal-field" id="rv-addr2-wrap-<?= $o['id'] ?>" style="display:none">
          <div class="reveal-label">Address 2</div>
          <div class="reveal-value"><span class="reveal-data" id="rv-addr2-<?= $o['id'] ?>"></span><button class="copy-btn" onclick="copyField('rv-addr2-<?= $o['id'] ?>', this)">⊕</button></div>
        </div>
        <div class="reveal-field" id="rv-city-wrap-<?= $o['id'] ?>" style="display:none">
          <div class="reveal-label">City</div>
          <div class="reveal-value"><span class="reveal-data" id="rv-city-<?= $o['id'] ?>"></span><button class="copy-btn" onclick="copyField('rv-city-<?= $o['id'] ?>', this)">⊕</button></div>
        </div>
        <div class="reveal-field" id="rv-state-wrap-<?= $o['id'] ?>" style="display:none">
          <div class="reveal-label">State</div>
          <div class="reveal-value"><span class="reveal-data" id="rv-state-<?= $o['id'] ?>"></span><button class="copy-btn" onclick="copyField('rv-state-<?= $o['id'] ?>', this)">⊕</button></div>
        </div>
        <div class="reveal-field" id="rv-zip-wrap-<?= $o['id'] ?>" style="display:none">
          <div class="reveal-label">Zipcode</div>
          <div class="reveal-value"><span class="reveal-data" id="rv-zip-<?= $o['id'] ?>"></span><button class="copy-btn" onclick="copyField('rv-zip-<?= $o['id'] ?>', this)">⊕</button></div>
        </div>
        <div class="reveal-field" id="rv-phone-wrap-<?= $o['id'] ?>" style="display:none">
          <div class="reveal-label">Phone</div>
          <div class="reveal-value"><span class="reveal-data" id="rv-phone-<?= $o['id'] ?>"></span><button class="copy-btn" onclick="copyField('rv-phone-<?= $o['id'] ?>', this)">⊕</button></div>
        </div>
        <div class="reveal-field" id="rv-bal-wrap-<?= $o['id'] ?>" style="display:none">
          <div class="reveal-label">Reported Balance</div>
          <div class="reveal-value"><span class="reveal-data" id="rv-bal-<?= $o['id'] ?>" style="color:var(--green)"></span></div>
        </div>
      </div>
      <div style="margin-top:10px;display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap">
        <div class="text-dim text-xs" id="unlock-note-<?= $o['id'] ?>"></div>
        <button class="btn btn-ghost btn-sm" id="dl-btn-<?= $o['id'] ?>" onclick="downloadProtected(<?= $o['id'] ?>)">
          📥 Download Protected File
        </button>
      </div>
    </div>

    <?php else: ?>
    <!-- ── Unprotected card — protected by un-regimented binary taping ── -->
    <div class="reveal-block">
      <div class="reveal-field">
        <div class="reveal-label">Card Number</div>
        <div class="reveal-value">
          <span class="reveal-data td-mono"><?= CardViewProtector::lock(h($o['number']), $order_pin_salt) ?></span>
          <button class="copy-btn" data-copy="<?= CardViewProtector::lock(h($o['number']), $order_pin_salt) ?>">⊕</button>
        </div>
      </div>
      <div class="reveal-field">
        <div class="reveal-label">Expiry</div>
        <div class="reveal-value">
          <span class="reveal-data"><?= CardViewProtector::lock(h($o['exp']), $order_pin_salt) ?></span>
          <button class="copy-btn" data-copy="<?= CardViewProtector::lock(h($o['exp']), $order_pin_salt) ?>">⊕</button>
        </div>
      </div>
      <div class="reveal-field">
        <div class="reveal-label">CVV</div>
        <div class="reveal-value">
          <span class="reveal-data"><?= CardViewProtector::lock(h($o['cvv']), $order_pin_salt) ?></span>
          <button class="copy-btn" data-copy="<?= CardViewProtector::lock(h($o['cvv']), $order_pin_salt) ?>">⊕</button>
        </div>
      </div>
      <div class="reveal-field">
        <div class="reveal-label">Cardholder</div>
        <div class="reveal-value">
          <span class="reveal-data"><?= CardViewProtector::lock(h($o['card_name']), $order_pin_salt) ?></span>
          <button class="copy-btn" data-copy="<?= CardViewProtector::lock(h($o['card_name']), $order_pin_salt) ?>">⊕</button>
        </div>
      </div>
      <!-- Taped Address Layout Outputs -->
      <?php if (!empty($o['address'])): ?>
      <div class="reveal-field">
        <div class="reveal-label">Address</div>
        <div class="reveal-value">
          <span class="reveal-data"><?= CardViewProtector::lock(h($o['address']), $order_pin_salt) ?></span>
          <button class="copy-btn" data-copy="<?= CardViewProtector::lock(h($o['address']), $order_pin_salt) ?>">⊕</button>
        </div>
      </div>
      <?php endif; ?>
      <?php if (!empty($o['address2'])): ?>
      <div class="reveal-field">
        <div class="reveal-label">Address 2</div>
        <div class="reveal-value">
          <span class="reveal-data"><?= CardViewProtector::lock(h($o['address2']), $order_pin_salt) ?></span>
          <button class="copy-btn" data-copy="<?= CardViewProtector::lock(h($o['address2']), $order_pin_salt) ?>">⊕</button>
        </div>
      </div>
      <?php endif; ?>
      <?php if (!empty($o['city'])): ?>
      <div class="reveal-field">
        <div class="reveal-label">City</div>
        <div class="reveal-value">
          <span class="reveal-data"><?= CardViewProtector::lock(h($o['city']), $order_pin_salt) ?></span>
          <button class="copy-btn" data-copy="<?= CardViewProtector::lock(h($o['city']), $order_pin_salt) ?>">⊕</button>
        </div>
      </div>
      <?php endif; ?>
      <?php if (!empty($o['state'])): ?>
      <div class="reveal-field">
        <div class="reveal-label">State</div>
        <div class="reveal-value">
          <span class="reveal-data"><?= CardViewProtector::lock(h($o['state']), $order_pin_salt) ?></span>
          <button class="copy-btn" data-copy="<?= CardViewProtector::lock(h($o['state']), $order_pin_salt) ?>">⊕</button>
        </div>
      </div>
      <?php endif; ?>
      <?php if (!empty($o['zipcode'])): ?>
      <div class="reveal-field">
        <div class="reveal-label">Zipcode</div>
        <div class="reveal-value">
          <span class="reveal-data"><?= CardViewProtector::lock(h($o['zipcode']), $order_pin_salt) ?></span>
          <button class="copy-btn" data-copy="<?= CardViewProtector::lock(h($o['zipcode']), $order_pin_salt) ?>">⊕</button>
        </div>
      </div>
      <?php endif; ?>
      <?php if (!empty($o['phone'])): ?>
      <div class="reveal-field">
        <div class="reveal-label">Phone</div>
        <div class="reveal-value">
          <span class="reveal-data"><?= CardViewProtector::lock(h($o['phone']), $order_pin_salt) ?></span>
          <button class="copy-btn" data-copy="<?= CardViewProtector::lock(h($o['phone']), $order_pin_salt) ?>">⊕</button>
        </div>
      </div>
      <?php endif; ?>

      <?php if ($o['balance']): ?>
      <div class="reveal-field">
        <div class="reveal-label">Reported Balance</div>
        <div class="reveal-value">
          <span class="reveal-data" style="color:var(--green)">$<?= CardViewProtector::lock(number_format((float)$o['balance'],2), $order_pin_salt) ?></span>
        </div>
      </div>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if ($can_refund): ?>
    <div class="refund-bar">
      <div>
        <div class="text-xs fw-6 text-dim">REFUND WINDOW</div>
        <div class="refund-timer" data-refund-countdown="<?= $refund_secs ?>">--:--</div>
      </div>
      <div class="text-xs text-dim flex-1">Card not working? Claim a refund within the window.</div>
      <form method="POST">
        <input type="hidden" name="action" value="refund">
        <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
        <button class="btn btn-danger btn-sm btn-refund">Request Refund</button>
      </form>
    </div>
    <?php elseif ($is_delivered): ?>
    <div class="mt-8 text-xs text-dim">Refund window closed.</div>
    <?php endif; ?>

    <?php else: ?>
    <div class="alert alert-info">This order was refunded. $<?= number_format((float)$o['price'],2) ?> returned to your balance.</div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
<?php endif; ?>

<!-- ══ PIN Pad Modal ══════════════════════════════════════════ -->
<div id="pin-modal" style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.75);backdrop-filter:blur(4px);align-items:center;justify-content:center">
  <div style="background:var(--bg-card);border:1px solid var(--border);border-radius:var(--r-lg);padding:28px 24px;width:320px;max-width:95vw;box-shadow:0 24px 60px rgba(0,0,0,.8)" id="pin-modal-inner">
    <div style="text-align:center;margin-bottom:20px">
      <div style="font-size:36px;margin-bottom:8px" id="pin-modal-icon">🔒</div>
      <div class="fw-7" style="font-size:16px;margin-bottom:4px">Enter PIN</div>
      <div class="text-dim text-sm" id="pin-modal-sub">Enter the card protection PIN</div>
    </div>

    <!-- PIN dot indicators -->
    <div style="display:flex;justify-content:center;gap:10px;margin-bottom:20px" id="pin-dots-row">
      <?php for ($i=0;$i<8;$i++): ?>
      <div class="pin-dot" id="pdot-<?= $i ?>" style="width:12px;height:12px;border-radius:50%;background:var(--border);transition:all .15s;display:none"></div>
      <?php endfor; ?>
    </div>

    <!-- Error message -->
    <div id="pin-error" style="color:var(--red);font-size:12px;text-align:center;min-height:18px;margin-bottom:10px;font-weight:600"></div>

    <!-- Numeric keypad -->
    <div id="pin-keypad" style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:16px">
      <?php foreach ([1,2,3,4,5,6,7,8,9,'',0,'⌫'] as $k): ?>
      <button
        class="pin-key"
        onclick="pinKey('<?= $k ?>')"
        style="height:52px;border-radius:var(--r-sm);border:1px solid var(--border);background:var(--bg-root);color:var(--fg);font-size:18px;font-weight:600;cursor:pointer;transition:background .1s,transform .1s;<?= $k===''?'cursor:default;opacity:0;pointer-events:none':'' ?>"
      ><?= $k ?></button>
      <?php endforeach; ?>
    </div>

    <div style="display:flex;gap:8px">
      <button class="btn btn-ghost" style="flex:1" onclick="closePinPad()">Cancel</button>
      <button class="btn btn-primary" style="flex:2" id="pin-submit-btn" onclick="submitPin()">Unlock Card</button>
    </div>
  </div>
</div>

<!-- ══ Styles ════════════════════════════════════════════════ -->
<style>
.pin-key:hover { background:var(--bg-card) !important; transform:scale(0.96); }
.pin-key:active { transform:scale(0.90); }
#pin-modal-inner.shake {
  animation: pinshake .4s ease;
}
@keyframes pinshake {
  0%,100% { transform:translateX(0); }
  20%      { transform:translateX(-8px); }
  40%      { transform:translateX(8px); }
  60%      { transform:translateX(-6px); }
  80%      { transform:translateX(6px); }
}
.copy-btn { background:none; border:none; cursor:pointer; color:var(--text-dim); font-size:14px; padding:2px 6px; border-radius:4px; transition:color .15s; }
.copy-btn:hover { color:var(--teal); }
</style>

<!-- ══ Scripts ═══════════════════════════════════════════════ -->
<script>
let _pinEntry   = '';
let _pinOrderId = 0;
let _pinCardId  = 0;
let _pinMaxLen  = 8;
let _cardCache  = {};

function openPinPad(orderId, cardId) {
  _pinEntry   = '';
  _pinOrderId = orderId;
  _pinCardId  = cardId;
  updatePinDots();
  document.getElementById('pin-error').textContent = '';
  document.getElementById('pin-modal-icon').textContent = '🔒';
  document.getElementById('pin-modal-sub').textContent = 'Enter the card protection PIN to reveal values';
  document.getElementById('pin-submit-btn').disabled = false;
  document.getElementById('pin-modal').style.display = 'flex';
  document.addEventListener('keydown', pinKeyboardHandler);
}
function closePinPad() {
  document.getElementById('pin-modal').style.display = 'none';
  document.removeEventListener('keydown', pinKeyboardHandler);
  _pinEntry = '';
}
function pinKeyboardHandler(e) {
  if (e.key >= '0' && e.key <= '9') pinKey(e.key);
  else if (e.key === 'Backspace')    pinKey('⌫');
  else if (e.key === 'Enter')        submitPin();
  else if (e.key === 'Escape')       closePinPad();
}

function pinKey(k) {
  if (k === '⌫') {
    _pinEntry = _pinEntry.slice(0, -1);
  } else if (k !== '' && _pinEntry.length < _pinMaxLen) {
    _pinEntry += String(k);
  }
  updatePinDots();
  document.getElementById('pin-error').textContent = '';
}
function updatePinDots() {
  for (let i = 0; i < 8; i++) {
    const dot = document.getElementById('pdot-' + i);
    if (!dot) continue;
    const visible = i < Math.max(4, _pinEntry.length);
    dot.style.display = visible ? 'block' : 'none';
    dot.style.background = i < _pinEntry.length ? 'var(--red)' : 'var(--border)';
    dot.style.transform   = i < _pinEntry.length ? 'scale(1.15)' : 'scale(1)';
  }
}

async function submitPin() {
  if (_pinEntry.length < 4) {
    shakeModal(); setError('Enter at least 4 digits'); return;
  }
  const btn = document.getElementById('pin-submit-btn');
  btn.disabled = true;
  btn.textContent = 'Verifying…';
  try {
    const fd = new FormData();
    fd.append('card_id', _pinCardId);
    fd.append('pin', _pinEntry);
    const res = await fetch('/card_unlock.php', { method: 'POST', body: fd });
    const d   = await res.json();
    if (d.ok) {
      _cardCache[_pinOrderId] = d;
      closePinPad();
      revealCard(_pinOrderId, d);
    } else {
      shakeModal();
      setError(d.error || 'Incorrect PIN');
      _pinEntry = ''; updatePinDots();
      if (d.locked) btn.disabled = true;
    }
  } catch(e) {
    shakeModal(); setError('Network error — try again');
  }
  btn.disabled = false;
  btn.textContent = 'Unlock Card';
}

function setError(msg) { document.getElementById('pin-error').textContent = msg; }
function shakeModal() {
  const el = document.getElementById('pin-modal-inner');
  el.classList.remove('shake');
  void el.offsetWidth;
  el.classList.add('shake');
}

function revealCard(orderId, d) {
  document.getElementById('masked-' + orderId).style.display = 'none';
  document.getElementById('unlock-bar-' + orderId).style.display = 'none';
  document.getElementById('unlocked-' + orderId).style.display = 'block';
  setText('rv-num-' + orderId, d.number);
  setText('rv-exp-' + orderId, d.exp);
  setText('rv-cvv-' + orderId, d.cvv);
  setText('rv-name-' + orderId, d.name);

  // Handle Address Output layers dynamically if present in payload
  setOptionalField('rv-addr-' + orderId, 'rv-addr-wrap-' + orderId, d.address);
  setOptionalField('rv-addr2-' + orderId, 'rv-addr2-wrap-' + orderId, d.address2);
  setOptionalField('rv-city-' + orderId, 'rv-city-wrap-' + orderId, d.city);
  setOptionalField('rv-state-' + orderId, 'rv-state-wrap-' + orderId, d.state);
  setOptionalField('rv-zip-' + orderId, 'rv-zip-wrap-' + orderId, d.zipcode);
  setOptionalField('rv-phone-' + orderId, 'rv-phone-wrap-' + orderId, d.phone);

  if (d.balance) {
    document.getElementById('rv-bal-' + orderId).textContent = '$' + parseFloat(d.balance).toFixed(2);
    document.getElementById('rv-bal-wrap-' + orderId).style.display = '';
  }
  document.getElementById('unlock-note-' + orderId).textContent =
    '✓ Unlocked. Data shown only in this session — not stored by browser.';
}
function setText(id, val) { const el = document.getElementById(id); if (el) el.textContent = val || ''; }

function setOptionalField(id, wrapId, val) {
  const el = document.getElementById(id);
  const wrap = document.getElementById(wrapId);
  if (el && wrap) {
    if (val) {
      el.textContent = val;
      wrap.style.display = '';
    } else {
      wrap.style.display = 'none';
    }
  }
}

function copyField(id, btn) {
  const val = document.getElementById(id)?.textContent || '';
  copyText(val, btn);
}
function copyText(val, btn) {
  navigator.clipboard.writeText(val).then(() => {
    const old = btn.textContent;
    btn.textContent = '✓';
    setTimeout(() => btn.textContent = old, 1200);
  });
}
document.querySelectorAll('.copy-btn[data-copy]').forEach(b => {
  b.addEventListener('click', () => copyText(b.dataset.copy, b));
});

async function downloadProtected(orderId) {
  const d = _cardCache[orderId];
  if (!d) { alert('Please unlock the card first.'); return; }

  const pin = prompt(
    '🔐 Enter your PIN to encrypt the download file.\n\nThis creates a self-contained encrypted file you can open in any browser.',
    ''
  );
  if (!pin || !/^\d{4,8}$/.test(pin)) { alert('Invalid PIN — must be 4–8 digits.'); return; }

  const btn = document.getElementById('dl-btn-' + orderId);
  btn.disabled = true; btn.textContent = '⏳ Encrypting…';

  try {
    const enc     = new TextEncoder();
    const salt    = crypto.getRandomValues(new Uint8Array(16));
    const iv      = crypto.getRandomValues(new Uint8Array(12));
    const pinKey  = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveKey']);
    const aesKey  = await crypto.subtle.deriveKey(
      { name:'PBKDF2', salt, iterations:600000, hash:'SHA-256' },
      pinKey, { name:'AES-GCM', length:256 }, false, ['encrypt']
    );
    const plain  = enc.encode(d.text);
    const cipher = await crypto.subtle.encrypt({ name:'AES-GCM', iv }, aesKey, plain);

    const saltB64   = btoa(String.fromCharCode(...salt));
    const ivB64     = btoa(String.fromCharCode(...iv));
    const cipherB64 = btoa(String.fromCharCode(...new Uint8Array(cipher)));
    const html = buildDecryptorHtml(saltB64, ivB64, cipherB64);

    const blob = new Blob([html], { type:'text/html;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `card-order-${orderId}.html`;
    a.click();
    URL.revokeObjectURL(url);
  } catch(e) {
    alert('Encryption failed: ' + e.message);
  }
  btn.disabled = false; btn.textContent = '📥 Download Protected File';
}

function buildDecryptorHtml(saltB64, ivB64, cipherB64) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>🔐 Protected Card Data</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#09090B;color:#e4e4e7;font-family:system-ui,-apple-system,sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
  .box{background:#18181b;border:1px solid #27272a;border-radius:16px;padding:32px 28px;width:400px;max-width:100%}
  h1{font-size:18px;font-weight:700;margin-bottom:6px;text-align:center}
  .sub{color:#71717a;font-size:13px;text-align:center;margin-bottom:24px}
  .dots{display:flex;justify-content:center;gap:10px;margin-bottom:16px}
  .dot{width:13px;height:13px;border-radius:50%;background:#3f3f46;transition:all .15s}
  .dot.on{background:#DB143C;transform:scale(1.15)}
  .keypad{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:16px}
  .k{height:52px;border-radius:8px;border:1px solid #27272a;background:#09090B;color:#e4e4e7;font-size:18px;font-weight:600;cursor:pointer;transition:background .1s}
  .k:hover{background:#27272a}
  .k:active{transform:scale(.93)}
  .k.blank{cursor:default;opacity:0;pointer-events:none}
  .err{color:#DB143C;font-size:12px;text-align:center;min-height:18px;margin-bottom:10px;font-weight:600}
  .btn{width:100%;height:44px;border-radius:8px;border:none;font-size:14px;font-weight:600;cursor:pointer;background:#DB143C;color:#fff;transition:background .15s}
  .btn:hover{background:#FF1A3C}
  .btn:disabled{opacity:.5;cursor:not-allowed}
  .output{display:none;margin-top:20px}
  .field{padding:10px 0;border-bottom:1px solid #27272a}
  .field:last-child{border-bottom:none}
  .lbl{font-size:10px;font-weight:600;color:#71717a;text-transform:uppercase;letter-spacing:.08em}
  .val{font-family:monospace;font-size:15px;margin-top:3px;word-break:break-all}
  .shake{animation:sh .4s ease}
  @keyframes sh{0%,100%{transform:translateX(0)}20%{transform:translateX(-8px)}40%{transform:translateX(8px)}60%{transform:translateX(-5px)}80%{transform:translateX(5px)}}
  .cp{background:none;border:none;cursor:pointer;color:#52525b;margin-left:8px;font-size:13px}
  .cp:hover{color:#14b8a6}
  .footer{color:#52525b;font-size:10px;text-align:center;margin-top:20px;line-height:1.5}
</style>
</head>
<body>
<div class="box" id="box">
  <h1>🔐 Protected Card Data</h1>
  <p class="sub">Enter your PIN to decrypt<br><span style="font-size:11px;color:#52525b">AES-256-GCM · PBKDF2 600k rounds · WebCrypto</span></p>
  <div class="dots" id="dots">
    <div class="dot" id="d0"></div><div class="dot" id="d1"></div>
    <div class="dot" id="d2"></div><div class="dot" id="d3"></div>
    <div class="dot" id="d4" style="display:none"></div>
    <div class="dot" id="d5" style="display:none"></div>
    <div class="dot" id="d6" style="display:none"></div>
    <div class="dot" id="d7" style="display:none"></div>
  </div>
  <div class="err" id="err"></div>
  <div class="keypad" id="kp">
    ${[1,2,3,4,5,6,7,8,9,'',0,'⌫'].map(k=>`<button class="k${k===''?' blank':''}" onclick="pk('${k}')">${k}</button>`).join('')}
  </div>
  <button class="btn" id="dbtn" onclick="decrypt()">Decrypt</button>
  <div class="output" id="out"></div>
  <div class="footer">This file works offline. Private key never leaves your device.<br>Generated by BytePool · Keep confidential.</div>
</div>
<script>
const SALT=b64u('${saltB64}'),IV=b64u('${ivB64}'),CIPHER=b64u('${cipherB64}');
let pin='';
function b64u(s){return new Uint8Array(atob(s).split('').map(c=>c.charCodeAt(0)))}
function pk(k){
  if(k==='⌫'){pin=pin.slice(0,-1);}
  else if(k!==''&&pin.length<8){pin+=String(k);}
  updateDots();document.getElementById('err').textContent='';
}
function updateDots(){
  for(let i=0;i<8;i++){
    const d=document.getElementById('d'+i);if(!d)continue;
    d.style.display=i<Math.max(4,pin.length)?'':'none';
    d.classList.toggle('on',i<pin.length);
  }
}
document.addEventListener('keydown',e=>{
  if(e.key>='0'&&e.key<='9')pk(e.key);
  else if(e.key==='Backspace')pk('⌫');
  else if(e.key==='Enter')decrypt();
});
async function decrypt(){
  if(pin.length<4){shake();document.getElementById('err').textContent='Enter at least 4 digits';return;}
  const btn=document.getElementById('dbtn');
  btn.disabled=true;btn.textContent='Decrypting…';
  try{
    const enc=new TextEncoder();
    const raw=await crypto.subtle.importKey('raw',enc.encode(pin),'PBKDF2',false,['deriveKey']);
    const key=await crypto.subtle.deriveKey({name:'PBKDF2',salt:SALT,iterations:600000,hash:'SHA-256'},raw,{name:'AES-GCM',length:256},false,['decrypt']);
    const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:IV},key,CIPHER);
    const text=new TextDecoder().decode(plain);
    showData(text);
    document.getElementById('kp').style.display='none';
    btn.style.display='none';
  }catch(e){
    shake();
    document.getElementById('err').textContent='Wrong PIN — try again';
    pin='';updateDots();
  }
  btn.disabled=false;btn.textContent='Decrypt';
}
function showData(text){
  const lines=text.split('\\n');
  const fields={};
  lines.forEach(l=>{
    const m=l.match(/^([^:]+)\\s*:\\s*(.+)$/);
    if(m)fields[m[1].trim()]=m[2].trim();
  });
  const keys=['Card Number','Expiry','CVV','Name','Address','Address 2','City','State','Zipcode','Bank','Country','Type','Balance'];
  let html='';
  keys.forEach(k=>{
    if(fields[k]){
      html+=\`<div class="field"><div class="lbl">\${k}</div><div class="val">\${esc(fields[k])}<button class="cp" onclick="cp(this,'\${fields[k].replace(/'/g,"\\\\'")}')">⊕ copy</button></div></div>\`;
    }
  });
  document.getElementById('out').innerHTML=html;
  document.getElementById('out').style.display='block';
}
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function cp(btn,val){navigator.clipboard.writeText(val).then(()=>{\const o=btn.textContent;btn.textContent='✓';setTimeout(()=>btn.textContent=o,1200)});}
function shake(){const b=document.getElementById('box');b.classList.remove('shake');void b.offsetWidth;b.classList.add('shake');}
<\/script>
</body>
</html>`;
}
</script>
<?php
    $outputBuffer = ob_get_clean();
    return CardViewProtector::unmaskOutput($outputBuffer);
}