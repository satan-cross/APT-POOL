<?php
declare(strict_types=1);
/**
 * cron.php — External cron endpoint for deposit auto-confirmation.
 *
 * Called by an external service (e.g. cron-job.org) every 5 minutes.
 * Runs one full deposit sweep and returns a JSON summary.
 *
 * Authentication: ?token=<cron_secret>  OR  X-Cron-Token: <cron_secret> header
 *
 * Example URL: https://your-app.replit.app/cron.php?token=YOUR_SECRET
 */

define('ROOT_DIR', __DIR__);
require_once ROOT_DIR . '/src/bootstrap.php';

header('Content-Type: application/json');

// ── Auth ─────────────────────────────────────────────────────────────────────
$secret   = get_setting('cron_secret', '');
$provided = $_GET['token'] ?? $_SERVER['HTTP_X_CRON_TOKEN'] ?? '';

if (empty($secret) || !hash_equals($secret, $provided)) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'forbidden']);
    exit;
}

// ── Run sweep ─────────────────────────────────────────────────────────────────
require_once ROOT_DIR . '/src/deposit_poller.php';

$started = microtime(true);
$lines   = [];

try {
    sweep_pending_deposits(function(string $msg) use (&$lines): void {
        $lines[] = '[' . date('H:i:s') . '] ' . $msg;
    });
    $ok = true;
} catch (\Throwable $e) {
    $lines[] = 'FATAL: ' . $e->getMessage();
    $ok = false;
}

$elapsed = round(microtime(true) - $started, 3);

echo json_encode([
    'ok'      => $ok,
    'elapsed' => $elapsed . 's',
    'log'     => $lines,
    'ts'      => date('Y-m-d H:i:s'),
], JSON_PRETTY_PRINT);
