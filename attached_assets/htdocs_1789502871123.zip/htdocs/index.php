<?php
declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

// Serve static files for PHP built-in server
if (PHP_SAPI === 'cli-server') {
    $file = __DIR__ . $_SERVER['REQUEST_URI'];
    $file = strtok($file, '?');
    if (is_file($file) && !str_ends_with($file, '.php')) {
        return false; // Serve static file directly
    }
}

define('ROOT_DIR', __DIR__);

require_once ROOT_DIR . '/src/bootstrap.php';
require_once ROOT_DIR . '/src/layout.php';

// Load all pages (skip standalone endpoints that have their own bootstrap)
$page_skip = ['init.php', 'wallet_functions.php', 'check_deposits.php', 'index.php', 'wallet_setup.php'];
foreach (glob(ROOT_DIR . '/src/pages/*.php') as $page_file) {
    if (in_array(basename($page_file), $page_skip)) continue;
    require_once $page_file;
}

$page = current_page();

// Pages that skip the layout
if ($page === 'login') {
    $body = page_login();
    // Login page renders its own full HTML
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>BytePool — Sign In</title><link rel="stylesheet" href="/assets/app.css"></head><body>';
    echo $body;
    echo '<script src="/assets/app.js"></script></body></html>';
    exit;
}

$page_fn = 'page_' . $page;
$body = function_exists($page_fn) ? $page_fn() : '<div class="empty-state"><h3>Page not found</h3></div>';

render_layout($page, $body);
