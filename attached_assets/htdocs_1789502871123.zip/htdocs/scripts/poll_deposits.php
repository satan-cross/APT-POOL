<?php
declare(strict_types=1);
/**
 * poll_deposits.php — CLI background deposit confirmation loop.
 *
 * Run as a persistent workflow process ("Deposit Poller" workflow).
 * Sweeps all pending deposits every 30 s using shared sweep logic.
 *
 * In production on Autoscale, this runs while the instance is awake.
 * For guaranteed 24/7 coverage, also point cron-job.org at /cron.php
 * every 5 minutes — see Admin → Deposits for the full URL.
 */

define('ROOT_DIR', dirname(__DIR__));
require_once ROOT_DIR . '/src/bootstrap.php';
require_once ROOT_DIR . '/src/deposit_poller.php';

const POLL_INTERVAL = 30; // seconds between full sweeps

function log_msg(string $msg): void {
    echo '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n";
    flush();
}

log_msg('Deposit poller started (interval=' . POLL_INTERVAL . 's, required_confirms=' . REQUIRED_CONFIRMS . ')');

while (true) {
    try {
        sweep_pending_deposits('log_msg');
    } catch (\Throwable $e) {
        log_msg('SWEEP ERROR: ' . $e->getMessage());
    }
    sleep(POLL_INTERVAL);
}
